package sg.edu.smu.teamrtt.localizertt.ui.rttdetails

import android.net.wifi.ScanResult
import android.net.wifi.rtt.RangingResult
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentRttDetailsBinding
import sg.edu.smu.teamrtt.localizertt.model.dataview.RTTDetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.toastMessages


/**
 * RTT Details Fragment
 *
 * Show the RTT Scan details of the selected WiFi Scanned AP
 *
 * @author William Tan. 14 Jan 2025.
 */
class RTTDetailsFragment : Fragment() {

    //  Sharing data between HomeFragment with RTTDetailsFragment
    private val rttDetailsViewModel: RTTDetailsDataViewModel by activityViewModels()

    private var _binding: FragmentRttDetailsBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    //  Handle to the Preference DataStore
    private lateinit var appPrefStore: AppPrefStore

    //  UI Elements
    private var tvContentMacAddress: TextView? = null
    private var tvContentDistanceMm: TextView? = null
    private var tvContentDistanceStdDevMm: TextView? = null
    private var tvContentRSSI: TextView? = null
    private var tvContentRangeTimestampMillis: TextView? = null
    private var tvContentNumAttemptedMeasurements: TextView? = null
    private var tvContentNumSuccessfulMeasurements: TextView? = null
    private var tvContentMeasurementBandwidth: TextView? = null
    private var tvContentMeasurementChannelFreq: TextView? = null

    private var chkboxRTT2or1sidede: CheckBox? = null
    private var chkboxIEEE80211az: CheckBox? = null
    private var chkboxIEEE80211mc: CheckBox? = null

    private var chkboxAPDefaultTest: CheckBox? = null
    private var selectedBSSID = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentRttDetailsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //  Setup the App Preferences DataStore
        context?.let { it1 ->
            appPrefStore = AppPrefStore(it1)
        }

        val textView: TextView = binding.textRttHeader
        // slideshowViewModel.text.observe(viewLifecycleOwner) {
        //     textView.text = it
        // }

        tvContentMacAddress = binding.tvContentMacaddress
        tvContentDistanceMm = binding.tvContentDistanceMm
        tvContentDistanceStdDevMm = binding.tvContentDistanceStdDevMm
        tvContentRSSI = binding.tvContentRssi
        tvContentRangeTimestampMillis = binding.tvContentRangetimestampmillis
        tvContentNumAttemptedMeasurements = binding.tvContentNumAttemptedMeasurements
        tvContentNumSuccessfulMeasurements = binding.tvContentNumSuccessfulMeasurements
        tvContentMeasurementBandwidth = binding.tvContentMeasurementBandwidth
        tvContentMeasurementChannelFreq = binding.tvContentMeasurementChannelFreqMhz

        chkboxRTT2or1sidede = binding.checkBoxRttsided1or2
        chkboxIEEE80211az = binding.checkBoxIeee80211azFlag
        chkboxIEEE80211mc = binding.checkBoxIeee80211mcFlag
        chkboxAPDefaultTest = binding.checkBoxDefaultTestAP

        var refMacAddress: String? = null
        val thisFrag: Fragment = this

        //  https://medium.com/@kocoviczoran_5004/pass-data-between-fragments-in-kotlin-6928c08d2bd0
        val apInfo = arguments?.getString("apInfo")
        val splitHolder: List<String>? = apInfo?.split(",")
        if (!splitHolder.isNullOrEmpty()) {

            textView.text = apInfo

            refMacAddress = splitHolder[0]

            selectedBSSID = refMacAddress
            val storeBSSID = appPrefStore.loadAPDefaultTest()
            Log.i("William", "selectedBSSID: $selectedBSSID, storeBSSID: $storeBSSID")
            chkboxAPDefaultTest?.isChecked = storeBSSID.compareTo(selectedBSSID) == 0
        }

        //  Go back to Home Fragment
        val btnBack: Button = binding.btnBack
        btnBack.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction().remove(thisFrag).commit()
        }

        //  Go back to Home Fragment
        val btnSetDefaultBSSID: Button = binding.btnSetDefaultTestAP
        btnSetDefaultBSSID.setOnClickListener {
            if (selectedBSSID.isNotBlank() && selectedBSSID.length > 3) {
                appPrefStore.setDefaultTestAP(selectedBSSID)
                chkboxAPDefaultTest?.isChecked = true
                rttDetailsViewModel.setRefTestAP(selectedBSSID)
                toastMessages(this.context, "This BSSID is now set to default Test AP.\nPlease wait to allow RTT ranging data to populate.")
            }
        }

        //  Observe for any changes occurring in HomeFragment
        //  Why? William: As the WiFi Scan is still occurring in Main Activity, any changes (e.g. RSSI, etc) will need to be updated in this UI as well.
        rttDetailsViewModel.currentRangingResult.observe(viewLifecycleOwner) { value ->

            //Log.i("William","RTTDetailsFragment Observer callback data updated!!! $value")

            for (eachScanResult in value) {

                if (refMacAddress == eachScanResult.macAddress.toString() && eachScanResult.status == RangingResult.STATUS_SUCCESS) {
                    //  Update the UI components to reflect updated results from the HomeFragment scan updates
                    setRangingResultToUI(eachScanResult)
                }
            }
        }

        return root
    }

    /**
     * Set Ranging Result To UI
     *
     * Given the the RTT scan result, update the UI Components.
     */
    private fun setRangingResultToUI(eachResult: RangingResult) {

        //Log.i("William","Name: ${eachResult.macAddress}, distance: ${eachResult.distanceMm}" )

        tvContentMacAddress?.text = eachResult.macAddress.toString()
        tvContentDistanceMm?.text = eachResult.distanceMm.toString()
        tvContentDistanceStdDevMm?.text = eachResult.distanceStdDevMm.toString()
        tvContentRSSI?.text = eachResult.rssi.toString()
        tvContentRangeTimestampMillis?.text = eachResult.rangingTimestampMillis.toString()
        tvContentNumAttemptedMeasurements?.text = eachResult.numAttemptedMeasurements.toString()
        tvContentNumSuccessfulMeasurements?.text = eachResult.numSuccessfulMeasurements.toString()
        tvContentMeasurementChannelFreq?.text = eachResult.measurementChannelFrequencyMHz.toString()

        //  ===============================================================================================

        if (eachResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_160MHZ)
            tvContentMeasurementBandwidth?.text = "160MHZ"
        else if (eachResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_20MHZ)
            tvContentMeasurementBandwidth?.text = "20MHZ"
        else if (eachResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_40MHZ)
            tvContentMeasurementBandwidth?.text = "40MHZ"
        else if (eachResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_80MHZ)
            tvContentMeasurementBandwidth?.text = "80MHZ"
        else if (eachResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ)
            tvContentMeasurementBandwidth?.text = "80MHZ PLUS"
        else if (eachResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_320MHZ)
            tvContentMeasurementBandwidth?.text = "320MHZ"
        else
            tvContentMeasurementBandwidth?.text = "Unspecified"

        //  ===============================================================================================

        if (eachResult.is80211azNtbMeasurement)
            chkboxIEEE80211az?.isChecked = true
        else
            chkboxIEEE80211az?.isChecked = false

        if (eachResult.is80211mcMeasurement)
            chkboxIEEE80211mc?.isChecked = true
        else
            chkboxIEEE80211mc?.isChecked = false

        if (!eachResult.is80211azNtbMeasurement && !eachResult.is80211mcMeasurement) {
            chkboxRTT2or1sidede?.isChecked = false
        } else {
            chkboxRTT2or1sidede?.isChecked = true
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}