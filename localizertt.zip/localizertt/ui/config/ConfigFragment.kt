package sg.edu.smu.teamrtt.localizertt.ui.config

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.widget.addTextChangedListener
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import sg.edu.smu.teamrtt.localizertt.dataStoreW
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentConfigBinding
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_AP_SCAN_TIME
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_CACHE_AP_TRACK_TIME
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_CELS_CAPTURE_TIME
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_MAX_NO_OF_AP
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_RSSI_FILTER
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_RTT_SCAN_TIME
import sg.edu.smu.teamrtt.localizertt.util.APSKEY_SAVE_TO_CSV
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.RSSI_FILTER

/**
 * Config Fragment
 *
 * This UI Fragment has the following functionality:
 * 1. Displays the various settings that the App use.
 * 2. These settings can be configured for different purposes.
 * 3. Config fragment uses DataStore Manager for preferences store/retrieve: https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/DataStoreManager.kt
 *
 * The configs available here are:
 * 1. WiFi Scan and RTT scan time
 * 2. Cache window for storing each AP's data
 * 3. WiFi filtering for RSSI
 * 4. Toggling to save to CSV files.
 *
 * William: DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 14: Created by William Tan Kiat Wee.
 */
class ConfigFragment : Fragment() {

    private var _binding: FragmentConfigBinding? = null

    // This property is only valid between onCreateView and onDestroyView.
    private val binding get() = _binding!!

    //  Handle to the Preference DataStore
    private lateinit var appPrefStore: AppPrefStore

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val configViewModel = ViewModelProvider(this).get(ConfigViewModel::class.java)

        _binding = FragmentConfigBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //  Setup the App Preferences DataStore
        context?.let { it1 ->
            appPrefStore = AppPrefStore(it1)
        }

        //  The Fragment title
        val textView: TextView = binding.textConfigHeader
        configViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        //  Handles to the UI views via binding
        val switchbtn = binding.switchEnableSaveToCsv
        val textEditAPScanTime = binding.editTextApScanTime
        val textEditRTTScanTime = binding.editTextRttScanTime
        val textEditCelsCaptureTime = binding.editTextCelsCaptureTimee
        val textEditAPCacheTimeWindow = binding.editTextTimeWindowForEachAp
        val textEditRSSIFilter = binding.editTextRssiFilter
        val textEditMaxNoOfAp = binding.editTextMaxNoOfAp

        //  Load from datastore to UI fields.
        binding.apply {

            //  Async Load from the datastore
            CoroutineScope(Dispatchers.IO).launch {

                context?.dataStoreW?.data?.collect { usrData ->

                    //  Load up RSSI Filter
                    val dsKeyrssiFilter = longPreferencesKey(APSKEY_RSSI_FILTER)
                    val dsRssiFilte = usrData[dsKeyrssiFilter] ?: RSSI_FILTER
                    activity?.runOnUiThread {
                        binding.apply {
                            textEditRSSIFilter.setText("$dsRssiFilte")
                        }
                    }

                    //  Load up Max No of AP
                    val dsKeyMaxNoOfAp = longPreferencesKey(APSKEY_MAX_NO_OF_AP)
                    val dsMaxNoOfAp = usrData[dsKeyMaxNoOfAp] ?: 10
                    activity?.runOnUiThread {
                        binding.apply {
                            textEditMaxNoOfAp.setText("$dsMaxNoOfAp")
                        }
                    }

                    //  Load up AP Scan Time
                    val dsKeyAPScanTime = longPreferencesKey(APSKEY_AP_SCAN_TIME)
                    val dsAPScanTime = usrData[dsKeyAPScanTime] ?: 10000
                    activity?.runOnUiThread {
                        binding.apply {
                            textEditAPScanTime.setText("$dsAPScanTime")
                        }
                    }

                    //  Load up RTT Scan Time
                    val dsKeyRTTScanTime = longPreferencesKey(APSKEY_RTT_SCAN_TIME)
                    val dsRTTScanTime = usrData[dsKeyRTTScanTime] ?: 100
                    activity?.runOnUiThread {
                        binding.apply {
                            textEditRTTScanTime.setText("$dsRTTScanTime")
                        }
                    }

                    //  Load up Position Capture Time (For Constant-Error LeastSquare Algo)
                    val dsKeyCELSCaptureTime = longPreferencesKey(APSKEY_CELS_CAPTURE_TIME)
                    val dsCELSCaptureTime = usrData[dsKeyCELSCaptureTime] ?: 20000
                    activity?.runOnUiThread {
                        binding.apply {
                            textEditCelsCaptureTime.setText("$dsCELSCaptureTime")
                        }
                    }

                    //  Load up Cache Time Window Per AP. The time to hold history of each AP before discarding.
                    val dsKeyCacheAPTrackTime = longPreferencesKey(APSKEY_CACHE_AP_TRACK_TIME)
                    val dsCacheAPTrackTime = usrData[dsKeyCacheAPTrackTime] ?: (10 * 60 * 1000L)
                    activity?.runOnUiThread {
                        binding.apply {
                            textEditAPCacheTimeWindow.setText("$dsCacheAPTrackTime")
                        }
                    }

                    //  Load up Save-CSV Flag
                    val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
                    val flag = usrData[flagSaveToCSV] ?: false
                    if (flag) {
                        // Display Data On UI
                        activity?.runOnUiThread {
                            binding.apply {
                                switchbtn.isChecked = true
                            }
                        }
                    } else {
                        activity?.runOnUiThread {
                            binding.apply {
                                switchbtn.isChecked = false
                            }
                        }
                    }
                }
            }
        }

        //  The change listeners for the view handles are listed below

        textEditRSSIFilter.addTextChangedListener {
            appPrefStore.setRSSIFilter(textEditRSSIFilter.text.toString().toLong())
        }

        textEditMaxNoOfAp.addTextChangedListener {
            appPrefStore.setMaxNoOfAP(textEditMaxNoOfAp.text.toString().toLong())
        }

        textEditRTTScanTime.addTextChangedListener {
            appPrefStore.setRTTScanTime(textEditRTTScanTime.text.toString().toLong())
        }

        textEditCelsCaptureTime.addTextChangedListener {
            appPrefStore.setCaptureTime(textEditCelsCaptureTime.text.toString().toLong())
        }

        textEditAPCacheTimeWindow.addTextChangedListener {
            appPrefStore.setCacheAPTrackTime(textEditAPCacheTimeWindow.text.toString().toLong())
        }

        textEditAPScanTime.addTextChangedListener {
            appPrefStore.setAPScanTime(textEditAPScanTime.text.toString().toLong())
        }

        binding.switchEnableSaveToCsv.setOnCheckedChangeListener { buttonView, isChecked ->

            //Log.i("William", "switchEnableSensor Clicked!")

            if (isChecked)
                appPrefStore.setSaveCSVFlag(true)
            else
                appPrefStore.setSaveCSVFlag(false)
        }

        return root
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}