package sg.edu.smu.teamrtt.localizertt.ui.home

import android.R
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.ViewModelProvider
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentHomeBinding
import sg.edu.smu.teamrtt.localizertt.model.dataview.WiFiScanDataViewModel
import sg.edu.smu.teamrtt.localizertt.ui.rttdetails.RTTDetailsFragment

/**
 * Home Fragment
 *
 * This UI Fragment has the following functionality:
 * 1. Toggle on/off WiFi AP Scan (This trigger functionality in MainActivity)
 * 2. List of WiFi AP sorted via RSSI Strength (strongest to weakest)
 * 3. Once user taps on any of the listed AP, brings them to the RTTDetailsFragment showing the AP details (this includes the RTT details)
 *
 * William Notes:
 * 1. DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 19: Created by William Tan Kiat Wee.
 */
class HomeFragment : Fragment() {

    //  1. Sharing data between HomeFragment with Main Activity
    private val wifiScanDataViewModel: WiFiScanDataViewModel by activityViewModels()

    private var listOfSSID = emptyArray<String>()

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private var btnSwitchWiFiScan: Switch? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        //  View Handles
        val textView: TextView = binding.textHome
        homeViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        //  List the WiFi, data loaded via ViewModels
        //  https://www.geeksforgeeks.org/android-listview-in-kotlin/
        val listViewSSID: ListView = binding.lvSSID
        var arrayAdapter = ArrayAdapter(this.requireContext(), R.layout.simple_list_item_1, listOfSSID)
        listViewSSID.adapter = arrayAdapter

        //  Update the ViewModel on toggle button change
        btnSwitchWiFiScan = binding.switchWiFiScan
        binding.switchWiFiScan.setOnCheckedChangeListener { buttonView, isChecked ->

            //  Trigger or Stop the MainActivity to start scanning based on what the user click.
            wifiScanDataViewModel.setFlagStartScan(isChecked)
        }

        //  Update the list if there are data changes from the MainActivity.
        wifiScanDataViewModel.currentListOfSSID.observe(viewLifecycleOwner) { value ->

            listOfSSID = emptyArray()
            listOfSSID = value.clone()

            //  https://www.geeksforgeeks.org/android-listview-in-kotlin/
            //val listViewSSID: ListView = binding.lvSSID
            arrayAdapter = ArrayAdapter(this.requireContext(), R.layout.simple_list_item_1, listOfSSID)
            listViewSSID.adapter = arrayAdapter
            listViewSSID.setOnItemClickListener { parent, view, i, l ->

                val element: String = arrayAdapter.getItem(i).toString()
                // Log.i("William","List element: $element" )

                //  Bundle
                //  https://medium.com/@kocoviczoran_5004/pass-data-between-fragments-in-kotlin-6928c08d2bd0
                val bundleDataToBePassOn = Bundle()
                bundleDataToBePassOn.putString("apInfo", element)

                val fragmentManager = requireActivity().supportFragmentManager
                val transaction = fragmentManager.beginTransaction()
                val rttFrag = RTTDetailsFragment()

                rttFrag.arguments = bundleDataToBePassOn
                transaction.add(
                    sg.edu.smu.teamrtt.localizertt.R.id.nav_host_fragment_content_main,
                    rttFrag
                )
                transaction.commit()
            }
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null

    }
}