package sg.edu.smu.teamrtt.localizertt.callbacks

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/**
 * William Notes: Google Gemini Generated Code For Testing
 *
 */
class StepDetector(private val sensorManager: SensorManager) : SensorEventListener {

    private var stepCount = 0
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    // Simple Moving Average filter
    private val filterWindowSize = 10 // Adjust as needed
    private val magnitudeBuffer = FloatArray(filterWindowSize)
    private var bufferIndex = 0
    private var isBufferFull = false

    // --- Parameters for peak detection (adjust these carefully) ---
    private var lastPeakTimeNs: Long = 0
    private val minTimeBetweenStepsNs: Long = 250_000_000L // 250 ms, approx 4 steps/sec max
    private val stepThreshold = 1.5f // Example threshold, needs tuning! Lower for more sensitivity.

    fun start() {
        accelerometer?.also { accel ->
            sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    fun getStepCount(): Int {
        return stepCount
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]

            // 1. Calculate magnitude
            val magnitude = sqrt(x * x + y * y + z * z)

            // 2. Simple Moving Average Filter
            magnitudeBuffer[bufferIndex] = magnitude
            bufferIndex = (bufferIndex + 1) % filterWindowSize
            if (bufferIndex == 0) {
                isBufferFull = true
            }

            if (isBufferFull) {
                val filteredMagnitude = magnitudeBuffer.average().toFloat()

                // 3. Basic Peak Detection and Debouncing
                val currentTimeNs = event.timestamp
                if (filteredMagnitude > stepThreshold && (currentTimeNs - lastPeakTimeNs > minTimeBetweenStepsNs)) {
                    // Check if it's a local maximum (simplistic check)
                    // A more robust peak detector would look at values before and after
                    // For this example, we'll assume a peak if above threshold and time condition met
                    // In a real app, you'd likely compare to previous filtered values.
                    val previousIndex = (bufferIndex - 2 + filterWindowSize) % filterWindowSize
                    if (filteredMagnitude > magnitudeBuffer[previousIndex]) { // Basic check against previous value
                        stepCount++
                        lastPeakTimeNs = currentTimeNs
                        // Log.d("StepDetector", "Step detected! Count: $stepCount, Magnitude: $filteredMagnitude")
                    }
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Can be used to handle changes in sensor accuracy if needed
    }
}
