package sg.edu.smu.teamrtt.localizertt.operations.coord

import android.net.wifi.rtt.RangingResult
import android.util.Log
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.research.PointSuggestion
import sg.edu.smu.teamrtt.localizertt.research.map_visualization.PointVal
import java.util.concurrent.ConcurrentHashMap

/**
 * Coordinate Operation Class
 *
 * Sits in MainActivity
 *  - Obtains RTT Range scan from WIFIRTTScanOps
 *  - Captures the Step data from IMU
 *  - Captures Coordinate Point from the DrawSB1Fragment
 *
 * Dependency:
 * 1. Uses Research Package to process
 * 2. Depends on the CoordinatePoint data from DrawSB1Fragment. This is because the starting point is user-dependant (user taps on the screen)
 * 3. Subsequent movement with step data is dependant on the starting point. (Where the movement: Step and Azimuth is processed in DrawSB1Fragment)
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 Aug 29 William: Created for integrating the Research Components from Hai and Thu for the Probabilistic AP's location approach.
 */
class CoordOpsV2 {

    private val classTAG = this.javaClass.name

    //CoordinatePoint
    private var captureCoordPointHashmap = HashMap<Long, CoordinatePoint>()

    //  Steps
    private var stepsCounted: Long = 0

    /**
     * Hashmap containing each step (indexed) to a timestamp.
     *
     * Essentially, logging each step to a timestamp.
     * Data structure: Step - UnixTimestampInMilliSeconds. Long - Long
     */
    private var stepIndexTimestampHashMap = HashMap<Long, Long>()

    private var lastDirectionalGuidanceTimestamp1: Long = 0L
    private var lastDirectionalGuidanceTimestamp2: Long = 0L

    private lateinit var lastPointVal: PointVal

    private var cumlativeListOfPointVal: MutableList<PointVal> = arrayListOf()
    private var cumulativeSetOfPointVal: MutableSet<PointVal> = mutableSetOf()

    private var hashMapBSSIDtoCumulativeSetOfPointVal = ConcurrentHashMap<String, MutableSet<PointVal>>()

    fun getAllBSSIDCumulativeSetOfPointVal(): ConcurrentHashMap<String, MutableSet<PointVal>> {

        return hashMapBSSIDtoCumulativeSetOfPointVal
    }

    fun getAllBSSIDCumulativeListOfPointVal(): MutableList<MutableList<PointVal>> {

        val listOfListOfPointVal: MutableList<MutableList<PointVal>> = mutableListOf()

        for (eachEntry in hashMapBSSIDtoCumulativeSetOfPointVal) {

            val cumulativeListOfPointVal: MutableList<PointVal> = eachEntry.value.toMutableList()
            listOfListOfPointVal.add(cumulativeListOfPointVal)
        }

        return listOfListOfPointVal
    }

    /**
     * Log and update each step to a timestamp
     *
     * Essentially, logging each step to a timestamp.
     * Data structure: Step - UnixTimestampInMilliSeconds. Long - Long
     *
     * TODO: William: Set a cache size to this (5min or 10min), not feasible to keep storing without a limit.
     */
    fun updateStepData(timestamp: Long): Long {
        //  With each step, increment the step counter
        stepsCounted++

        //  Add to hashmap: Step - UnixTimestampInMilliSeconds. Long - Long
        stepIndexTimestampHashMap[stepsCounted] = timestamp

        //  Return the step Index
        return stepsCounted
    }

    /**
     * Capture and Store Each CoordinatePoint to a timestamp.
     *
     * Data is capture in Hashmap.
     * Data structure: UnixTimestampInMilliSeconds - CoordinatePoint: Long - CoordinatePoint
     *
     * On Store, the previous older entry, older than 5 min is removed to conserve space.
     * TODO: William: Improve the cache.
     */
    fun captureCoordPoint(timestamp: Long, coordinatePoint: CoordinatePoint) {

        captureCoordPointHashmap.put(timestamp, coordinatePoint)

        //  Remove old result > 5min
        val filterTimestamp = timestamp - (5 * 60 * 1000)
        for (eachTimestamp in captureCoordPointHashmap.keys.sorted())
            if (eachTimestamp <= filterTimestamp)
                captureCoordPointHashmap.remove(eachTimestamp)
            else
                break
    }

    /**
     * Return the all the captured CoordinatePoint with timestamp.
     *
     * Data is capture in Hashmap.
     * Data structure: UnixTimestampInMilliSeconds - CoordinatePoint: Long - CoordinatePoint
     */
    fun getCoordPointHashMap(): HashMap<Long, CoordinatePoint> {
        return captureCoordPointHashmap.toMap() as HashMap<Long, CoordinatePoint>
    }

    /**
     * Generate the PointVal for each step for all steps (all the way to the latest step)
     *
     * Each PointVal contains the X, Y position as well as the Mean of RTT Distance value at that position.
     *
     * To generate all PointVal, use the captureCoordPointHashmap where:
     * 1. we captured the CoordinatePoint with a timestamp at each step.
     * 2. Calculate the Mean RTT Distance at each step where mean is between this step and previous step.
     * 3. Hence, this function needs the initial timestamp which is the creationTimestamp which logs the timestamp at the point where the user is created on the map.
     * 4. This loops until the last step inside captureCoordPointHashmap.
     * 5. This function is called again to regenerate all the PointVal
     *
     * TODO: William: Maybe we store the values at Step 5. So that we don't need to regenerate everything again?
     *
     * Example:
     * Step 0 - creationTimestamp
     * Step 1 - Timestamp of Step 1 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 1 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 2 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 2 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * ...
     *
     * Calculate the RTT mean between at Step 0, Step 0 to 1, Step 1 to 2, etc, etc, etc.
     * Get the CoordinatePoint, with the RTT Mean an put into Thu's PointVal.
     *
     * Why?: This function interfaces with Thu's PointVal class which is later used in the DrawSB1Fragment to generate the MASK for drawing the heatmap.
     */
    fun thusPointValGeneratorForAllSteps(
        selectedAP: String,
        creationTimestamp: Long,
        scanResultHashMap: HashMap<Long, MutableList<RangingResult>>
    ): MutableList<PointVal> {

        //  Init
        val listOfPointVal: MutableList<PointVal> = arrayListOf()
        var totalDistance = 0
        var count = 0
        var meanDistance: Double
        var coordinatePoint: CoordinatePoint? = null

        //  1. Process the first timestamp at the point the user is created.
        //  ================================================================

        //  Capture the RTT Distance
        val sortedTimestamps = scanResultHashMap.keys.sorted()
        for (eachTimestamp in sortedTimestamps) {
            if (eachTimestamp < creationTimestamp) {
                val scanResultData: MutableList<RangingResult>? = scanResultHashMap.get(eachTimestamp)
                if (scanResultData != null) {
                    for (eachScanResult in scanResultData) {
                        if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {

                            val refMacAddress = eachScanResult.macAddress.toString().substring(0, 14)
                            val valSelectedAP = selectedAP.substring(0, 14)

                            //Log.i(classTAG, "macAddress: ${refMacAddress}")
                            //Log.i(classTAG, "valSelectedAP: ${valSelectedAP}")

                            if (valSelectedAP.compareTo(refMacAddress) == 0) {
                                //Log.i(classTAG, "matched!")
                                totalDistance += eachScanResult.distanceMm / 1000
                                count++

                                //  If we have valid RTT value, load the CoordinatePoint
                                coordinatePoint = captureCoordPointHashmap.get(eachTimestamp)
                            }
                        }


                    }
                } else
                    Log.e(classTAG, "scanResultData is empty")
            }
        }

        //  Only calculate the mean, if CoordinatePoint is loaded and count is non zero.
        if (coordinatePoint != null && count != 0) {
            //  Get Mean (if count is zero, we are going to get divide by zero error)
            meanDistance = totalDistance / count.toDouble()

            //  We have mean, coordinate point, we create the PointVal and store it.
            val pointVal = PointVal(coordinatePoint.x, coordinatePoint.y, meanDistance)
            listOfPointVal.add(pointVal)
        }


        //  2. Process the next series of steps after the initial creationTimestamp
        //  =======================================================================

        //  Set the createTimestamp now as the previous timestamp, as we are moving to the next step.
        var prevTimestamp = creationTimestamp

        //  Repeat the same processing but now we are interating through the step
        val sortedKeys = stepIndexTimestampHashMap.keys.sorted()
        for (eachKey in sortedKeys) {
            //  Get the next timestamp for each step
            val nextTimestamp: Long? = stepIndexTimestampHashMap.get(eachKey)
            if (nextTimestamp != null) {

                //  Reset
                totalDistance = 0
                count = 0

                //  At next timestamp, we get all the RTT values from the previous timestamp to the next timestamp.
                val sortedTimestamps = scanResultHashMap.keys.sorted()
                for (eachTimestamp in sortedTimestamps) {
                    //  Check if the timestamp is between previous and next, and get the RTT distance
                    if (eachTimestamp > prevTimestamp && eachTimestamp < nextTimestamp) {

                        val scanResultData: MutableList<RangingResult>? = scanResultHashMap.get(eachTimestamp)
                        if (scanResultData != null) {
                            for (eachScanResult in scanResultData) {
                                if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {

                                    //val refMacAddress = eachScanResult.macAddress.toString().substring(0, 14)
                                    //val valSelectedAP = selectedAP.substring(0, 14)

                                    val refMacAddress = eachScanResult.macAddress.toString()
                                    val valSelectedAP = selectedAP

                                    if (valSelectedAP.compareTo(refMacAddress) == 0) {
                                        totalDistance += eachScanResult.distanceMm / 1000
                                        count++

                                        //  If we have valid RTT value, load the CoordinatePoint
                                        coordinatePoint = captureCoordPointHashmap.get(eachTimestamp)
                                    }
                                }
                            }
                        } else
                            Log.i(classTAG, "scanResultData is empty")
                    }
                }

                //  Only calculate the mean, if CoordinatePoint is loaded and count is non zero.
                if (coordinatePoint != null && count != 0) {
                    //  Get Mean (if count is zero, we are going to get divide by zero error)
                    meanDistance = totalDistance / count.toDouble()

                    //  We have mean, coordinate point, we create the PointVal and store it.
                    val pointVal = PointVal(coordinatePoint.x, coordinatePoint.y, meanDistance)
                    listOfPointVal.add(pointVal)
                }

                //  Move the next to the previous and now repeat for the next step. All the way to the last step.
                prevTimestamp = nextTimestamp
            }
        }

        return listOfPointVal
    }


    /**
     * Generate the PointVal for each step for 2 Points only
     *
     * Each PointVal contains the X, Y position as well as the Mean of RTT Distance value at that position.
     *
     * To generate all PointVal, use the captureCoordPointHashmap where:
     * 1. we captured the CoordinatePoint with a timestamp at each step.
     * 2. If not saved lasttimestamp, we calculate the 2 points: Start and End Point (AKA starting point and ending point where the step has ended)
     * 3. Hence, this function needs the initial timestamp which is the creationTimestamp which logs the timestamp at the point where the user is created on the map.
     * 4. When the function is called again, if last timestamp is saved, creationTimestamp is not use.
     *
     * Example:
     * Step 0 - creationTimestamp
     * Step 1 - Timestamp of Step 1 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 1 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 2 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 2 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 3 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 3 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 4 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 4 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Where Step 2 is where user stopped.
     *
     * Calculate the RTT mean between at Step 0 and RTT Mean at Step 1 to 2.
     * Get the CoordinatePoint, with the RTT Mean an put into Thu's PointVal.
     *
     * Similarly, if user stopped at Step 2 and walk again to Step 4.
     * Calculated 2 Points are now would be Step 1-2 and Step 3-4
     * Hence, if the user continue, last saved step is now Step 3-4.
     *
     * Why?:
     * 1. This function interfaces with Thu's PointVal class which is later used in the DrawSB1Fragment to generate the MASK for drawing the heatmap.
     * 2. The PointVal is then used for Hai's directionGuidance() function.
     */
    fun thusPointValGenerator2Points(
        selectedAP: String,
        creationTimestamp: Long,
        scanResultHashMap: HashMap<Long, MutableList<RangingResult>>
    ): MutableList<PointVal> {

        //  2025 Aug 28: Hai's recommend to try the 2 point approach first. Capture 2 points and recommend the target position.

        //  Init
        val listOfPointVal: MutableList<PointVal> = arrayListOf()
        var totalDistance = 0
        var count = 0
        var meanDistance: Double
        var coordinatePoint: CoordinatePoint? = null
        var coordinatePoint2: CoordinatePoint? = null

        if (stepIndexTimestampHashMap.isEmpty()) {
            Log.e(classTAG, "stepIndexTimestampHashMap is empty! Returning empty listOfPointVal.")
            return listOfPointVal
        }

        //  Sorted the Step-Index timestamp Hashmap: This stores the timestamp at each step.
        val keyset = stepIndexTimestampHashMap.keys.sorted()
        val setSize = keyset.size

        //  =================================================================
        //  1st Point: CreationTimestamp Point to the Timestamp of First Step
        //  =================================================================

        //  Check if we have saved last timestamp.
        if (lastDirectionalGuidanceTimestamp1 == 0L && lastDirectionalGuidanceTimestamp2 == 0L) {

            //  Get timestamp of first step
            val firstStepTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[0])
            if (firstStepTimestamp != null) {

                //  If No last entries saved, use the CreationTimestamp
                val sortedTimestamps = scanResultHashMap.keys.sorted()
                for (eachTimestamp in sortedTimestamps) {

                    //  Get data between creationTimestamp to first-step timestamp.
                    if ((eachTimestamp >= creationTimestamp) && (eachTimestamp <= firstStepTimestamp)) {

                        val scanResultData: MutableList<RangingResult>? = scanResultHashMap.get(eachTimestamp)
                        if (scanResultData != null) {
                            for (eachScanResult in scanResultData) {

                                if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {

                                    Log.i(classTAG, "scanResultData is ok")

                                    //val refMacAddress = eachScanResult.macAddress.toString().substring(0, 14)
                                    //val valSelectedAP = selectedAP.substring(0, 14)

                                    val refMacAddress = eachScanResult.macAddress.toString()
                                    val valSelectedAP = selectedAP

                                    if (valSelectedAP.compareTo(refMacAddress) == 0) {
                                        totalDistance += eachScanResult.distanceMm / 1000
                                        count++

                                        coordinatePoint = captureCoordPointHashmap.get(creationTimestamp)
                                    }
                                } else
                                    Log.e(classTAG, "scanResultData is bad")
                            }
                        } else
                            Log.e(classTAG, "scanResultData is empty")
                    }
                }

                //  Only calculate the mean, if CoordinatePoint is loaded and count is non zero.
                if (coordinatePoint != null && count != 0) {
                    //  Get Mean (if count is zero, we are going to get divide by zero error)
                    meanDistance = totalDistance / count.toDouble()

                    //  We have mean, coordinate point, we create the PointVal and store it.
                    val pointVal = PointVal(coordinatePoint.x, coordinatePoint.y, meanDistance)
                    listOfPointVal.add(pointVal)

                    //  Store to cumulative List to store all
                    cumlativeListOfPointVal.add(pointVal)
                }
            } else {
                Log.e(classTAG, "No Step Data yet. Returning empty listOfPointVal.")
                return listOfPointVal
            }

        } else {

            //  Load the last saved PointVal
            listOfPointVal.add(lastPointVal)
        }

        //  ================================
        //  2nd Point: Always the last Step.
        //  ================================

        val secondToLast = 2

        if (listOfPointVal.isNotEmpty() && (setSize > secondToLast)) {

            //  Get the last 2 timestamp
            val lastTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[setSize - 1])
            val secondTolastTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[setSize - secondToLast])

            Log.i(classTAG, "Size of Step Data Holder: ${stepIndexTimestampHashMap.size}")
            Log.i(classTAG, "creationTimestamp: $creationTimestamp")
            Log.i(classTAG, "lastTimestamp: $lastTimestamp")
            Log.i(classTAG, "secondTolastTimestamp: $secondTolastTimestamp")

            if (lastTimestamp != null && secondTolastTimestamp != null) {

                //  Debug
                //Log.i(classTAG, "timestamp not null")
                if ((lastTimestamp > secondTolastTimestamp) && (secondTolastTimestamp > creationTimestamp))
                    Log.i(classTAG, "All timestamps are in order.")

                //  Timestamp must be bigger than the creationTimestamp. Meaning: it cannot be eariler than the 1st point.
                if (lastTimestamp > creationTimestamp && secondTolastTimestamp > creationTimestamp) {

//                //  Timestamp must be bigger than the last point (if any).
//                //  Meaning: If there is a last point saved, the current last point must be bigger than the last point saved.
//                if ((lastDirectionalGuidanceTimestamp1 != 0L && lastTimestamp > lastDirectionalGuidanceTimestamp1)
//                    && (lastDirectionalGuidanceTimestamp2 != 0L && secondTolastTimestamp > lastDirectionalGuidanceTimestamp2)
//                ) {
//
//                }
                    Log.i(classTAG, "Within timestamp")

                    totalDistance = 0
                    count = 0

                    //  Sort the ScanResult in order of their timestamp
                    val sortedTimestamps = scanResultHashMap.keys.sorted()

                    //  DEBUG: Check if any of scanresult timestamp is within the step timesstamp
                    var scanTimestampValidFlag = false
                    for (eachTimestamp in sortedTimestamps) {

                        if ((eachTimestamp > secondTolastTimestamp) && (eachTimestamp < lastTimestamp)) {
                            scanTimestampValidFlag = true
                            Log.i(classTAG, "valid eachTimestamp: $eachTimestamp")
                            break
                        }
                        //Log.i(classTAG, "eachTimestamp: $eachTimestamp")
                    }

                    if (scanTimestampValidFlag)
                        Log.i(classTAG, "Valid scanResult timestamp found within Step timestamp")
                    else
                        Log.e(classTAG, "No Valid scanResult timestamp found within Step timestamp")

                    for (eachTimestamp in sortedTimestamps) {

                        if ((eachTimestamp > secondTolastTimestamp) && (eachTimestamp < lastTimestamp)) {

                            val scanResultData: MutableList<RangingResult>? = scanResultHashMap.get(eachTimestamp)
                            if (scanResultData != null) {
                                for (eachScanResult in scanResultData) {
                                    if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {

                                        //  Old code check 5 out of 6 of BSSID HexDec (Remove if no longer needed in the future)
                                        //val refMacAddress = eachScanResult.macAddress.toString().substring(0, 14)
                                        //val valSelectedAP = selectedAP.substring(0, 14)

                                        val refMacAddress = eachScanResult.macAddress.toString()
                                        val valSelectedAP = selectedAP

                                        Log.i(classTAG, "Checking MAC Prefix: $refMacAddress against $valSelectedAP")

                                        if (valSelectedAP.compareTo(refMacAddress) == 0) {
                                            Log.i(classTAG, "found mac: ${eachScanResult.macAddress}, distance=${eachScanResult.distanceMm / 1000}")

                                            totalDistance += eachScanResult.distanceMm / 1000
                                            count++

                                            coordinatePoint2 = captureCoordPointHashmap.get(eachTimestamp)
                                        }
                                    } else
                                        Log.e(classTAG, "No using ScanResult because Range Result is bad.")
                                }
                            } else
                                Log.e(classTAG, "scanResultData is empty")
                        } else
                            Log.e(classTAG, "Not within time! eachTimestamp: $eachTimestamp")
                    }

                    //  Only calculate the mean, if CoordinatePoint is loaded and count is non zero.
                    if (coordinatePoint2 != null && count != 0) {
                        //  Get Mean (if count is zero, we are going to get divide by zero error)
                        meanDistance = totalDistance / count.toDouble()

                        //  We have mean, coordinate point, we create the PointVal and store it.
                        val pointVal = PointVal(coordinatePoint2.x, coordinatePoint2.y, meanDistance)
                        listOfPointVal.add(pointVal)

                        //  Save the last 2 timestamp, for next iteration
                        lastDirectionalGuidanceTimestamp1 = lastTimestamp
                        lastDirectionalGuidanceTimestamp2 = secondTolastTimestamp
                        lastPointVal = pointVal

                        //  Store to cumulative List to store all
                        cumlativeListOfPointVal.add(pointVal)
                    }
                }
            }
        } else
            Log.e(classTAG, "Not enough steps for last point.")

        return listOfPointVal
    }


    //  TODO
    fun thusPointValPerStep(
        selectedBSSID: String,
        stepIndex: Long,
        creationTimestamp: Long,
        hashmapTimestampToListOfRangeResult: HashMap<Long, MutableList<RangingResult>>
    ): MutableList<PointVal> {

        //  Init
        val emptyListOfPointVal: MutableList<PointVal> = arrayListOf()

        //  ============================
        //  Data check before processing
        //  ============================

        if (hashmapTimestampToListOfRangeResult.isEmpty()) {
            Log.e(classTAG, "hashmapTimestampToListOfRangeResult is empty! Returning empty listOfPointVal.")
            return emptyListOfPointVal
        }

        if (stepIndexTimestampHashMap.isEmpty()) {
            Log.e(classTAG, "stepIndexTimestampHashMap is empty! Returning empty listOfPointVal.")
            return emptyListOfPointVal
        }

        //  Sorted the Step-Index timestamp Hashmap: This stores the timestamp at each step.
        val keyset = stepIndexTimestampHashMap.keys.sorted()
        val setSize = keyset.size

        //  Load from the holder is BSSID's copy exist.
        var localCumulativeSetOfPointVal: MutableSet<PointVal> = mutableSetOf()
        if (hashMapBSSIDtoCumulativeSetOfPointVal.isNotEmpty()) {
            if (hashMapBSSIDtoCumulativeSetOfPointVal.containsKey(selectedBSSID)) {
                val copyOfCumulativeSetOfPointVal = hashMapBSSIDtoCumulativeSetOfPointVal.get(selectedBSSID)
                if (copyOfCumulativeSetOfPointVal != null)
                    localCumulativeSetOfPointVal = copyOfCumulativeSetOfPointVal
            }
        }


        //  =================================================================
        //  1st Point: CreationTimestamp Point to the Timestamp of First Step
        //  =================================================================

        //  Check if we have saved last timestamp.
        if (localCumulativeSetOfPointVal.isEmpty() && lastDirectionalGuidanceTimestamp1 == 0L && lastDirectionalGuidanceTimestamp2 == 0L) {

            //  Get timestamp of first step
            val firstStepTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[0])
            if (firstStepTimestamp != null) {

                val pointValWithinTimestamp = getPointVal(
                    selectedBSSID,
                    creationTimestamp,
                    firstStepTimestamp,
                    hashmapTimestampToListOfRangeResult
                )
                if (pointValWithinTimestamp == null) {
                    Log.e(classTAG, "No Step Data within creationTimestamp-Timestamp to firstStepTimestamp-Timestamp. Returning empty listOfPointVal.")
                    return emptyListOfPointVal
                } else {
                    //  Store to cumulative List to store all
                    //cumlativeListOfPointVal.add(pointValWithinTimestamp)
                    localCumulativeSetOfPointVal.add(pointValWithinTimestamp)
                }

            } else {
                Log.e(classTAG, "No Step Data yet. Returning empty listOfPointVal.")
                return emptyListOfPointVal
            }
        }

        //  ================================
        //  2nd Point: Always the last Step.
        //  ================================

        val secondToLast = 2

        if (localCumulativeSetOfPointVal.isNotEmpty() && (setSize > secondToLast)) {

            //  Get the last 2 timestamp from the step timestamp
            val lastTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[setSize - 1])
            val secondTolastTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[setSize - secondToLast])

            Log.i(classTAG, "Size of Step Data Holder: ${stepIndexTimestampHashMap.size}")
            Log.i(classTAG, "creationTimestamp: $creationTimestamp")
            Log.i(classTAG, "lastTimestamp: $lastTimestamp")
            Log.i(classTAG, "secondTolastTimestamp: $secondTolastTimestamp")

            if (lastTimestamp != null && secondTolastTimestamp != null) {

                if ((lastTimestamp > secondTolastTimestamp) && (secondTolastTimestamp > creationTimestamp))
                    Log.i(classTAG, "All timestamps are in order.")

                //  Timestamp must be bigger than the creationTimestamp. Meaning: it cannot be earlier than the 1st point.
                if (lastTimestamp > creationTimestamp && secondTolastTimestamp > creationTimestamp) {

                    Log.i(classTAG, "Within timestamp")

                    val pointValWithinTimestamp = getPointVal(
                        selectedBSSID,
                        secondTolastTimestamp,
                        lastTimestamp,
                        hashmapTimestampToListOfRangeResult
                    )
                    if (pointValWithinTimestamp == null) {
                        Log.e(classTAG, "No Step Data within SecondLastStep-Timestamp to LastStep-Timestamp. Returning empty listOfPointVal.")
                        return emptyListOfPointVal
                    } else {
                        //  Save the last 2 timestamp, for next iteration
                        lastDirectionalGuidanceTimestamp1 = lastTimestamp
                        lastDirectionalGuidanceTimestamp2 = secondTolastTimestamp
                        lastPointVal = pointValWithinTimestamp

                        //  Store to cumulative List to store all
                        //cumlativeListOfPointVal.add(pointValWithinTimestamp)
                        localCumulativeSetOfPointVal.add(pointValWithinTimestamp)
                    }
                }
            } else {
                Log.e(classTAG, "No timestamp for lastTimestamp and secondTolastTimestamp.  Returning empty listOfPointVal.")
                return emptyListOfPointVal
            }
        } else {
            Log.e(classTAG, "Not enough steps for last point. Returning empty listOfPointVal.")
            return emptyListOfPointVal
        }

        //  Store back.
        hashMapBSSIDtoCumulativeSetOfPointVal[selectedBSSID] = localCumulativeSetOfPointVal

        return localCumulativeSetOfPointVal.toList() as MutableList<PointVal>
    }

    /**
     * Generate cumulative set of PointVal (to the point the user moved)
     *
     * Each PointVal contains the X, Y position as well as the Mean of RTT Distance value at that position (at a specific time period).
     *
     * To generate all PointVal, use the captured CoordPointHashmap where:
     * 1. we captured each CoordinatePoint with a timestamp at each step.
     * 2. The the cumulative holder is empty, the first point is the point defined as the period (Creation-Timestamp to the timestamp of the 1st step)
     * 3. If the cumulative holder is not empty, we will be capturing the the point defined as the period (2nd to last timestamp to the last timestamp of the last step)
     * 4. Hence, for next iteration, if the cumulative holder is not empty, we will repeating step 2, capturing the PointVal of the last step.
     * 5. Hence, this function needs the initial timestamp which is the creationTimestamp which logs the timestamp at the point where the user is created on the map.
     * 6. When the function is called again, if last timestamp is saved, creationTimestamp is not use.
     *
     * Example:
     * Step 0 - creationTimestamp
     * Step 1 - Timestamp of Step 1 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 1 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 2 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 2 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 3 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 3 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 4 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 4 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Where Step 2 is where user stopped.
     *
     * Calculate the RTT mean between at Step 0 and RTT Mean at Step 1.
     * Get the CoordinatePoint, with the RTT Mean an put into Thu's PointVal.
     *
     * Similarly, if user stopped at Step 2 and walk again to Step 4.
     * Calculated 2 Points are now would be Step 1-2 and Step 3-4
     * Hence, if the user continue, last saved step is now Step 3-4.
     *
     * Why?:
     * 1. This function interfaces with Thu's PointVal class which is later used in the DrawSB1Fragment to generate the MASK for drawing the heatmap.
     * 2. The PointVal is then used for Hai's directionGuidance() function.
     */
    fun thusPointValGeneratorCumulativePoints(
        selectedBSSID: String,
        creationTimestamp: Long,
        hashmapTimestampToListOfRangeResult: HashMap<Long, MutableList<RangingResult>>
    ): MutableList<PointVal> {

        //  Init
        val emptyListOfPointVal: MutableList<PointVal> = arrayListOf()

        //  ============================
        //  Data check before processing
        //  ============================

        if (hashmapTimestampToListOfRangeResult.isEmpty()) {
            Log.e(classTAG, "hashmapTimestampToListOfRangeResult is empty! Returning empty listOfPointVal.")
            return emptyListOfPointVal
        }

        if (stepIndexTimestampHashMap.isEmpty()) {
            Log.e(classTAG, "stepIndexTimestampHashMap is empty! Returning empty listOfPointVal.")
            return emptyListOfPointVal
        }

        //  Sorted the Step-Index timestamp Hashmap: This stores the timestamp at each step.
        val keyset = stepIndexTimestampHashMap.keys.sorted()
        val setSize = keyset.size

        //  Load from the holder is BSSID's copy exist.
        var localCumulativeSetOfPointVal: MutableSet<PointVal> = mutableSetOf()
        if (hashMapBSSIDtoCumulativeSetOfPointVal.isNotEmpty()) {
            if (hashMapBSSIDtoCumulativeSetOfPointVal.containsKey(selectedBSSID)) {
                val copyOfCumulativeSetOfPointVal = hashMapBSSIDtoCumulativeSetOfPointVal.get(selectedBSSID)
                if (copyOfCumulativeSetOfPointVal != null)
                    localCumulativeSetOfPointVal = copyOfCumulativeSetOfPointVal
            }
        }


        //  =================================================================
        //  1st Point: CreationTimestamp Point to the Timestamp of First Step
        //  =================================================================

        //  Check if we have saved last timestamp.
        if (localCumulativeSetOfPointVal.isEmpty() && lastDirectionalGuidanceTimestamp1 == 0L && lastDirectionalGuidanceTimestamp2 == 0L) {

            //  Get timestamp of first step
            val firstStepTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[0])
            if (firstStepTimestamp != null) {

                val pointValWithinTimestamp = getPointVal(
                    selectedBSSID,
                    creationTimestamp,
                    firstStepTimestamp,
                    hashmapTimestampToListOfRangeResult)

                if (pointValWithinTimestamp.x==9999.9999 &&
                    pointValWithinTimestamp.y==9999.9999 &&
                    pointValWithinTimestamp.meanRTTDistance == -1.0) {
                    Log.e(classTAG, "No Step Data within creationTimestamp-Timestamp to firstStepTimestamp-Timestamp. Returning empty listOfPointVal.")
                    return emptyListOfPointVal
                } else {
                    //  Store to cumulative List to store all
                    //cumlativeListOfPointVal.add(pointValWithinTimestamp)
                    localCumulativeSetOfPointVal.add(pointValWithinTimestamp)
                }

            } else {
                Log.e(classTAG, "No Step Data yet. Returning empty listOfPointVal.")
                return emptyListOfPointVal
            }
        }

        //  ================================
        //  2nd Point: Always the last Step.
        //  ================================

        val secondToLast = 2

        if (localCumulativeSetOfPointVal.isNotEmpty() && (setSize > secondToLast)) {

            //  Get the last 2 timestamp from the step timestamp
            val lastTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[setSize - 1])
            val secondTolastTimestamp: Long? = stepIndexTimestampHashMap.get(keyset[setSize - secondToLast])

            Log.i(classTAG, "Size of Step Data Holder: ${stepIndexTimestampHashMap.size}")
            Log.i(classTAG, "creationTimestamp: $creationTimestamp")
            Log.i(classTAG, "lastTimestamp: $lastTimestamp")
            Log.i(classTAG, "secondTolastTimestamp: $secondTolastTimestamp")

            if (lastTimestamp != null && secondTolastTimestamp != null) {

                if ((lastTimestamp > secondTolastTimestamp) && (secondTolastTimestamp > creationTimestamp))
                    Log.i(classTAG, "All timestamps are in order.")

                //  Timestamp must be bigger than the creationTimestamp. Meaning: it cannot be earlier than the 1st point.
                if (lastTimestamp > creationTimestamp && secondTolastTimestamp > creationTimestamp) {

                    Log.i(classTAG, "Within timestamp")

                    val pointValWithinTimestamp = getPointVal(
                        selectedBSSID,
                        secondTolastTimestamp,
                        lastTimestamp,
                        hashmapTimestampToListOfRangeResult)

                    if (pointValWithinTimestamp.x==9999.9999 &&
                        pointValWithinTimestamp.y==9999.9999 &&
                        pointValWithinTimestamp.meanRTTDistance == -1.0) {
                        Log.e(classTAG, "No Step Data within SecondLastStep-Timestamp to LastStep-Timestamp. Returning empty listOfPointVal.")
                        return emptyListOfPointVal
                    } else {
                        //  Save the last 2 timestamp, for next iteration
                        lastDirectionalGuidanceTimestamp1 = lastTimestamp
                        lastDirectionalGuidanceTimestamp2 = secondTolastTimestamp
                        lastPointVal = pointValWithinTimestamp

                        //  Store to cumulative List to store all
                        //cumlativeListOfPointVal.add(pointValWithinTimestamp)
                        localCumulativeSetOfPointVal.add(pointValWithinTimestamp)
                    }
                }
            } else {
                Log.e(classTAG, "No timestamp for lastTimestamp and secondTolastTimestamp.  Returning empty listOfPointVal.")
                return emptyListOfPointVal
            }
        } else {
            Log.e(classTAG, "Not enough steps for last point. Returning empty listOfPointVal.")
            return emptyListOfPointVal
        }

        //  Store back.
        hashMapBSSIDtoCumulativeSetOfPointVal[selectedBSSID] = localCumulativeSetOfPointVal

        return localCumulativeSetOfPointVal.toList() as MutableList<PointVal>
    }

    /**
     * Get PointVal
     *
     * Given:
     * 1. selectedAP - The selected AP
     * 2. Start Time - startTimestamp
     * 3. End Time - endTimestamp
     * 4. The RTT Range Result - scanResultHashMap
     *
     * Get PointVal where each represents a X,Y location with the mean RTT distance between the start to end timestamp from the captured RTT range result.
     */
    fun getPointVal(
        selectedBSSID: String,
        startTimestamp: Long,
        endTimestamp: Long,
        hashMapTimestampToRangeResultList: HashMap<Long, MutableList<RangingResult>>
    ): PointVal {

        //  Init
        var meanDistance: Double
        var meanRSSI: Double

        var totalDistance = 0
        var totalRSSI = 0
        var count = 0

        var coordinatePoint: CoordinatePoint? = null

        //  Sort the ScanResult in order of their timestamp
        val sortedTimestamps = hashMapTimestampToRangeResultList.keys.sorted()
        for (eachTimestamp in sortedTimestamps) {

            //  Only process data that is within the start and end timestamp
            if ((eachTimestamp >= startTimestamp) && (eachTimestamp <= endTimestamp)) {

                //  Get the RTT Range result from the valid timestamp
                val scanResultData: MutableList<RangingResult>? = hashMapTimestampToRangeResultList.get(eachTimestamp)
                if (scanResultData != null) {

                    //  In each scanResultData might contain multiple BSSID range result.
                    //  Hence, we have to search through
                    for (eachScanResult in scanResultData) {

                        //  Check if the range result is success first.
                        if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {

                            // Log.i(classTAG, "Checking MAC Prefix: ${eachScanResult.macAddress.toString()} against $selectedAP")

                            //  Check if the Range BSSID matches the selected-BSSID we have chosen to test against.
                            if (selectedBSSID.compareTo(eachScanResult.macAddress.toString()) == 0) {

                                Log.i(classTAG, "Found mac: ${eachScanResult.macAddress}, distance=${eachScanResult.distanceMm / 1000}")

                                //  Store and add (to calculate the mean distance)
                                totalDistance += eachScanResult.distanceMm / 1000
                                totalRSSI += eachScanResult.rssi
                                count++
                            }
                        } else
                            Log.e(classTAG, "No using ScanResult because Range Result is bad.")
                    }
                } else
                    Log.e(classTAG, "scanResultData is empty. No RTT Range Data capture (yet).")

                //  Extract Coordinate at this valid timestamp and valid selected-BSSID
                coordinatePoint = captureCoordPointHashmap[eachTimestamp]

            } else
                Log.e(classTAG, "Not within time! eachTimestamp: $eachTimestamp")
        }

        //  Only calculate the mean, if CoordinatePoint is loaded and count is non zero.
        if (coordinatePoint != null) {

            if (count == 0) {
                val pointVal = PointVal(selectedBSSID, coordinatePoint.x, coordinatePoint.y, -1.0, 9999.9999)
                return pointVal
            } else {
                //  Get Mean (if count is zero, we are going to get divide by zero error)
                meanDistance = totalDistance / count.toDouble()
                meanRSSI = totalRSSI / count.toDouble()

                //  We have mean, coordinate point, we create the PointVal and store it.
                val pointVal = PointVal(selectedBSSID, coordinatePoint.x, coordinatePoint.y, meanDistance, meanRSSI)
                return pointVal
            }
        } else {
            Log.e(classTAG, "No Step Data within Start-Timestamp to End-Timestamp. Returning empty listOfPointVal.")

            val pointVal = PointVal(selectedBSSID, 9999.9999, 9999.9999, -1.0, 9999.9999)
            return pointVal
        }
    }

    /**
     * Generate cumulative set of PointVal (to the point the user moved)
     *
     * Each PointVal contains the X, Y position as well as the Mean of RTT Distance value at that position (at a specific time period).
     *
     * To generate all PointVal, use the captured CoordPointHashmap where:
     * 1. we captured each CoordinatePoint with a timestamp at each step.
     * 2. The the cumulative holder is empty, the first point is the point defined as the period (Creation-Timestamp to the timestamp of the 1st step)
     * 3. If the cumulative holder is not empty, we will be capturing the the point defined as the period (2nd to last timestamp to the last timestamp of the last step)
     * 4. Hence, for next iteration, if the cumulative holder is not empty, we will repeating step 2, capturing the PointVal of the last step.
     * 5. Hence, this function needs the initial timestamp which is the creationTimestamp which logs the timestamp at the point where the user is created on the map.
     * 6. When the function is called again, if last timestamp is saved, creationTimestamp is not use.
     *
     * Example:
     * Step 0 - creationTimestamp
     * Step 1 - Timestamp of Step 1 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 1 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 2 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 2 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 3 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 3 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Step 4 - Timestamp of Step 2 (inside stepIndexTimestampHashMap) - with RTT Scan Results. Same Step 4 timestamp also captures the CoordinatePoint (inside captureCoordPointHashmap)
     * Where Step 2 is where user stopped.
     *
     * Calculate the RTT mean between at Step 0 and RTT Mean at Step 1.
     * Get the CoordinatePoint, with the RTT Mean an put into Thu's PointVal.
     *
     * Similarly, if user stopped at Step 2 and walk again to Step 4.
     * Calculated 2 Points are now would be Step 1-2 and Step 3-4
     * Hence, if the user continue, last saved step is now Step 3-4.
     *
     * Why?:
     * 1. This function interfaces with Thu's PointVal class which is later used in the DrawSB1Fragment to generate the MASK for drawing the heatmap.
     * 2. The PointVal is then used for Hai's directionGuidance() function.
     */
    fun thusPointValGeneratorCumulativePointsOld(
        selectedAP: String,
        creationTimestamp: Long,
        scanResultHashMap: HashMap<Long, MutableList<RangingResult>>
    ): MutableList<PointVal> {

        //  Same function call but we are returning all instead of just 2 points
        if (!scanResultHashMap.isEmpty())
            thusPointValGenerator2Points(selectedAP, creationTimestamp, scanResultHashMap)

        return cumlativeListOfPointVal
    }

    /**
     * (Hai' Research component)
     *
     * Interfacing Function between Kotlin-Java
     *
     * listOfPointVal: MutableList<PointVal> - Calculated from thusPointValGenerator2Points() function.
     * Where the list of PointVal has only 2 points. Either Start Point and End Point OR the Last saved Point and the End Point.
     * Last Saved Point is the saved End Point during the previous calculation.
     */
    fun directionGuidance(listOfPointVal: MutableList<PointVal>): CoordinatePoint? {

        var coordinatePoint: CoordinatePoint? = null

        //  With the PointVal, calculate
        if (!listOfPointVal.isEmpty()) {

            var sizeOfEntry = listOfPointVal.size
            var x_points = DoubleArray(sizeOfEntry)
            var y_points = DoubleArray(sizeOfEntry)
            var rtt_points = DoubleArray(sizeOfEntry)

            var counter = 0
            for (eachPointVal in listOfPointVal) {
                x_points[counter] = eachPointVal.x
                y_points[counter] = eachPointVal.y
                rtt_points[counter] = eachPointVal.meanRTTDistance
                counter++

                Log.i(classTAG, "Submitted. X: ${eachPointVal.x}, Y: ${eachPointVal.y}, value: ${eachPointVal.meanRTTDistance}")
            }

            coordinatePoint = PointSuggestion.suggestNextPointVer2(sizeOfEntry, x_points, y_points, rtt_points, 3.8)

            if (coordinatePoint != null)
                Log.i(classTAG, "directionGuidance X: ${coordinatePoint.x}, Y: ${coordinatePoint.y}")
            else
                Log.i(classTAG, "coordinatePoint is null")

            return coordinatePoint
        }

        Log.e(classTAG, "directionGuidance istOfPointVal is empty")
        return CoordinatePoint(0.0, 0.0)
    }
}