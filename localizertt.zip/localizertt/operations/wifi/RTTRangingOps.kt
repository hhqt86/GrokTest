package sg.edu.smu.teamrtt.localizertt.operations.wifi

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.RangingResult
import android.net.wifi.rtt.WifiRttManager
import android.util.Log
import sg.edu.smu.teamrtt.localizertt.model.dataview.RTTDetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.model.dataview.WiFiScanDataViewModel
import sg.edu.smu.teamrtt.localizertt.operations.wifi.callback.RTTRangeResultCallback
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.RSSI_FILTER
import java.util.concurrent.Executor

/**
 * WiFi RTT Scanning Operation Class
 *
 * What this does:
 * 1. Store the AP Scan result
 * 2. Filter the AP Scan result based on RSSI, channel and channel width.
 * 3. Invokes the RTT Scan of all available APs
 * 4. As RTT scan has Max Peer Limits (only can certain number of APs at one time)
 * 5. This class chunks the list of available APs into the limit and RTT scan them in chunks
 * 6. So that ALL APs are scanned.
 * 7. Once scanned, Updates the respective ViewModels such that the corresponding UI are updated accordingly.
 *
 * Ref:
 *  https://developer.android.com/develop/connectivity/wifi/wifi-scan
 *  https://developer.android.com/develop/connectivity/wifi/wifi-rtt#:~:text=Wi%2DFi%20RTT%20was%20introduced,store%20and%20retrieve%20this%20data.
 *
 * @author William Tan. 2025 Jan 17.
 */
class RTTRangingOps(
    val mainActivityContext: Context,
    private val wifiManager: WifiManager,
    val wifiRttManager: WifiRttManager,
    private val wifiScanDataViewModel: WiFiScanDataViewModel,
    val rttDetailsViewModel: RTTDetailsDataViewModel
) {

    /**
     * TAG for Logging
     */
    private val classTAG = this.javaClass.name

    /**
     * Hardcoded AP MAC For Testing Only. (To be remove in Production)
     * Set to False to turn off, hardcoded AP MAC
     *
     * Default= false
     */
    val flagUseHardcodedAPMACIndexMap = true

    /**
     * Hardcoded AP List for testing purpose. (To be remove in Production)
     */
    private val mutableHardcodedAPMACIndexMap = mutableMapOf<String, Int>()

    /**
     *  Current List of ScanResult from the AP
     *  (Sorted descending in order of RSSI)
     */
    private var currentScanResult: List<ScanResult> = emptyList()

    /**
     *  All collected scanResult seen throughout the app is active.
     *  (Sorted descending in order of RSSI)
     */
    private var allFilteredScanResult: List<ScanResult> = emptyList()

    /**
     *
     */
    private var storeFlag: Boolean = false

    /**
     * RSSI Filter
     *
     * Extracted from the App's preferences store in DataStore.
     * Used to filter away BSSID that is below this filter level and keep only those above this leve.
     */
    private var filterRSSILevel: Int = RSSI_FILTER.toInt()

    /**
     * List of RTT scan results of all APs
     */
    var scanRTTResultHolder: MutableList<RangingResult> = mutableListOf()

    /**
     * Range Request Counter
     * Tracks the index of listOfReq when calling each RangeRequest one by one.
     */
    var requestCounter: Int = 0

    /**
     * List of RangingRequest which will be called one by one.
     */
    var listOfReq = mutableListOf<RangingRequest>()

    /**
     * RTT Scan is Free Flag
     * True indicates that RTT ranging is available.
     * False indicates that the previous RTT ranging is still going on. Wait until Flag becomes True.
     */
    var rttScanIsFreeFlag: Boolean = true

    /**
     * Executor to run separately task
     */
    var mainExecutor: Executor? = null

    /**
     * Init for this class.
     *
     * Doe the following:
     * 1. Obtain the RSSI level to filter BSSID.
     */
    init {
        //  Obtain the RSSI Level to filter BSSID for RTT Scan.
        filterRSSILevel = AppPrefStore(mainActivityContext).loadRSSIFilter()
    }

    /**
     * Add to list of Hardcoded AP
     */
    fun addToHardcodedAP(bssidData: String, indexData: Int) {
        allFilteredScanResult = emptyList()
        mutableHardcodedAPMACIndexMap.clear()
        mutableHardcodedAPMACIndexMap[bssidData] = indexData
    }

    /**
     *  Store the AP Scan Results
     *
     *  This is initiated in MainActivity and is triggered from the WiFiScanBCR.
     *
     *  Does the following:
     *  1. Sort the result (via RSSI) and store the result.
     *  2. Extract the result for the UI for displaying to the user
     *  3. Call filterSelectBestBSSIDForRTT() function to select the best BSSID for RTT Scan. (See the function for details.)
     */
    @SuppressLint("MissingPermission")  //  William: I suppressed Missing Permission, as the check already performed on MainActivty, so no idea why Android Studio kept prompting this.
    fun storeScanResults() {

        //  Obtain the wifi scan result
        val scanResult: List<ScanResult> = wifiManager.scanResults

        //  Sort by RSSI strength and store.
        currentScanResult = scanResult.sortedByDescending { it.level }

        //  Update view models. i.e. Such that other parts like UI Fragments can use it.
        updateViewModels()

        //  Filter and select the best BSSID for RTT scan
        filterSelectBestBSSIDForRTT()
    }

    /**
     * Update the View Models
     *
     * 1. Extract the relevant data from the WiFi scan.
     * 2. Push to ViewModels.
     * 3. Such that other parts such as UI Fragment can get updated with the scan results.
     */
    private fun updateViewModels() {

        //  List of SSID for UI, In format BSSID, SSID, RSSI. Eg: 94:43:F3:2A:30:2F, WLAN-SMU, -52, 5210
        var reformattedListOfSSID = emptyArray<String>()

        //  Generate list of scan result
        for (eachScan in currentScanResult) {

            //  Channel width check
            //            if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_20MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_20MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_40MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_40MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_80MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_80MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_160MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_160MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_320MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_320MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ) {
            //                Log.i("classTAG, "CHANNEL_WIDTH_80MHZ_PLUS_MHZ")
            //            }
            //            else {
            //                Log.i(classTAG, "CHANNEL_UNKNOWN")
            //            }

            //  Find the frequency of the channel
            val channelFreq: Int = if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_20MHZ)
                eachScan.frequency
            else
                eachScan.centerFreq0

            if (eachScan.channelWidth != ScanResult.CHANNEL_WIDTH_20MHZ &&
                channelFreq >= 5000
                && eachScan.level >= filterRSSILevel
            ) {
                reformattedListOfSSID += eachScan.BSSID + ", " + eachScan.SSID + ", " + eachScan.level + ", " + channelFreq
            }

            //reformattedListOfSSID += eachScan.BSSID + ", " + eachScan.SSID + ", " + eachScan.level + ", " + channelFreq
        }

        //  Update the view models. E.g. For UI
        wifiScanDataViewModel.setListOfSSID(reformattedListOfSSID)
    }

    /**
     * Given ScanResult, filter and select the best set of BSSID for RTT scan
     *
     * Executed during storeScanResults() function call then use for RTT scan.
     *  - - Filter BSSID before RTT using widest channel in 5GH range for BSSID check
     *
     * Returns set of selected ScanResult tag with timestamp
     *
     * Ref: https://developer.android.com/reference/android/net/wifi/ScanResult
     * @author William Tan 2025 Mar 07.
     */
    private fun filterSelectBestBSSIDForRTT() {

        //  Filter only if scan result is available.
        if (currentScanResult.isNotEmpty()) {

            //  Reload the filter level if there was any changes by the user in the config(UI) fragment.
            filterRSSILevel = AppPrefStore(mainActivityContext).loadRSSIFilter()

            //  Init empty Best Picked ScanResult
            var bestPickedScanResult: MutableList<ScanResult> = mutableListOf()

            //  Step 1: Filter away based on Channel (5GHz), RSSI and bandwidth (above 20Mhz)
            //  Iterate through the current scan result
            for (eachScan in currentScanResult) {

                //  Find the frequency of the channel
                val channelFreq: Int = if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_20MHZ)
                    eachScan.frequency
                else
                    eachScan.centerFreq0

                //  We are only interested in the 5GHz band & More than 20Mhz bandwidth with a threshold RSSI (set in config: Default -70dBm)
                if (eachScan.channelWidth != ScanResult.CHANNEL_WIDTH_20MHZ &&
                    channelFreq >= 5000
                    && eachScan.level >= filterRSSILevel
                ) {
                    //Log.i(TAG, "Picked: $eachScan")
                    bestPickedScanResult += eachScan

//                    if (bestPickedScanResult.isEmpty()) {
//                        //  Add to list if empty
//                        bestPickedScanResult += eachScan
//                    } else {
//                        //  If not empty, update the list with each scan result
//                        bestPickedScanResult = checkScanResultIsBetter(bestPickedScanResult, eachScan)
//                    }
                }
            }

            //  Step 1A: Hardcoded Filter (to be remove in production)
            if (bestPickedScanResult.isNotEmpty() && flagUseHardcodedAPMACIndexMap) {
                //bestPickedScanResult = filterOnlyHardcodedAP(bestPickedScanResult, hardcodedAPMACIndexMap)
                bestPickedScanResult = filterOnlyHardcodedAP(bestPickedScanResult, mutableHardcodedAPMACIndexMap)
            }

            //  Step 2: Add to existing Filtered list (of previously scanned filtered result, as the user might be moving about)
            //  At the end, if results are not empty, sort and save to filter result
            if (bestPickedScanResult.isNotEmpty()) {

                //  Sort and Store
                if (allFilteredScanResult.isEmpty())
                    allFilteredScanResult = bestPickedScanResult.sortedByDescending { it.level }
                else {

                    //  Update the current list sortedFilteredScanResult with any updated ScanResult (if any)
                    val sortedBestPickedScanResult = bestPickedScanResult.sortedByDescending { it.level }
                    val newFilteredScanResult: MutableList<ScanResult> = mutableListOf()

                    //  Iterate thru the list and store new item or update existing item (if any).
                    for (eachItemInGrandList in allFilteredScanResult) {

                        var alreadyExistFlag = false
                        for (eachItemInBest in sortedBestPickedScanResult) {

                            if (eachItemInBest.BSSID.compareTo(eachItemInGrandList.BSSID) == 0) {
                                alreadyExistFlag = true
                                newFilteredScanResult += eachItemInBest
                            }
                        }

                        if (!alreadyExistFlag)
                            newFilteredScanResult += eachItemInGrandList
                    }

                    //  Add any new scanResult into the list
                    for (eachItemInBest in sortedBestPickedScanResult) {

                        var alreadyExistFlag = false
                        for (eachItemInGrandList in newFilteredScanResult) {

                            if (eachItemInBest.BSSID.compareTo(eachItemInGrandList.BSSID) == 0)
                                alreadyExistFlag = true
                        }

                        if (!alreadyExistFlag)
                            newFilteredScanResult += eachItemInBest
                    }

                    allFilteredScanResult = newFilteredScanResult.sortedByDescending { it.level }
                    Log.i(classTAG, "allFilteredScanResult: $allFilteredScanResult")
                }

                // Log for Debugging
                // for (eachScan in bestPickedScanResult) {
                //     Log.i(TAG, "Picked eachScan: $eachScan")
                // }

                //  Hardcoded Filter (to be remove in production) Move to top.
                //if (flagUseHardcodedAPMACIndexMap)
                //    allFilteredScanResult = filterOnlyHardcodedAP(allFilteredScanResult!!, hardcodedAPMACIndexMap).sortedByDescending { it.level }

                //  Setup the flag to trigger RTT scan, since the RTT scan is a seperate thread/process
                storeFlag = true
            }
        }
    }

    /**
     * Filter the available AP scan list to only those that are hardcoded.
     *
     * Filtering the list is required as the scan may not be able to pick any AP or non relevant AP in the list.
     * Filtering is done:
     * 1. Only the 1st five MAC Hex Address is compared.
     *
     * listOfScanResult: Scanned List
     * listOfHardcodedAP: Hardcoded List
     *
     * Returns the hardcoded items from the Scanned list if available.
     */
    private fun filterOnlyHardcodedAP(listOfScanResult: List<ScanResult>, listOfHardcodedAP: Map<String, Int>): MutableList<ScanResult> {

        //  Init a new empty list
        val newList: MutableList<ScanResult> = mutableListOf()

        for (eachScan in listOfScanResult) {
            val listOfDelimitedBSSIDofScan = eachScan.BSSID.split(":")

            for (eachHardcodedBSSID in listOfHardcodedAP) {

                val listOfDelimitedBSSIDofHardcoded = eachHardcodedBSSID.key.split(":")

                var flagFound = true

                //  Old code
                //  Match first 5 of 6
                //for (index in 0..4) {

                //  Match all 6
                for (index in 0..5) {
                    if (listOfDelimitedBSSIDofHardcoded[index].compareTo(listOfDelimitedBSSIDofScan[index]) != 0) {
                        flagFound = false
                        break
                    }
                }

                if (flagFound)
                    newList.add(eachScan)
            }
        }

        return newList
    }


    /**
     * Invoke RTT Scan
     *
     *  1. Get the WiFi Scan result
     *  2. Extract only the APs that the phone currently see (because, we might have walk around, some AP may no longer in range)
     *  2. Sort in descending order
     *  3. Chunk the list of AP to the size of 1: So each RangeRequest has only 1 AP.
     *  4. Start the RTT Scan. Only moving to the next AP Range ONLY if the AP has completed ranging.
     *  5. Save the result to CSV routine. (CSV Ops will check if we need to store the data to file or not)
     *  6. RTT Scan is recursive, scan only stop if all APs ranging is completed.
     *
     *  William Notes: 2025 Sep 18, New version: Recursive scan one AP at a time.
     */
    //  William: I suppressed Missing Permission, as the check already performed on MainActivty, so no idea why Android Studio kept prompting this.
    @SuppressLint("MissingPermission")
    fun invokeRTTScan() {

        //  Check if storeFlag is set, this indicate a stored result is present.
        //  Check if rttScanIsFreeFlag is set, this indicate there are no previous ranging occurring at this moment.
        if (storeFlag && rttScanIsFreeFlag && currentScanResult.isNotEmpty() && allFilteredScanResult.isNotEmpty()) {

            // Log.i(TAG,"Invoking RTT Scan...")

            //  Build the Ranging Request with filtered APs. Empty the list for the new ranging.
            listOfReq = mutableListOf()

            //  Given a list of AP that the device has seen (in the past and future)
            //  Only return the list of AP that the device currently see.
            val seenSortedFilteredScanResult: MutableList<ScanResult> = mutableListOf()
            for (eachScanResult in allFilteredScanResult) {

                var alreadyExistFlag = false
                for (eachSeenScan in currentScanResult) {
                    if (eachScanResult.BSSID.compareTo(eachSeenScan.BSSID) == 0) {
                        alreadyExistFlag = true
                        break
                    }
                }

                if (alreadyExistFlag)
                    seenSortedFilteredScanResult += eachScanResult
            }

            //  If the currently seen list of AP is not emptu, build the list of RangingRequest
            if (seenSortedFilteredScanResult.isNotEmpty()) {

                //  Chunk the List to max peers to size of 1.
                val chunkedSortedScanResult = seenSortedFilteredScanResult.sortedByDescending { it.level }.chunked(1)

                for (element in chunkedSortedScanResult) {
                    val chunkResult: List<ScanResult> = element
                    val req: RangingRequest = RangingRequest.Builder().addAccessPoints(chunkResult).build()
                    // Log.i(TAG," - Eligible Range Request: $req")
                    listOfReq.add(req)
                }

                //  Start Ranging if list is not empty.
                if (listOfReq.isNotEmpty()) {

                    //  New ranging, reset counter to zero.
                    requestCounter = 0

                    //  Get the 1st and single range request
                    val singleRangeRequest = listOfReq[requestCounter]

                    //  Increment the counter to the next index.
                    requestCounter++

                    // Build the callback: Callback will setup next Ranging within it. (Recursive call)
                    val rangeResultCallback = RTTRangeResultCallback(
                        singleRangeRequest,
                        requestCounter,
                        this
                    )

                    //  Pass it on for RTT Scan
                    mainExecutor = mainActivityContext.mainExecutor
                    mainExecutor.let {

                        //  Start the scan.
                        if (it != null) {

                            //Log.i(TAG, " - Scanning ${rrequest}}")

                            wifiRttManager.startRanging(
                                singleRangeRequest,
                                it,
                                rangeResultCallback
                            )

                            //  Once range start, set the flag to false.
                            //  This indicates that ranging is happening.
                            //  Hence, if next invokeRTTScan() occurs while ranging is still running,
                            //  we skip to the next one, while not interrupting the current one.
                            rttScanIsFreeFlag = false
                        }
                    }
                } else
                    Log.i(classTAG, "No Range Requests. Deferring to next scan.")
            } else
                Log.i(classTAG, "No APs available. Deferring to next scan.")
        }
    }

    //    /**
//     * Given the current best picked list and a new scan result:
//     * 1. Check if the new scan result is part of the AP (with atleast 5 out of 6 of the BSSID-MAC same)
//     * 2. If the new result has better RSSI value.
//     * 3. If yes, replace the existing one with the better scan result or no, leave the current one in the list.
//     * 4. If gone through the list and no BSSID-MAC is similar, it will be a new BSSID-MAC, add it to the list.
//     *
//     * Return the updated list.
//     */
//    private fun checkScanResultIsBetter(listOfExistingBestPickedResult: List<ScanResult>, toBeCheckedNewScanResult: ScanResult): MutableList<ScanResult> {
//
//        //  Init a new empty list
//        val newList: MutableList<ScanResult> = mutableListOf()
//
//        //  Set the addFlag to true
//        var addFlag = true
//
//        // Iterate through the current list
//        for (eachScan in listOfExistingBestPickedResult) {
//
//            //  Check the new scan result is related to any of the existing BSSID in the list
//            if (checkBSSIDSimilarity(4, eachScan.BSSID, toBeCheckedNewScanResult.BSSID)) {
//
//                //  If yes: Check if the RSSI level is better in the list
//                if (eachScan.level < toBeCheckedNewScanResult.level) {
//                    //  Better
//                    newList += toBeCheckedNewScanResult
//                } else {
//                    //  Worse off: Use existing list.
//                    newList += eachScan
//                }
//
//                //  If yes: This means the new scan result is related to atleast 1 item in the list.
//                //  Hence, the new scan result should not be added.
//                addFlag = false
//            } else {
//                //  If no, not related, add back to the list.
//                newList += eachScan
//            }
//        }
//
//        //  After going through the list, if the addFlag is still true, add the new scan result
//        if (addFlag)
//            newList += toBeCheckedNewScanResult
//
//        return newList
//    }
//
//    /**
//     * Given two BSSID check if they are related given how many of the items to check against.
//     *
//     * Each BSSID MAC has the following format: 30:5a:3a:c4:b3:1c
//     *
//     * If two BSSID MACs came from the same AP, they will have portion of their MAC address the same
//     * e.g.
//     * 30:5a:3a:c4:b3:1c
//     * 30:5a:3a:c4:b3:fe
//     *
//     * We check that at least 5 items from the left e.g 30:5a:3a:c4:b3 are the same, it they are, that means they are from the same AP
//     * and we return True if not False.
//     */
//    private fun checkBSSIDSimilarity(checkToIndex: Int, existingBSSID: String, toBeCheckBSSID: String): Boolean {
//
//        //  Split the string to delimit the items
//        val itemsOfExistingBSSID = existingBSSID.split(":")
//        val itemsOftoBeCheckBSSID = toBeCheckBSSID.split(":")
//
//        //  Go through the items
//        for (findex in 0..checkToIndex) {
//
//            //  If one of the item in the range is not the same return false
//            if (itemsOfExistingBSSID[findex] != itemsOftoBeCheckBSSID[findex]) {
//                return false
//            }
//        }
//
//        //  If all items in range is the same, return true.
//        return true
//    }
}