package sg.edu.smu.teamrtt.localizertt.model.dataview

import android.net.wifi.rtt.RangingResult
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * RTT Details Data View Model
 *
 * Transferring of Ranging Result from the Home Fragment to the RTTDetails Fragment
 * This allows the details of 1 AP to be shown, also allows for simultaneous updates when it occurs on the MainActivity
 * i.e. Data gets updated automatically when user is open on the RTTDetails Fragment.
 */
class RTTDetailsDataViewModel : ViewModel() {

    private var mutableRangingResult = MutableLiveData<MutableList<RangingResult>>()

    val currentRangingResult: LiveData<MutableList<RangingResult>> get() = mutableRangingResult

    fun setRangingResult(rangingResult: MutableList<RangingResult>) {
        mutableRangingResult.value = rangingResult
    }

    //  =============================================

//    private var mutableRefTestAP = MutableLiveData<String>()
//
//    val currentRefTestAP: LiveData<String> get() = mutableRefTestAP
//
//    fun setRefTestAP(bssid: String) {
//        mutableRefTestAP.value = bssid
//    }

    //  =============================================
}