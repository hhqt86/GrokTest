package sg.edu.smu.teamrtt.localizertt.model.dataview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint

/**
 * Original ViewModel now supporting for class: DrawSB1FragmentOld1
 * Hai's Constant Erro LeastSquare Algo Fragment Version (used in period of May 2025)
 */
class DrawSB1DetailsDataViewModelOld1 : ViewModel() {

    private var coordPosList = MutableLiveData<MutableList<CoordinatePoint>>()
    val currentCoordPosList: LiveData<MutableList<CoordinatePoint>> get() = coordPosList

    fun setCoordPosList(coordPos: MutableList<CoordinatePoint>) {
        coordPosList.value = coordPos
    }

    fun getArrayOfCoordinates(): Array<CoordinatePoint> {

        var arrayOfCoord: Array<CoordinatePoint> = emptyArray()

        if (currentCoordPosList.value?.isNotEmpty() == true) {
            for (eachCoordinate in currentCoordPosList.value!!) {
                arrayOfCoord += eachCoordinate
            }
        }

        return arrayOfCoord
    }

    //  ================================================================

    private var userCoordPosPoint = MutableLiveData<CoordinatePoint>()
    val currentUserCoordPosPoint: LiveData<CoordinatePoint> get() = userCoordPosPoint

    fun setUserCoordPosPoint(coordPos: CoordinatePoint) {
        userCoordPosPoint.value = coordPos
    }

    //  ================================================================

    fun getListOfTimestamp(): MutableList<Long> {

        var listOfTimestamps: MutableList<Long> = mutableListOf()

        if (currentCoordPosList.value?.isNotEmpty() == true) {
            for (eachCoordinate in currentCoordPosList.value!!) {
                listOfTimestamps.add(eachCoordinate.timestamp)
            }
        }

        //Log.i("DrawDetailsDataViewModel", "getListOfTimestamp(): $listOfTimestamps")

        return listOfTimestamps
    }

    //  ================================================================

    private var triggerFlag = MutableLiveData<Boolean>()
    val currentTriggerFlag: LiveData<Boolean> get() = triggerFlag

    fun setTriggerFlag(flag: Boolean) {
        triggerFlag.value = flag
    }

    //  ================================================================

    private var coordAPPosList = MutableLiveData<MutableList<CoordinatePoint>>()
    val currentCoordAPPosList: LiveData<MutableList<CoordinatePoint>> get() = coordAPPosList

    fun setCoordAPPosList(coordAPPos: MutableList<CoordinatePoint>) {
        coordAPPosList.value = coordAPPos
    }

    //  ================================================================

}