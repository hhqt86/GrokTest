package sg.edu.smu.teamrtt.localizertt.model.cartesian;

import androidx.annotation.NonNull;

/**
 * Coordinate Point
 * <p>
 * Used to marked position in X-Y plane.
 *
 * @author Truong Quang Hai <qhtruong@smu.edu.sg>
 * Tracking:
 * - 2025 Feb 20: Migrated from Hai's GIT codebase.
 * - 2025 Feb 26: Added timestamp and label
 */
public class CoordinatePoint {

    public double x;
    public double y;

    public double direction;

    public long timestamp;

    /**
     * Influence here is generic term.
     * E.g. If coordinate point is representing a Access Point.
     * Radius of Influence will mean likely location
     * <p>
     * Notes:   CoordinatePoint can be used to represent a lot of things: User, AP, Pillar, etc.
     * radiusOfInfluence will mean different things when it represent different things.
     */
    public double radiusOfInfluence;

    /**
     * Influence here is generic term.
     * E.g. If coordinate point is representing a Access Point.
     * Confidence of Influence will mean likely location
     * <p>
     * Notes:   CoordinatePoint can be used to represent a lot of things: User, AP, Pillar, etc.
     * radiusOfInfluence will mean different things when it represent different things.
     */
    public double confidenceOfInfluence;

    public String label;

    public CoordinatePoint(double x, double y) {
        this.x = x;
        this.y = y;
        this.timestamp = 0;
        this.label = "nil";
        this.direction = 0.0;
        this.radiusOfInfluence = 0.0;
        this.confidenceOfInfluence = 0.0;
    }


    public CoordinatePoint(double x, double y, double direction) {
        this.x = x;
        this.y = y;
        this.timestamp = 0;
        this.label = "nil";
        this.direction = direction;
        this.radiusOfInfluence = 0.0;
        this.confidenceOfInfluence = 0.0;
    }

    public CoordinatePoint(double x, double y, double radiusOfInfluence, double confidenceOfInfluence) {
        this.x = x;
        this.y = y;
        this.timestamp = 0;
        this.label = "nil";
        this.direction = 0.0;
        this.radiusOfInfluence = radiusOfInfluence;
        this.confidenceOfInfluence = confidenceOfInfluence;
    }

    public CoordinatePoint(double x, double y, long timestamp, String label) {
        this.x = x;
        this.y = y;
        this.timestamp = timestamp;
        this.label = label;
        this.direction = 0.0;
        this.radiusOfInfluence = 0.0;
        this.confidenceOfInfluence = 0.0;
    }

    @NonNull
    @Override
    public String toString() {

        return "X: " + this.x + ", Y: " + this.y;
    }


}
