package sg.edu.smu.teamrtt.localizertt.model.wifi

/**
 * Used for Hai's Algo.
 *
 * As we need to tracked each AP's distance across time to do solve using LeastSquares.
 *
 * Every time we get a RangeResult from RTT scan, we store to the list of Tracked Access Point
 */
class TrackedAP(private val bssidOfAP: String, private val timeWindow: Long) {

    /**
     * Tracked Timestamp(Unix) - Distance
     */
    //private var trackedTimeDistancePair = HashMap<Long, Float>()
    private var trackedTimeDistancePair = emptyMap<Long, Double>()

    private fun setTrackedTimeDistancePair(dataTrackedTimeDistancePair: Map<Long, Double>) {

        trackedTimeDistancePair = dataTrackedTimeDistancePair

    }

    /**
     * Check if the Key-Value pair holding the collected data is empty or not.
     */
    fun isEmpty(): Boolean {
        return trackedTimeDistancePair.isEmpty()
    }

    /**
     * Add data into the Key-Value Pair collection.
     *
     * At each add process, filter out old data and rearrange the data based on Key (Ascending)
     * entryTimestamp - Unix Timestamp
     * entryDistance - Meters.
     */
    fun addDataPoint(entryTimestamp: Long, entryDistance: Double) {

        //Log.i("William", "BSSID: ${bssidOfAP}, Timestamp: ${entryTimestamp}, Distance: $entryDistance")

        //  Add to key-value pair map
        trackedTimeDistancePair = trackedTimeDistancePair + mapOf(entryTimestamp to entryDistance)
        //trackedTimeDistancePair[entryTimestamp] = entryDistance
        //Log.i("William", "trackedTimeDistancePair: $trackedTimeDistancePair")

        //  Filter the hashmap based on the timeWindow
        val nonMatchingPredicate: (Long) -> Boolean = { it > (entryTimestamp - (timeWindow / 2)) && it <= (entryTimestamp + (timeWindow / 2)) }
        val filteredMap = trackedTimeDistancePair.filterKeys(nonMatchingPredicate)
        //Log.i("William", "filteredMap: $filteredMap")

        //  Sort the map based on the time:
        //  Ref: https://mrappbuilder.medium.com/sort-a-hashmap-in-kotlin-in-ascending-order-but-the-first-element-is-not-used-in-sorting-a7d6f1a1fefa
        val filteredSortedMap = filteredMap.toList().sortedBy { it.first }.toMap()
        //Log.i("William", "filteredSortedMap: $filteredSortedMap")

        //  Once Filtered and Sorted, add back
        trackedTimeDistancePair = filteredSortedMap
        //Log.i("William", "trackedTimeDistancePair: $trackedTimeDistancePair")

        //Log.i("William", "BSSID: ${bssidOfAP}, trackedTimeDistancePair: $trackedTimeDistancePair")
    }

    /**
     * Get Filtered Window of TrackedAP
     *
     * From the original data source, create and new TrackedAP that is filtered based on the timestamp window (lower to upper)
     */
    fun getFilteredWindow(lowerLimit: Long, upperLimit: Long): TrackedAP {

        //  Filter the hashmap based on the timeWindow
        val nonMatchingPredicate: (Long) -> Boolean = { it in (lowerLimit + 1)..upperLimit }
        val filteredMap = trackedTimeDistancePair.filterKeys(nonMatchingPredicate)

        //  Sort the map based on the time:
        //  Ref: https://mrappbuilder.medium.com/sort-a-hashmap-in-kotlin-in-ascending-order-but-the-first-element-is-not-used-in-sorting-a7d6f1a1fefa
        val filteredSortedMap = filteredMap.toList().sortedBy { it.first }.toMap()

        var newTrackedAP: TrackedAP = TrackedAP(bssidOfAP, timeWindow)
        newTrackedAP.setTrackedTimeDistancePair(filteredSortedMap)

        return newTrackedAP
    }

    /**
     * Get the average distance of the collected trackedTimeDistancePair
     */
    fun getAverageDistance(): Double {

        var totalDistance: Double = 0.0

        for (eachTimestamp in trackedTimeDistancePair.keys) {
            var distance = trackedTimeDistancePair.get(eachTimestamp)
            if (distance != null) {
                totalDistance += distance
            }
        }

        return if (totalDistance == 0.0) {
            0.0
        } else {
            totalDistance / trackedTimeDistancePair.size
        }
    }


}