package sg.edu.smu.teamrtt.localizertt.model.wifi

class APRangeReading(private val bssidOfAP: String, private val rangeReadingAssociatedWithAP: DoubleArray) {

    fun getBSSID(): String {
        return bssidOfAP
    }

    fun getRangeReading(): DoubleArray {
        return rangeReadingAssociatedWithAP
    }

    override fun toString(): String {
        return "APRangeReading(bssidOfAP='$bssidOfAP', rangeReadingAssociatedWithAP=${rangeReadingAssociatedWithAP.contentToString()})"
    }


    companion object {

        fun obtainRangeReading(listOfAPRangeReading: List<APRangeReading>): Array<DoubleArray> {

            var rangeReadings: Array<DoubleArray> = emptyArray()

            for (eachItem in listOfAPRangeReading) {
                rangeReadings += eachItem.getRangeReading()
            }

            return rangeReadings
        }


        fun obtainListOfAP(listOfAPRangeReading: List<APRangeReading>): List<String> {

            val listOfAP: MutableList<String> = mutableListOf()

            for (eachItem in listOfAPRangeReading) {
                listOfAP += eachItem.getBSSID()
            }

            return listOfAP
        }
    }
}