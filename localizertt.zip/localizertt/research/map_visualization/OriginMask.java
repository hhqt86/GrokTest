package sg.edu.smu.teamrtt.localizertt.research.map_visualization;

import static sg.edu.smu.teamrtt.localizertt.util.AppPrefStoreKt.apCircleThresholdToMarkAsFound;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

/**
 * Builds a mask over [0,width] x [0,height] where each grid cell counts
 * how many point-pair constraints it satisfies:
 * <p>
 * | (dist(cell, pi) - dist(cell, pj)) - (value_i - value_j) | <= tolerance
 * <p>
 * Each satisfying pair contributes +1 to the cell's value.
 *
 * @author Thu Tran, 2025 Aug 27.
 * Tracking:
 * - 2025 Aug 27: Migrated from Thu's GIT codebase.
 */
public final class OriginMask {
    private OriginMask() {
    }

    /**
     * Build mask with explicit tolerance.
     *
     * @param data      points with measured values (x, y, value)
     * @param gridW     number of cols in mask
     * @param gridH     number of rows in mask
     * @param width     real width in meters
     * @param height    real height in meters
     * @param tolerance absolute tolerance for matching distance differences
     * @return int[gridH][gridW] counts (each cell is how many pairs match)
     */
    public static int[][] buildMask(List<PointVal> data,
                                    int gridW, int gridH,
                                    double width, double height,
                                    double tolerance) {

        if (gridW <= 0 || gridH <= 0) throw new IllegalArgumentException("gridW/gridH must be > 0");
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("width/height must be > 0");
        if (data == null || data.size() < 2) throw new IllegalArgumentException("Need at least 2 points");
        if (tolerance < 0) throw new IllegalArgumentException("tolerance must be >= 0");

        final int n = data.size();
        // Precompute observed deltas: obsDelta[i][j] = value_i - value_j
        double[][] obsDelta = new double[n][n];
        for (int i = 0; i < n; i++) {
            double vi = data.get(i).getMeanRTTDistance();
            for (int j = i + 1; j < n; j++) {
                obsDelta[i][j] = vi - data.get(j).getMeanRTTDistance();
            }
        }

        int[][] mask = new int[gridH][gridW];

        // Cell centers
        double cellW = width / gridW;
        double cellH = height / gridH;

        for (int gy = 0; gy < gridH; gy++) {
            // Change the direction of the y axis to upwards
            // It was downwards originally
            // Move (0,0) to the middle of the screen
            double cy = (gridH - gy + 0.5) * cellH - height / 2;
            for (int gx = 0; gx < gridW; gx++) {
                // Move (0,0) to the middle of the screen
                // Direction of x axis if left-right
                double cx = (gx + 0.5) * cellW - width / 2;

                int count = 0;
                // Check all unordered pairs (i<j)
                for (int i = 0; i < n; i++) {
                    PointVal pi = data.get(i);
                    double di = hypot(cx - pi.getX(), cy - pi.getY());
                    for (int j = i + 1; j < n; j++) {
                        PointVal pj = data.get(j);
                        double dj = hypot(cx - pj.getX(), cy - pj.getY());

                        double modelDelta = di - dj;
                        double observedDelta = obsDelta[i][j];

                        if (Math.abs(modelDelta - observedDelta) <= tolerance) {
                            count++;
                        }
                    }
                }
                mask[gy][gx] = count;
            }
        }
        return mask;
    }

    /**
     * @param apDatas   list of data for each AP (each inner list is List<PointVal> for one AP)
     * @param gridW     number of cols in mask
     * @param gridH     number of rows in mask
     * @param width     real width in meters
     * @param height    real height in meters
     * @param tolerance absolute tolerance for matching distance differences
     * @param apStatuses list of APStatus to update, same order and size as apDatas
     * @return List<APCircle> one for each AP
     */
    public static List<APCircle> buildAPRoundRepresentative(List<List<PointVal>> apDatas,
                                                            int gridW, int gridH,
                                                            double width, double height,
                                                            double tolerance,
                                                            List<APStatus> apStatuses) {

        if (gridW <= 0 || gridH <= 0) throw new IllegalArgumentException("gridW/gridH must be > 0");
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("width/height must be > 0");
        if (apDatas == null || apDatas.isEmpty()) throw new IllegalArgumentException("Need at least one AP");
        if (tolerance < 0) throw new IllegalArgumentException("tolerance must be >= 0");

        List<APCircle> results = new ArrayList<>();

        for (int i = 0; i < apDatas.size(); i++) {
            List<PointVal> data = apDatas.get(i);

            if (data == null || data.size() < 2) {
                results.add(null); // Skip invalid AP data
                continue;
            }

            int n = data.size();
            int possibleMax = n * (n - 1) / 2;

            // Precompute observed deltas: obsDelta[i][j] = value_i - value_j for i < j
            double[][] obsDelta = new double[n][n];
            for (int j = 0; j < n; j++) {
                double vj = data.get(j).getMeanRTTDistance();
                for (int k = j + 1; k < n; k++) {
                    obsDelta[j][k] = vj - data.get(k).getMeanRTTDistance();
                }
            }

            int[][] mask = new int[gridH][gridW];
            double cellW = width / gridW;
            double cellH = height / gridH;
            int maxValue = 0;

            for (int gy = 0; gy < gridH; gy++) {
                double cy = (gridH - gy + 0.5) * cellH - height / 2;
                for (int gx = 0; gx < gridW; gx++) {
                    double cx = (gx + 0.5) * cellW - width / 2;

                    int count = 0;
                    for (int j = 0; j < n; j++) {
                        PointVal pi = data.get(j);
                        double di = hypot(cx - pi.getX(), cy - pi.getY());
                        for (int k = j + 1; k < n; k++) {
                            PointVal pj = data.get(k);
                            double dj = hypot(cx - pj.getX(), cy - pj.getY());

                            double modelDelta = di - dj;
                            double observedDelta = obsDelta[j][k];

                            if (Math.abs(modelDelta - observedDelta) <= tolerance) {
                                count++;
                            }
                        }
                    }
                    mask[gy][gx] = count;
                    if (count > maxValue) {
                        maxValue = count;
                    }
                }
            }

            if (maxValue == 0) {
                results.add(null); // No valid area
                continue;
            }

            // Find all cells with maxValue
            List<int[]> maxCells = new ArrayList<>();
            for (int gy = 0; gy < gridH; gy++) {
                for (int gx = 0; gx < gridW; gx++) {
                    if (mask[gy][gx] == maxValue) {
                        maxCells.add(new int[]{gy, gx});
                    }
                }
            }

            // Find largest connected component (4-connected)
            List<int[]> largestComponent = findLargestComponent(maxCells, gridH, gridW);

            if (largestComponent.isEmpty()) {
                results.add(null);
                continue;
            }

            // Compute centroid
            double sumX = 0;
            double sumY = 0;
            for (int[] cell : largestComponent) {
                int gy = cell[0];
                int gx = cell[1];
                double cy = (gridH - gy + 0.5) * cellH - height / 2;
                double cx = (gx + 0.5) * cellW - width / 2;
                sumX += cx;
                sumY += cy;
            }
            double centX = sumX / largestComponent.size();
            double centY = sumY / largestComponent.size();

            // Compute radius: max dist to centroid
            double maxDist = 0;
            for (int[] cell : largestComponent) {
                int gy = cell[0];
                int gx = cell[1];
                double cy = (gridH - gy + 0.5) * cellH - height / 2;
                double cx = (gx + 0.5) * cellW - width / 2;
                double dist = hypot(cx - centX, cy - centY);
                if (dist > maxDist) {
                    maxDist = dist;
                }
            }

            double confidence = (double) maxValue / possibleMax;

            if (apStatuses != null) {
                apStatuses.get(i).setX(centX);
                apStatuses.get(i).setY(centY);
            }

            if (maxDist > apCircleThresholdToMarkAsFound){
                if (apStatuses != null) {
                    apStatuses.get(i).setStatus(APStatus.STATUS_FOUND);
                }
            }

            results.add(new APCircle(centX, centY, maxDist, confidence));
        }

        return results;
    }

    private static List<int[]> findLargestComponent(List<int[]> maxCells, int gridH, int gridW) {
        Set<String> visited = new HashSet<>();
        List<int[]> largest = new ArrayList<>();
        for (int[] cell : maxCells) {
            String key = cell[0] + "," + cell[1];
            if (visited.contains(key)) continue;

            // BFS for component
            List<int[]> component = new ArrayList<>();
            Queue<int[]> queue = new LinkedList<>();
            queue.add(cell);
            visited.add(key);

            while (!queue.isEmpty()) {
                int[] curr = queue.poll();
                component.add(curr);

                // Neighbors: up, down, left, right
                int[][] dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
                for (int[] dir : dirs) {
                    int ny = curr[0] + dir[0];
                    int nx = curr[1] + dir[1];
                    if (ny >= 0 && ny < gridH && nx >= 0 && nx < gridW) {
                        String nkey = ny + "," + nx;
                        if (!visited.contains(nkey) && containsCell(maxCells, ny, nx)) {
                            visited.add(nkey);
                            queue.add(new int[]{ny, nx});
                        }
                    }
                }
            }

            if (component.size() > largest.size()) {
                largest = component;
            }
        }
        return largest;
    }

    private static boolean containsCell(List<int[]> cells, int y, int x) {
        for (int[] cell : cells) {
            if (cell[0] == y && cell[1] == x) return true;
        }
        return false;
    }

    private static double hypot(double dx, double dy) {
        return Math.hypot(dx, dy);
    }

    /**
     * Builds round heatmap representations for multiple access points (APs).
     * For each AP, computes a mask similar to previous one, identifies the largest
     * connected component of cells with the maximum value, and represents it
     * as a circle with centroid and radius. Also computes a confidence value
     * for coloring or visualization purposes.
     * Every AP will have a differenct color, and the circle represents equal probabilities. The
     * confident values are calculated based on the value of the heatmap and n * (n - 1) / 2, the
     * maximum value of all pairs
     *
     * @author Hai
     * Tracking:
     * 2025 Nov 06: Created based on OriginMask, adapted for multiple APs and circle representation,
     * added updating of APStatus based on maxDist threshold.
     * Build circle representations for multiple APs.
     */
    public static class APCircle {
        private final double centerX;
        private final double centerY;
        private final double radius;
        private final double confidence; // 0 to 1, for coloring

        public APCircle(double centerX, double centerY, double radius, double confidence) {
            this.centerX = centerX;
            this.centerY = centerY;
            this.radius = radius;
            this.confidence = confidence;
        }

        public double getCenterX() {
            return centerX;
        }

        public double getCenterY() {
            return centerY;
        }

        public double getRadius() {
            return radius;
        }

        public double getConfidence() {
            return confidence;
        }
    }
    public static void main(String[] args) {
        // Example data for one AP
        String bssid = "00:11:22:33:AA:BB";
        List<PointVal> data = new ArrayList<>();
        data.add(new PointVal(bssid, 0.0, 0.0, 3.0, -60.0));
        data.add(new PointVal(bssid, 6.0, 0.0, 3.0, -60.0));
        data.add(new PointVal(bssid, 3.0, 4.0, 4.0, -70.0));

        List<List<PointVal>> apDatas = new ArrayList<>();
        apDatas.add(data);

        List<APStatus> apStatuses = new ArrayList<>();
        apStatuses.add(new APStatus(bssid, 0.0, 0.0));

        int gridW = 100;
        int gridH = 100;
        double width = 10.0;
        double height = 10.0;
        double tolerance = 0.1;

        List<APCircle> circles = buildAPRoundRepresentative(apDatas, gridW, gridH, width, height, tolerance, apStatuses);
        for (int i = 0; i < circles.size(); i++) {
            APCircle circle = circles.get(i);
            if (circle != null) {
                System.out.printf("AP %s - Center: (%.2f, %.2f), Radius: %.2f, Confidence: %.2f%n",
                        bssid, circle.getCenterX(), circle.getCenterY(), circle.getRadius(), circle.getConfidence());
            } else {
                System.out.println("No circle found for AP " + bssid);
            }
        }

        for (APStatus status : apStatuses) {
            System.out.printf("BSSID: %s, Status: %d, Position: (%.2f, %.2f)%n",
                    status.getBSSID(), status.getStatus(), status.getX(), status.getY());
        }
    }
}

