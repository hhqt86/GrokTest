package sg.edu.smu.teamrtt.localizertt.research.map_visualization;

/**
 * AP Status
 * <p>
 * For storing the computed AP's location and status
 *
 * @author Truong Quang Hai <qhtruong@smu.edu.sg>, William Tan Kiat Wee
 * Tracking:
 * - 2025 Nov 05: Creation.
 */
public class APStatus {

    public static final int STATUS_FOUND = 0;

    public static final int STATUS_NOT_FOUND = 1;

    private final String strBSSID;
    private double x;
    private double y;

    private int nStatus;

    /**
     * Constructor
     *
     * @param strBSSID String BSSID E.g. 00:11:22:33:AA:BB
     * @param x        Double Set initial coordinate E.g. 0.0
     * @param y        Double Set initial coordinate E.g. 0.0
     */
    public APStatus(String strBSSID, double x, double y) {
        this.strBSSID = strBSSID;
        this.x = x;
        this.y = y;
        this.nStatus = STATUS_NOT_FOUND;
    }

    public String getBSSID() {
        return strBSSID;
    }

    public int getStatus() {
        return nStatus;
    }

    public void setStatus(int nStatus) {
        this.nStatus = nStatus;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
}
