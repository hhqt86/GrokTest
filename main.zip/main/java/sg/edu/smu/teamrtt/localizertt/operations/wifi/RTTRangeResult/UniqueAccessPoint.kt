package sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangeResult

import android.net.wifi.ScanResult
import android.net.wifi.rtt.RangingResult

class UniqueAccessPoint(val maxBSSIDComponent: Int) {
    val commonIdentifiers: LinkedHashSet<String> = LinkedHashSet()

    //val setOfChildBSSID: HashSet<String> = hashSetOf()
    val hashMapOfRangeResult: HashMap<String, RangingResult> = hashMapOf()


    private fun isBSSIDChild(strBSSID: String): Boolean {

        //  Split the string to delimit the items
        val itemsOftoBeCheckBSSID = strBSSID.split(":")

        var counter = 0
        //  Go through the items
        for (eachHexDecOfBSSID in commonIdentifiers) {

            //  If one of the item in the range is not the same return false
            if (eachHexDecOfBSSID.compareTo(itemsOftoBeCheckBSSID[counter]) != 0) {
                return false
            }

            counter++
        }

        //  If all items in range is the same, return true.
        return true
    }

    fun addChild(strBSSID: String, rangingResult: RangingResult): Boolean {

        if (commonIdentifiers.isEmpty()) {

            var counter = 0

            //  Split the string to delimit the items
            val itemsOftoBeCheckBSSID = strBSSID.split(":")
            if (itemsOftoBeCheckBSSID.size == 6) {
                for (eachHexDec in itemsOftoBeCheckBSSID) {
                    if (counter < maxBSSIDComponent)
                        commonIdentifiers.add(eachHexDec)
                    counter++
                }

                // setOfChildBSSID.add(strBSSID)
                hashMapOfRangeResult[strBSSID] = rangingResult
                return true
            } else
                return false
        } else {
            if (isBSSIDChild(strBSSID)) {
                //setOfChildBSSID.add(strBSSID)
                hashMapOfRangeResult[strBSSID] = rangingResult
                return true
            } else {
                return false
            }
        }
    }

    fun getBestBSSIDToRepresentAP(): String {

        val bestBSSID = nested01BestInCategoryOfFrequency()
        return bestBSSID
    }

    fun getRestOfBSSIDNotSelected(bestBSSID: String): Set<String> {

        // Filter the map to exclude the specified key
        val filteredKeys = hashMapOfRangeResult.filterKeys { it != bestBSSID }.keys

        return filteredKeys
    }

    private fun nested01BestInCategoryOfFrequency(): String {

        var listOFBSSIDin5Ghz: MutableList<RangingResult> = mutableListOf()
        var listOFBSSIDin2Ghz: MutableList<RangingResult> = mutableListOf()

        val keySet = hashMapOfRangeResult.keys
        for (eachBSSID in keySet) {
            val rangeResult = hashMapOfRangeResult.get(eachBSSID)
            if (rangeResult != null && (rangeResult.status == RangingResult.STATUS_SUCCESS)) {
                if (rangeResult.measurementChannelFrequencyMHz > 5000) {
                    listOFBSSIDin5Ghz.add(rangeResult)
                } else if (rangeResult.measurementChannelFrequencyMHz > 2000) {
                    listOFBSSIDin2Ghz.add(rangeResult)
                }
            }
        }

        if (listOFBSSIDin5Ghz.isNotEmpty()) {
            return nested02BestInCategoryOfBandwidth(listOFBSSIDin5Ghz)
        } else if (listOFBSSIDin2Ghz.isNotEmpty()) {
            return nested02BestInCategoryOfBandwidth(listOFBSSIDin2Ghz)
        } else {
            return "nil"
        }
    }

    private fun nested02BestInCategoryOfBandwidth(listOfCandidatesRangingResult: MutableList<RangingResult>): String {

        var listOFBSSIDin320: MutableList<RangingResult> = mutableListOf()
        var listOFBSSIDin160: MutableList<RangingResult> = mutableListOf()
        var listOFBSSIDin80: MutableList<RangingResult> = mutableListOf()
        var listOFBSSIDin40: MutableList<RangingResult> = mutableListOf()
        var listOFBSSIDin20: MutableList<RangingResult> = mutableListOf()
        var listOFBSSIDinUnspecified: MutableList<RangingResult> = mutableListOf()


        for (eachRangeResult in listOfCandidatesRangingResult) {

            if (eachRangeResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_320MHZ ||
                eachRangeResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ
            ) {
                listOFBSSIDin320.add(eachRangeResult)
            } else if (eachRangeResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_160MHZ)
                listOFBSSIDin160.add(eachRangeResult)
            else if (eachRangeResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_80MHZ)
                listOFBSSIDin80.add(eachRangeResult)
            else if (eachRangeResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_40MHZ)
                listOFBSSIDin40.add(eachRangeResult)
            else if (eachRangeResult.measurementBandwidth == ScanResult.CHANNEL_WIDTH_20MHZ)
                listOFBSSIDin20.add(eachRangeResult)
            else
                listOFBSSIDinUnspecified.add(eachRangeResult)
        }

        if (listOFBSSIDin320.isNotEmpty()) {
            return nested03BestInCategoryOfRSSI(listOFBSSIDin320)
        } else if (listOFBSSIDin160.isNotEmpty()) {
            return nested03BestInCategoryOfRSSI(listOFBSSIDin160)
        } else if (listOFBSSIDin80.isNotEmpty()) {
            return nested03BestInCategoryOfRSSI(listOFBSSIDin80)
        } else if (listOFBSSIDin40.isNotEmpty()) {
            return nested03BestInCategoryOfRSSI(listOFBSSIDin40)
        } else if (listOFBSSIDin20.isNotEmpty()) {
            return nested03BestInCategoryOfRSSI(listOFBSSIDin20)
        } else if (listOFBSSIDinUnspecified.isNotEmpty()) {
            return nested03BestInCategoryOfRSSI(listOFBSSIDinUnspecified)
        } else {
            return "nil"
        }

    }

    private fun nested03BestInCategoryOfRSSI(listOfCandidatesRangingResult: MutableList<RangingResult>): String {

        var topRSSI = -999
        var topBSSID = "nil"

        for (eachRangeResult in listOfCandidatesRangingResult) {

            if (topRSSI == -999) {
                topRSSI = eachRangeResult.rssi
                topBSSID = eachRangeResult.macAddress.toString()
            } else {
                if (eachRangeResult.rssi > topRSSI) {
                    topRSSI = eachRangeResult.rssi
                    topBSSID = eachRangeResult.macAddress.toString()
                }
            }
        }

        return topBSSID
    }


    //  Kotlin Equivalent for Static Function

    companion object {
        fun addToCollectionOfUniqueAccessPoints(
            strBSSID: String,
            rangingResult: RangingResult,
            currentCollectionOfUniqueAccessPoint: HashSet<UniqueAccessPoint>
        ): HashSet<UniqueAccessPoint> {

            if (currentCollectionOfUniqueAccessPoint.isEmpty()) {
                val newAccessPoint = UniqueAccessPoint(5)
                newAccessPoint.addChild(strBSSID, rangingResult)

                currentCollectionOfUniqueAccessPoint.add(newAccessPoint)
            } else {

                var foundFlag = false
                for (eachUniqueAP in currentCollectionOfUniqueAccessPoint) {

                    if (eachUniqueAP.addChild(strBSSID, rangingResult)) {
                        foundFlag = true
                        break
                    }
                }

                if (!foundFlag) {
                    val newAccessPoint = UniqueAccessPoint(5)
                    newAccessPoint.addChild(strBSSID, rangingResult)

                    currentCollectionOfUniqueAccessPoint.add(newAccessPoint)
                }
            }

            return currentCollectionOfUniqueAccessPoint
        }
    }
}