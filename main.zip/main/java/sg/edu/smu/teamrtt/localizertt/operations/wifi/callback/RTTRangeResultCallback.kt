package sg.edu.smu.teamrtt.localizertt.operations.wifi.callback

import android.annotation.SuppressLint
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.RangingResult
import android.net.wifi.rtt.RangingResultCallback
import android.util.Log
import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangingOps
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations

/**
 * RTT Range Result Callback
 * (Implements the RangingResultCallback Interface)
 *
 * 1. Handles what happens if a range fails.
 * 2. Handles what occurs when range is success.
 *
 * In this implementation, in either mode, the callback will do the following:
 * 1. Setup the next AP range request, in the list of range request.
 * 2. Calls the AP Ranging AP with the range request.
 * 3. This is then recursively call again on Step 1 and 2 until all AP in the list is exhausted.
 * 4. This allows us to range the AP one at a time, setting up the next range after the previous one is completed (or fail)
 * 5. We are doing this to avoid issues with the chunk approach: Where a chunk of AP is set the to Range API where if 1 fails, all failed.
 * 6. Whereas this approach ensures only 1 AP is range at only 1 time.
 *
 * RTTRangeResultCallback is used in WiFIRTTScanOps Class.
 *
 * @author William Tan Kiat Wee 2025 Sep 18.
 */
class RTTRangeResultCallback(
    val currentRequest: RangingRequest,
    var requestCounter: Int,
    var handle: RTTRangingOps
) : RangingResultCallback() {

    //  TAG for Logging
    private val TAG = this.javaClass.name

    /**
     * See Docs: We are just implementing the interface.
     * For Error.
     */
    override fun onRangingFailure(code: Int) {

        //  Log the error when ranging fail and on which request.
        val errorMessage: String = when (code) {
            STATUS_CODE_FAIL -> "Ranging fail"
            STATUS_CODE_FAIL_RTT_NOT_AVAILABLE -> "RTT Not Available"
            else -> "Unknown"
        }

        Log.e(
            TAG,
            "  -- Ranging Error. Error code: $code, $errorMessage. For $currentRequest"
            //"   - Ranging Error. Error code: $code, $errorMessage. Respond Index: ${reponseSetCounter}, Timestamp: ${Calendar.getInstance().timeInMillis}"
        )

        //  Scan next RangeRequest
        scanNext()
    }

    /**
     * See Docs: We are just implementing the interface.
     * For when result is available.
     */
    override fun onRangingResults(results: List<RangingResult?>) {

        //  DEBUG Log
        if (handle.flagUseHardcodedAPMACIndexMap)
            Log.i(TAG, "  -- Ranging Success. Hardcoded AP Mode. Result: ${results}. For $currentRequest")
        else
            Log.i(TAG, "  -- Ranging Success. Result: ${results}. For $currentRequest")

        //  Add to results to holder
        for (eachResult in results) {
            if (eachResult != null) {
                //Log.i(TAG, "    ---- RTT ScanResult: $eachResult")
                handle.scanRTTResultHolder.add(eachResult)
            }
        }

        //  Save to CSV
        val savingToCSVThread = Thread {
            handle.mainActivityContext.let { it1 ->
                CSVOperations().saveToCSVRTTData(it1, handle.scanRTTResultHolder.toMutableList())
            }
        }
        savingToCSVThread.start()

        //  Update the data so that Fragment and WiFiProcessOps can access
        handle.rttDetailsViewModel.setRangingResult(handle.scanRTTResultHolder.toMutableList())

        //  Scan next RangeRequest
        scanNext()
    }

    /**
     * Setup the next RTT Ranging after the result is captured Or failed.
     *
     * Recursively setup the Callback and next scan (in the list)
     * Continue to do so until the list is exhausted, then clear the flag for next scan.
     */
    @SuppressLint("MissingPermission")
    private fun scanNext() {

        //  The requestCounter has been incremented since the last scan,
        //  Hence, we check if the index is within the list.
        //  If not, list is exhausted, recursive call ends.
        if (requestCounter < handle.listOfReq.size) {

            // Log.i(TAG, " - requestCounter Next ${requestCounter}}")

            //  Get the next and single range request
            val singleRangeRequest = handle.listOfReq[requestCounter]

            //  Increment the counter to the next index.
            requestCounter++

            val recursiveRangeResultCallback = RTTRangeResultCallback(
                singleRangeRequest,
                requestCounter,
                handle
            )

            //  Pass it on for RTT Scan
            handle.mainExecutor = handle.mainActivityContext.mainExecutor
            handle.mainExecutor.let {

                //  Start the scan.
                if (it != null) {

                    //Log.i(TAG, " - Scanning Next ${singleRangeRequest}}")

                    handle.wifiRttManager.startRanging(
                        singleRangeRequest,
                        it,
                        recursiveRangeResultCallback
                    )
                }
            }
        } else {
            //  Recursive call ends, resets flag to true for next RTT Range scan.
            //  If held at false, the next RTT Range scan cannot happen.
            handle.rttScanIsFreeFlag = true
            // Log.i(TAG, " - Complete.")
        }
    }
}