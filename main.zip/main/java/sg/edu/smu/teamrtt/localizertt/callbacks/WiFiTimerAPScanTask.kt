package sg.edu.smu.teamrtt.localizertt.callbacks

import sg.edu.smu.teamrtt.localizertt.MainActivity
import java.util.TimerTask

/**
 * Timer Task for Invoking WiFi AP Scan
 *
 * Scheduled by MainActivity to invoke WiFi Scan to allow more frequent AP Scan.
 *
 * @author William Tan. 2025 Mar 28.
 */
class WiFiTimerAPScanTask(private val mainActivity: MainActivity) : TimerTask() {

    override fun run() {

        //  Start the WifI Scan
        mainActivity.startWiFiScan()
    }
}