package sg.edu.smu.teamrtt.localizertt.research;

import org.apache.commons.math3.fitting.leastsquares.LeastSquaresBuilder;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresOptimizer;
import org.apache.commons.math3.fitting.leastsquares.LeastSquaresProblem;
import org.apache.commons.math3.fitting.leastsquares.LevenbergMarquardtOptimizer;
import org.apache.commons.math3.fitting.leastsquares.MultivariateJacobianFunction;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.commons.math3.util.Pair;

import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint;

/**
 * AP Location Constant-Error LeastSquare
 *
 * @author Truong Quang Hai <qhtruong@smu.edu.sg>
 * Tracking:
 * - 2025 Feb 26: Migrated from Hai's GIT codebase.
 */
public class APLocationConstantErrorLeastSquare {
    static int ap_number = 4;
    static int movementCount = 5;
    static CoordinatePoint[] estimatedAP = new CoordinatePoint[ap_number];
    static double[] rangeErrorEachAP = new double[ap_number];

    public static CoordinatePoint solveX(CoordinatePoint[] movementLocations, double[] diffDistances) {
        MultivariateJacobianFunction model = point -> {
            double x = point.getEntry(0);
            double y = point.getEntry(1);
            RealVector residuals = new ArrayRealVector(diffDistances.length);
            RealMatrix jacobian = new Array2DRowRealMatrix(diffDistances.length, 2);
            for (int i = 0; i < diffDistances.length; i++) {
                CoordinatePoint A = movementLocations[i];
                CoordinatePoint B = movementLocations[i + 1];
                double dA = Math.sqrt(Math.pow(x - A.x, 2) + Math.pow(y - A.y, 2));
                double dB = Math.sqrt(Math.pow(x - B.x, 2) + Math.pow(y - B.y, 2));
                residuals.setEntry(i, dB - dA - diffDistances[i]);
                if (dA != 0) {
                    jacobian.setEntry(i, 0, (x - A.x) / dA);
                    jacobian.setEntry(i, 1, (y - A.y) / dA);
                }

                if (dB != 0) {
                    jacobian.setEntry(i, 0, (x - B.x) / dB - jacobian.getEntry(i, 0));
                    jacobian.setEntry(i, 1, (y - B.y) / dB - jacobian.getEntry(i, 1));
                }
            }
            return new Pair<>(residuals, jacobian);
        };

        LeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresProblem problem = new LeastSquaresBuilder()
                .start(new double[]{0, 0})
                .model(model)
                .target(new double[diffDistances.length])
                .lazyEvaluation(false)
                .maxEvaluations(1000) // original: 1000, mod: 100000
                .maxIterations(1000)
                .build();
        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
        return new CoordinatePoint(result.getPoint().getEntry(0), result.getPoint().getEntry(1));
    }

    public static double[][] calculateDiffDistances(double[][] rangeReadings) {
        double[][] diffDistances = new double[rangeReadings.length][rangeReadings[0].length - 1];
        for (int i = 0; i < rangeReadings.length; i++) {
            for (int j = 0; j < rangeReadings[0].length - 1; j++) {
                diffDistances[i][j] = rangeReadings[i][j + 1] - rangeReadings[i][j];
            }
        }
        return diffDistances;
    }

    public static CoordinatePoint localizePosition(double[] rangeErrorEachAP, CoordinatePoint[] estimatedAPs, double[] rangeReadingsForLocalization) {
        MultivariateJacobianFunction model = point -> {
            double x = point.getEntry(0);
            double y = point.getEntry(1);
            RealVector residuals = new ArrayRealVector(estimatedAPs.length);
            RealMatrix jacobian = new Array2DRowRealMatrix(estimatedAPs.length, 2);

            for (int i = 0; i < estimatedAPs.length; i++) {
                //CoordinatePoint ap = estimatedAP[i];
                CoordinatePoint ap = estimatedAPs[i];
                double d = Math.sqrt(Math.pow(x - ap.x, 2) + Math.pow(y - ap.y, 2));
                residuals.setEntry(i, d - rangeReadingsForLocalization[i] + rangeErrorEachAP[i]);
                if (d != 0) {
                    jacobian.setEntry(i, 0, (x - ap.x) / d);
                    jacobian.setEntry(i, 1, (y - ap.y) / d);
                }
            }

            return new Pair<>(residuals, jacobian);
        };

        LeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
        LeastSquaresProblem problem = new LeastSquaresBuilder()
                .start(new double[]{0, 0})
                .model(model)
                .target(new double[estimatedAPs.length])
                .lazyEvaluation(false)
                .maxEvaluations(1000)
                .maxIterations(1000)
                .build();

        LeastSquaresOptimizer.Optimum result = optimizer.optimize(problem);
        return new CoordinatePoint(result.getPoint().getEntry(0), result.getPoint().getEntry(1));
    }

    public static double[] calculateRangingErrors(int numOfAP, CoordinatePoint[] movementLocations, double[][] rangeReadings, CoordinatePoint[] estimatedAPs) {
        double[] errors = new double[numOfAP];
        for (int apIndex = 0; apIndex < numOfAP; apIndex++) {
            double sumError = 0;
            for (int i = 0; i < movementLocations.length; i++) {
                double trueDistance = Math.sqrt(Math.pow(movementLocations[i].x - estimatedAPs[apIndex].x, 2) +
                        Math.pow(movementLocations[i].y - estimatedAPs[apIndex].y, 2));
                double measuredDistance = rangeReadings[apIndex][i];
                sumError += (measuredDistance - trueDistance);
            }
            errors[apIndex] = sumError / movementLocations.length; // Mean error per AP
        }
        return errors;
    }

    public static void main(String[] args) {
        CoordinatePoint[] movementLocations = {new CoordinatePoint(0, 18), new CoordinatePoint(0, 13.5), new CoordinatePoint(11, 4.5), new CoordinatePoint(6, 7), new CoordinatePoint(11, 16)};

        double[][] rangeReadings = {
                {2002.0, 2006.5, 2019.01, 2014.32, 2011.70},
                {2208.06, 2207.02, 2210.31, 2207.07, 2204.47},
                {2415.0, 2410.5, 2411.10, 2407.21, 2417.03},
                {2617.49, 2613.83, 2602.5, 2605.0, 2613.15}
        };
        //Phase 1 execution
        double[][] diffDistances = calculateDiffDistances(rangeReadings);
        for (int i = 0; i < ap_number; i++) {
            estimatedAP[i] = solveX(movementLocations, diffDistances[i]);
            System.out.printf("Estimated AP Location: (%.2f, %.2f)\n", estimatedAP[i].x, estimatedAP[i].y);
        }
        rangeErrorEachAP = calculateRangingErrors(ap_number, movementLocations, rangeReadings, estimatedAP);
        for (int i = 0; i < ap_number; i++) {
            System.out.printf("Constant ranging error for AP %d: %.2f\n", i + 1, rangeErrorEachAP[i]);
        }

        //Phase 2 Execution
        double[][] rangeReadingsForLocalization = {
                {2014.14, 2205.0, 2412.21, 2607.07},
                {2010.5, 2204.2, 2411.0, 2606.8}//number of column equal to ap_number, number of rows equal to locations
        };

        for (int i = 0; i < rangeReadingsForLocalization.length; i++) {
            CoordinatePoint localizedPosition = localizePosition(rangeErrorEachAP, estimatedAP, rangeReadingsForLocalization[i]);
            System.out.printf("Localized position of moving object: (%.2f, %.2f)\n", localizedPosition.x, localizedPosition.y);
        }
    }
}
