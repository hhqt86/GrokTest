package sg.edu.smu.teamrtt.localizertt.ui.drawSB1

//import androidx.compose.ui.graphics.Paint
import android.content.Context
import android.graphics.Paint
import android.icu.util.Calendar
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.createBitmap
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentDrawSb1Binding
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.model.dataview.DrawSB1DetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.research.map_visualization.OriginMask
import sg.edu.smu.teamrtt.localizertt.research.map_visualization.PointVal
import sg.edu.smu.teamrtt.localizertt.ui.imu.IMUViewModel
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.avgHumanStepInMeters
import sg.edu.smu.teamrtt.localizertt.util.gridHeight
import sg.edu.smu.teamrtt.localizertt.util.gridMaskTolerance
import sg.edu.smu.teamrtt.localizertt.util.gridResolution
import sg.edu.smu.teamrtt.localizertt.util.gridWidth
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min


/**
 * SOSS B1 User AP Draw Plot (Static View) Fragment (DrawSB1Frament)
 *
 * Hai's (and Thu) Probabilistic AP's location approach Version (used in period of August 2025)
 *
 * This UI Fragments has the following functionality:
 * 1. Renders the SOSS B1 Map on screen.
 * 2. Marks and captures the user position on screen based on where the user is when the user taps on the map.
 * 3. (Not yet) Renders the AP Location based on Hai's Constant Error LeastSquare Algo.
 * 4. This requires the WiFI RTT Scanning/Capturing be running in the background.
 *
 * William: DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 Aug 22: Created by William Tan Kiat Wee. (Adopted from older version DrawSB1FragmentOld1. See older version for details)
 * - 2025 Oct 13, William: Fragment is renamed to Static View when map is static and user plot is moving around the map.
 */
class DrawSB1Fragment : Fragment() {

    //  Hardcoded AP MAC For Testing Only. (To be remove in Production)
    //  Original:   private val apList = arrayOf(HARDCODED_AP0, HARDCODED_AP1, HARDCODED_AP2, HARDCODED_AP3, HARDCODED_AP4)
    //  Position 0 to flexible, see AppPrefStore.kt to set the target AP for testing.
    //private val apList = arrayOf(HARDCODED_AP_TARGET, HARDCODED_AP1, HARDCODED_AP2, HARDCODED_AP3, HARDCODED_AP4)

    /**
     * List of Support Columns Position meant to be plotted on map
     */
    private val listOfColumnsPositionForPlottingOnMap = arrayOf(
        CoordinatePoint(-1.0, 11.0),
        CoordinatePoint(7.0, 11.0),
        CoordinatePoint(-1.0, 3.0),
        CoordinatePoint(-9.0, 3.0),
        CoordinatePoint(7.0, 3.0),
        CoordinatePoint(-1.0, -4.0),
        CoordinatePoint(-9.0, -4.0),
        CoordinatePoint(7.0, -4.0)
    )


    /**
     * List of Access Point Position meant to be plotted on map
     */
    private val listOfAPPositionForPlottingOnMap = arrayOf(
        CoordinatePoint(-6.0, -8.0),
        CoordinatePoint(-6.0, -2.0),
        CoordinatePoint(-1.0, 3.0),
        CoordinatePoint(5.0, -3.0),
        CoordinatePoint(7.0, 3.0)
    )

    //  ===================================
    //      Plot/Device Drawable space
    //  ===================================

    //  SOSS B1 map (v1)
    //  465 pixels per 10 meters (Use GIMP, open image and measure the pixels that constitute 10 meters)
    // private val GRID10MPX = 465
    // private val ACTUAL_LENGTH_OF_SOSS_B1 = 33.82

    //  Hai's map (SOSS B1 V2)
    //  Horizontal: 42 pixels per meter (Use GIMP, open image and measure the pixels that constitute 10 meters)
    //  Vertical: 52 pixels per meter

    //  Default number of pixels per 1 meter. As our grid is a square. Vertical and Horizontal will use the same value.
    private val noOfPixelsPerMeter = 42.0f / 1.0f

    //  Previous: Where grid is non-square.
    //private val V2_HORIZONTAL_42PX_PER_METER1 = 42.0f / 1.0f
    //private val V2_VERTICALL_52PX_PER_METER1 = 52.0f / 1.0f
    private var noOfPixelsPerMeterInAxisX = noOfPixelsPerMeter
    private var noOfPixelsPerMeterInAxisY = noOfPixelsPerMeter

    //  Device's drawable space (Canvas)
    private var gCanvasWidth = 0.0f
    private var gCanvasHeight = 0.0f

    //  Center of the drawable space (values will be compute during runtime)
    //  Originally at (0, 200), changed to center of map by Hai. (This is done programmatically in code)
    var refOriginX = 0.0f
    var refOriginY = 0.0f


    //  ================
    //      Heatmap
    //  ================
    var refHeatmapWidth = 0.0f
    var refHeatmapHeight = 0.0f


    private var _binding: FragmentDrawSb1Binding? = null

    private var thisContext: Context? = null

    //  Handle to set/observe for stuff in DrawSB1Fragment
    private val drawDetailsViewModel: DrawSB1DetailsDataViewModel by activityViewModels()

    //  Handle to set/observe for stuff in IMU
    private val imuViewModel: IMUViewModel by activityViewModels()

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    private var captureTimeWindow = 20 * 1000L

    private var listOfAPCoordinatePoint: MutableList<CoordinatePoint> = mutableListOf()
    private var userCoordinatePoint: CoordinatePoint = CoordinatePoint(0.0, 0.0)

    private var targetCoordinatePoint: CoordinatePoint = CoordinatePoint(0.0, 0.0)
    private var targetShowFlag: Boolean = true

    //  Reference angle for correcting UI Plot
    private var referenceAngle = 0.0

    //  Current received IMU Azimuth
    private var azimuthInDegrees = 0.0

    private var selectedAP = ""

    //  For Heatmap plot
    private var hmpMask: Array<IntArray?>? = null
    private var maskBitmap = ImageBitmap(1, 1)

    private var currentListOfPointVal: MutableList<PointVal> = mutableListOf()

    private var flagIsLocalCreationTimestampSet = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        thisContext = this.context

        captureTimeWindow = thisContext?.let { AppPrefStore(it).loadCaptureTime() }!!

        val drawViewModel = ViewModelProvider(this).get(DrawSB1ViewModel::class.java)

        _binding = FragmentDrawSb1Binding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textDraw
        drawViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        val composeView = binding.composeView
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                DrawMap()
                CanvasDrawGrid()
            }
        }

        //  Setup the UI Button interactions
        setupUIComponents()

        //  Setup ViewModel Observers
        setupViewModelObservers(composeView)

        return root
    }


    /**
     * Setup UI View/Components and their interactions.
     * E.g. Buttons, Dropdown list, etc.
     */
    private fun setupUIComponents() {

        //  ======================================================================================================
        //  ======================================================================================================

        //  Button to Mark Reference Angle
        val buttonClear: Button = binding.buttonMark
        buttonClear.setOnClickListener {
            referenceAngle = azimuthInDegrees
            drawDetailsViewModel.setReferenceAngleForUI(referenceAngle.toFloat())
        }

        //  ======================================================================================================
        //  ======================================================================================================

        val parentViewGroup = buttonClear.parent as ViewGroup

        //  Button to Lock Reference Angle
        val buttonLockAngle: Button = binding.buttonLock

        //  Button Zoom In
        val buttonZoomIn: Button = binding.buttonZoomIn

        //  Button Zoom Out
        val buttonZoomOut: Button = binding.buttonZoomOut

        parentViewGroup.removeView(buttonLockAngle)
        parentViewGroup.removeView(buttonZoomIn)
        parentViewGroup.removeView(buttonZoomOut)

        //  ======================================================================================================
        //  ======================================================================================================

        //  Button for Update
        val buttonPlot: Button = binding.buttonUpdate
        buttonPlot.setOnClickListener {
            drawDetailsViewModel.setTriggerFlag(true)
        }

        //  ======================================================================================================
        //  ======================================================================================================

//        //  Drop down/up List for list of AP (AP0 to AP4)
//        if (thisContext != null) {
//            val spinner: Spinner = binding.spinnerApList
//            // Create an ArrayAdapter using the string array and a default spinner layout.
//            ArrayAdapter.createFromResource(
//                thisContext!!,
//                R.array.Test_AP_List,
//                android.R.layout.simple_spinner_item
//            ).also { adapter ->
//                // Specify the layout to use when the list of choices appears.
//                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                // Apply the adapter to the spinner.
//                spinner.adapter = adapter
//            }
//
//            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//                    selectedAP = apList[position]
//                    drawDetailsViewModel.setSelectedAP(selectedAP)
//                    //Log.i("William", "selectedAP=$selectedAP")
//                }
//
//                override fun onNothingSelected(parent: AdapterView<*>?) {
//                }
//            }
//        }
    }

    /**
     * Setup the Observers of various ViewModels
     */
    private fun setupViewModelObservers(composeView: ComposeView) {

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe for User Location changes (for displaying on screen)
        //  Update handle and redraw the user on screen.
        drawDetailsViewModel.currentUserCoordPosPoint.observe(viewLifecycleOwner, Observer { value ->

            userCoordinatePoint = value

            // Draw on screen
            drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe for predicted AP location
        //  Update local handle and redraw the AP on screen
        //  Updated from MainActivity WiFiProcessOps has computed the AP Locations
        //  Currently, commented out as code is not ready yet for new Trigo-Algo (Hai and Thu Aug 2025)
        drawDetailsViewModel.currentCoordAPPosList.observe(viewLifecycleOwner, Observer { value ->

            //listOfAPCoordinatePoint = value

            // Draw on screen
            // drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the Azimuth from the IMU data.
        //  In DrawSB1Fragment, this is only use for UI purpose, to draw the user direction on screen.
        imuViewModel.currentComputedDataOrientation.observe(viewLifecycleOwner) { value ->

            //  Get the orientation data
            val orientationData: FloatArray = value

            //  Convert to Degrees and update the handle
            azimuthInDegrees = (Math.toDegrees(orientationData[0].toDouble()) + 360) % 360
            //Log.i("William", "azimuthInDegrees=$azimuthInDegrees")

            // Draw on screen (of where the user is facing)
            drawScreen(composeView)

            //  Toggle this flag to mimic flashing on the canvas on the suggestion point.
            targetShowFlag = !targetShowFlag
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the step data from the IMU data.
        //  In DrawSB1Fragment, this is only use for UI purpose, to draw the user position on screen after every step.
        imuViewModel.currentSensorStepDetectedEvent.observe(viewLifecycleOwner) { value ->

            //  With each step, update Position on Screen,
            //  Given the average step of 0.76 meters and the direction the user is facing.
            userCoordinatePoint = calculatePositionInMetersWhenAStepIsTaken(
                userCoordinatePoint.x,
                userCoordinatePoint.y,
                azimuthInDegrees,
                noOfPixelsPerMeterInAxisX,
                noOfPixelsPerMeterInAxisY
            )

            // Draw on screen
            drawScreen(composeView)

            //  Convert position into meters and notify MainActivity (where Hai and Thu's Trigo-Algo Aug 2025 is being held and used)
            val userCoordinatePointInMeters = adjustToReferenceGrid(
                refOriginX,
                refOriginY,
                userCoordinatePoint.x.toFloat(),
                userCoordinatePoint.y.toFloat()
            )
            drawDetailsViewModel.setUserCoordPosPointInMeters(userCoordinatePointInMeters)
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the target point for the user to move to.
        //  This is updated in MainActivity via (Hai and Thu's Trigo-Algo Aug 2025)
        //  If there are any updates, we set the target and redraw the point on screen.
        drawDetailsViewModel.currentTargetCoordPosPointInMeters.observe(viewLifecycleOwner, Observer { value ->

            //  Update target location.
            targetCoordinatePoint = adjustToScreenGrid(refOriginX, refOriginY, value)

            // Draw on screen
            drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the List of PointVal updated via (Hai and Thu's Trigo-Algo Aug 2025) in MainActivity.
        //  List of PointVal is use to draw the Heatmap.
        //  Once the list is updated, we build the mask and draw the heatmap on screen.
        drawDetailsViewModel.currentListOfPointVal.observe(viewLifecycleOwner, Observer { value ->

            Log.i("William", "Build Mask in DrawSB1Fragment")

            //  Obtain the current list of PointVal
            currentListOfPointVal = value

            //  Grid (this is based on the SOSS B1 Map from Hai)
            val gridW = gridWidth * gridResolution
            val gridH = gridHeight * gridResolution
            hmpMask = OriginMask.buildMask(value, gridW.toInt(), gridH.toInt(), gridWidth, gridHeight, gridMaskTolerance)

            //  Create bitmap from hmpMask
            maskBitmap = createHmpMaskBitmap(refHeatmapWidth.toInt(), refHeatmapHeight.toInt())

            // Draw on screen
            drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================
    }

    /**
     * Draw or Re-Draw the Screen during any update.
     *
     * This is called from the view models during any data update.
     * In which, the whole screen is refreshed and data is redrawn.
     * These includes the map, tracked position, any AP plotted, etc.
     */
    private fun DrawSB1Fragment.drawScreen(composeView: ComposeView) {
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                DrawMap()
                PlotAP()
                PlotUser()
                PlotTarget()
                PlotHeatmap()
                CanvasDrawGrid()
            }
        }
    }

    /**
     * Canvas Drawing: Plot User on the map
     */
    @Composable
    fun PlotUser() {

        Canvas(modifier = Modifier.fillMaxSize()) {

            //  If user point is available
            if (userCoordinatePoint.x != 0.0 && userCoordinatePoint.y != 0.0) {

                // Log.i("William", "User Location. X=${userCoordinatePoint.x}, Y=${userCoordinatePoint.y}")

                val correctedAngleForUI = convertAzimuthToCartesianAngle(azimuthInDegrees)

                //  Drawing the line to represent the user's facing direction from the Azimuth data.
                //  To draw line, we need 2 point, since we already have the userCoordinatePoint,
                //  we just draw a short line of 70.0 pixels from that point along the azimuth/correctedAngleForUI
                val xPosToMove: Double = 70.0f * kotlin.math.cos(Math.toRadians(correctedAngleForUI))
                val yPosToMove: Double = 70.0f * kotlin.math.sin(Math.toRadians(correctedAngleForUI))

                val actualPosX = userCoordinatePoint.x
                val actualPosY = userCoordinatePoint.y

                //  Draw the circle representing the user
                drawCircle(
                    color = Color.Magenta,
                    radius = 7.dp.toPx(),
                    center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                )

                //  Draw the line representing the user facing direction.
                drawLine(
                    start = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                    end = Offset((actualPosX + xPosToMove).toFloat(), (actualPosY + yPosToMove).toFloat()),
                    color = Color.Magenta,
                    strokeWidth = 10f

                )
            }
        }
    }

    /**
     * Canvas Drawing: Plot Suggest Point (Target) on the map
     */
    @Composable
    fun PlotTarget() {

        Canvas(modifier = Modifier.fillMaxSize()) {

            //  If target point is available (targetFlashingFlag is toggle by IMU to mimic flashing on the canvas)
            if (targetShowFlag && targetCoordinatePoint.x != 0.0 && targetCoordinatePoint.y != 0.0) {

                //Log.i("William", "Target Location. X=${targetCoordinatePoint.x}, Y=${targetCoordinatePoint.y}")

                drawCircle(
                    color = Color(0xFF78620A),  //  Colour: Gold.
                    radius = 9.dp.toPx(),
                    center = Offset(targetCoordinatePoint.x.toFloat(), targetCoordinatePoint.y.toFloat()),
                )
            }
        }
    }

    /**
     * Canvas Drawing: Plot AP on the map
     */
    @Composable
    fun PlotAP() {

        //  Use to plot text
        val textMeasurer = rememberTextMeasurer()

        //  Plot the list of AP in the store(listOfAPCoordinatePoint)
        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            // val interval = canvasWidth / numOfMakers

            //  Iterate thru each Point and plot it.
            for (eachCoordinatePoint in listOfAPCoordinatePoint) {

                //  Get the index of each Point
                val returnedIndex = 0 //getIndexFromMac(eachCoordinatePoint.label)

                //  Conversion
                val posXcanvas = eachCoordinatePoint.x * noOfPixelsPerMeterInAxisX
                val posYcanvas = eachCoordinatePoint.y * noOfPixelsPerMeterInAxisY
                // var posXcanvas = eachCoordinatePoint.x * interval
                // var posYcanvas = eachCoordinatePoint.y * interval

                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                //  Check if point is within the Canvas
                if (actualPosX in 0.0..canvasHeight.toDouble() && actualPosY >= 0 && actualPosY <= canvasWidth) {

                    //  Draw Circle
                    drawCircle(
                        color = Color.Yellow,
                        radius = 7.dp.toPx(),
                        center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                    )

                    //  Draw Text
                    drawText(
                        textMeasurer = textMeasurer,
                        text = "$returnedIndex",
                        topLeft = Offset(actualPosX.toFloat(), actualPosY.toFloat() + 5F),
                        style = TextStyle(
                            color = Color.Black,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )
                    )
                }
                //else {
                //    Log.i("William", "Not Plotting Point. X=${eachCoordinatePoint.x}, Y=${eachCoordinatePoint.y}")
                //}
            }
        }
    }

    /**
     * Canvas Drawing: Plot Heatmap on the map
     */
    @Composable
    fun PlotHeatmap() {

        //  Plot only when the refMap handles are updated.
        if (refHeatmapWidth > 0 && refHeatmapHeight > 0) {

            //  Setup the mask Plot Position
            val coordOfMask = adjustToScreenGrid(refOriginX, refOriginY, CoordinatePoint(-10.0, 11.0))

            if (maskBitmap.height > 1 && maskBitmap.width > 1) {
                Canvas(modifier = Modifier.fillMaxSize(), onDraw = {
                    drawImage(
                        image = maskBitmap,
                        dstSize = IntSize(
                            width = refHeatmapWidth.toInt(),
                            height = refHeatmapHeight.toInt()
                        ),
                        dstOffset = IntOffset(x = coordOfMask.x.toInt(), y = coordOfMask.y.toInt())
                        //dstOffset = IntOffset(x = refHeatMapX.toInt(), y = refHeatMapY.toInt())
                    )

                    //Log.i("William", "Drawn. maskBitmap: ${maskBitmap.width}")
                })
            }
        }
    }

    /**
     * Create Bitmap from HmpMask (Heatmap)
     *
     * Given:
     * 1. HmpMask
     * 2. bitmapWidth, bitmapHeight The bitmap size to be created.
     *
     * Create and return a bitmap image repsenting the heatmap (HmpMask) defined by the bitmapWidth, bitmapHeight
     */
    private fun createHmpMaskBitmap(width: Int, height: Int): ImageBitmap {

        val bitmap = createBitmap(width, height)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = Paint()

        //  If mask data is avalilable
        if (hmpMask != null) {

            val gridH: Int = hmpMask!!.size
            val gridW: Int = hmpMask!![0]?.size!!

            //Log.i("William", "gridH: $gridH, gridW: $gridW")
            //Log.i("William", "refMapWidth: $refMapWidth, refMapHeight: $refMapHeight")

            val boxW = refHeatmapWidth / gridW.toFloat()
            val boxH = refHeatmapHeight / gridH.toFloat()

            //Log.i("William", "boxW: $boxW, boxH: $boxH")

            // Find max in mask for normalization
            val nPoints = currentListOfPointVal.size
            val max = nPoints * (nPoints - 1) / 2
            val normDen: Int = Math.max(1, max)

            for (gy in 0..<gridH) {
                for (gx in 0..<gridW) {

                    val t: Double = hmpMask!![gy]?.get(gx)!!.toDouble() / normDen.toDouble() // normalize to [0,1]

                    val c: Color = colormapTurbo(t)
                    val adjustColor = Color(c.red, c.green, c.blue, 0.5f)
                    paint.color = adjustColor.toArgb()

                    val x = floor(gx * boxW).toInt()
                    val y = floor(gy * boxH).toInt()
                    ceil((gx + 1) * boxW).toInt() - x
                    ceil((gy + 1) * boxH).toInt() - y

                    //Log.i("William", "x: $x, y: $y, adjustColor: $adjustColor")

                    canvas.drawRect(
                        (x.toFloat()),
                        (y.toFloat()),
                        (x.toFloat()) + boxW,
                        (y.toFloat()) + boxH,
                        paint
                    )

                }
            }
        }

        return bitmap.asImageBitmap()
    }

    private fun colormapTurbo(t: Double): Color {
        var t = t
        t = max(0.0, min(1.0, t))
        // Piecewise polynomial-ish approximation
        val r = min(1.0, max(0.0, 1.7 * t - 0.3))
        val g = min(1.0, max(0.0, -4 * (t - 0.5) * (t - 0.5) + 1))
        val b = min(1.0, max(0.0, 1.4 - 1.7 * t))
        return Color(r.toFloat(), g.toFloat(), b.toFloat())
    }

//    private fun DrawScope.colormapTurbo(t: Double): Color {
//        var t = t
//        t = max(0.0, min(1.0, t))
//        // Piecewise polynomial-ish approximation
//        val r = min(1.0, max(0.0, 1.7 * t - 0.3))
//        val g = min(1.0, max(0.0, -4 * (t - 0.5) * (t - 0.5) + 1))
//        val b = min(1.0, max(0.0, 1.4 - 1.7 * t))
//        return Color(r.toFloat(), g.toFloat(), b.toFloat())
//    }

    /**
     * Canvas Drawing: Draw Basic Map
     * 1. White back ground.
     * 2. Black dot at center.
     * 3. Calculate the plot parameters.
     */
    @Composable
    fun DrawMap() {

        val textMeasurer = rememberTextMeasurer()

        //  https://stackoverflow.com/questions/77299943/draw-image-with-fixed-height-and-width-jetpack-compose-canvas-using-drawimage
        Canvas(
            modifier = Modifier
                .fillMaxSize(), onDraw = {

                //  Capture the canvas width and height
                gCanvasWidth = size.width
                gCanvasHeight = size.height

                //  Get the midpoint of canvas.
                refOriginX = gCanvasWidth / 2
                refOriginY = gCanvasHeight / 2

                //  Setup Heatmap size
                refHeatmapWidth = 20 * noOfPixelsPerMeter
                refHeatmapHeight = 22 * noOfPixelsPerMeter

                val canvasQuadrantSize = size
                drawRect(
                    color = Color.White,
                    size = canvasQuadrantSize
                )

                //  Draw Map Columns
                for (eachCol in listOfColumnsPositionForPlottingOnMap) {
                    val adjustedCoord = adjustToScreenGrid(refOriginX, refOriginY, eachCol)

                    drawCircle(
                        color = Color.Red,
                        radius = 9.dp.toPx(),
                        center = Offset(adjustedCoord.x.toFloat(), adjustedCoord.y.toFloat()),
                    )
                }

                //  Draw Map AP
                var counter = 0
                for (eachCol in listOfAPPositionForPlottingOnMap) {
                    val adjustedCoord = adjustToScreenGrid(refOriginX, refOriginY, eachCol)

                    drawCircle(
                        color = Color.Blue,
                        radius = 7.dp.toPx(),
                        center = Offset(adjustedCoord.x.toFloat(), adjustedCoord.y.toFloat()),
                    )

                    drawText(
                        textMeasurer = textMeasurer,
                        text = "$counter",
                        topLeft = Offset(adjustedCoord.x.toFloat() + 10f, adjustedCoord.y.toFloat() + 10f),
                        style = TextStyle(
                            color = Color.Blue,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )
                    )

                    counter++
                }

                //  Center
                drawCircle(
                    color = Color.Black,
                    radius = 5.dp.toPx(),
                    center = Offset(refOriginX.toFloat(), refOriginY.toFloat()),
                )
            })
    }

    /**
     * Canvas Drawing: Draw Grid
     */
    @Composable
    fun CanvasDrawGrid() {

        //  Tap: https://stackoverflow.com/questions/68363029/how-to-add-click-events-to-canvas-in-jetpack-compose
        //  https://medium.com/@fctdev/drawing-with-compose-836eadd1a308
        //  https://github.com/SebastienFCT/articles/blob/main/code-samples/DrawingCanvasExample/app/src/main/java/com/tectes/drawingcanvasexample/DrawingCanvas.kt
        // [START android_compose_graphics_canvas_diagonal_line]

        // Log.i("William", "CanvasDrawGrid")

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { tapOffset ->
                        capturePointOnTap(tapOffset)
                    })
                }

        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            drawGridHorizontalMarkers(heightMid, widthMid, noOfPixelsPerMeterInAxisX, canvasWidth)
            drawGridVerticalMarkers(heightMid, widthMid, noOfPixelsPerMeterInAxisY, canvasHeight)
        }
    }

    private fun DrawScope.drawGridHorizontalMarkers(heightMid: Float, widthMid: Float, interval: Float, canvasWidth: Float) {

        //  Draw Horizontal Markers
        var posFlag = true
        var startPoint = widthMid
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = 0f),
                end = Offset(x = startPoint, y = heightMid * 2),
                color = Color.Black
            )
            startPoint -= interval
            if (startPoint <= 0)
                posFlag = false
        }

        posFlag = true
        startPoint = widthMid
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = 0f),
                end = Offset(x = startPoint, y = heightMid * 2),
                color = Color.Black
            )
            startPoint += interval
            if (startPoint >= canvasWidth)
                posFlag = false
        }
    }

    private fun DrawScope.drawGridVerticalMarkers(
        heightMid: Float,
        widthMid: Float,
        interval: Float,
        canvasHeight: Float
    ) {
        //  Draw Vertical Markers Reverse
        var posFlag = true
        var startPoint = heightMid
        while (posFlag) {
            drawLine(
                start = Offset(x = 0f, y = startPoint),
                end = Offset(x = widthMid * 2, y = startPoint),
                color = Color.Black
            )
            startPoint -= interval
            if (startPoint <= 0)
                posFlag = false
        }


        //  Draw Vertical Markers Forward
        posFlag = true
        startPoint = heightMid
        while (posFlag) {
            drawLine(
                start = Offset(x = 0f, y = startPoint),
                end = Offset(x = widthMid * 2, y = startPoint),
                color = Color.Black
            )
            startPoint += interval
            if (startPoint >= canvasHeight)
                posFlag = false
        }
    }

    /**
     * Triggered when user tap on Canvas
     *
     * This is setup for CanvasDrawGrid() function.
     */
    private fun capturePointOnTap(tapOffset: Offset) {

        //Log.i("William", "tapOffset: $tapOffset")

        val userCoordinatePointInMeters = adjustToReferenceGrid(refOriginX, refOriginY, tapOffset.x, tapOffset.y)
        drawDetailsViewModel.setUserCoordPosPointInMeters(userCoordinatePointInMeters)

        //  Mark coordinate for UI
        //userCoordinatePoint = CoordinatePoint(tapOffset.x.toDouble(), tapOffset.y.toDouble(), azimuthInDegrees.toDouble())
        drawDetailsViewModel.setUserCoordPosPoint(CoordinatePoint(tapOffset.x.toDouble(), tapOffset.y.toDouble(), azimuthInDegrees.toDouble()))

        //  Mark the time the user initial position. (Do only once)
        if (!flagIsLocalCreationTimestampSet) {
            flagIsLocalCreationTimestampSet = true
            drawDetailsViewModel.setCreationTimestamp(Calendar.getInstance().timeInMillis)
        }
        //  original:
        //drawDetailsViewModel.setCreationTimestamp(Calendar.getInstance().timeInMillis)
    }

//    private fun testMask() {
//
//        val data: MutableList<PointVal?> = RandomPoints.generatePoints(
//            10,
//            50.0,
//            30.0,
//            gCanvasWidth.toDouble() / 2,
//            gCanvasHeight.toDouble() / 2,
//            0.0,
//            0.0,
//            1.0
//        )
//
////        for(eachPoint in data) {
////            Log.i("William", "eachPoint: $eachPoint")
////        }
//
//        val gridW = 21 * 20
//        val gridH = 22 * 20
//        hmpMask = OriginMask.buildMask(data, gridW, gridH, 21.0, 22.0, 1.0)
//    }

    /**
     * Adjust to (Human) Actual Grid
     *
     * Calculate the real space position in meters given the position on screen/canvas.
     *
     * To convert, we are given:
     * 1. refX, refY which are the screen/canvas midpoint (where the canvas starts at the 0,0 top-left).
     * The height and width are device dependent. E.g. Pixel7 has a different screen size compare Pixel5 or Samsung phone, etc
     *
     * 2. The coordinate measuredX, measuredY in pixel to be converted.
     *
     * Returns the coordinate in real space position (reference grid 0,0 at the center)
     */
    private fun adjustToReferenceGrid(refX: Float, refY: Float, measuredX: Float, measuredY: Float): CoordinatePoint {

        var actualXInMeters = 0.0f
        if (measuredX < refX) {
            actualXInMeters = -1.0f * (refX - measuredX) / noOfPixelsPerMeterInAxisX
        } else if (measuredX > refX) {
            actualXInMeters = (measuredX - refX) / noOfPixelsPerMeterInAxisX
        }

        var actualYInMeters = 0.0f
        if (measuredY < refY) {
            actualYInMeters = (refY - measuredY) / noOfPixelsPerMeterInAxisY
        } else if (measuredY > refY) {
            actualYInMeters = -1.0f * (measuredY - refY) / noOfPixelsPerMeterInAxisY
        }

        return CoordinatePoint(actualXInMeters.toDouble(), actualYInMeters.toDouble())
    }


    /**
     * Adjust to (Device) Screen Grid
     *
     * Calculate the (device) screen/canvas equivalent position given the actual position in meters.
     *
     * To convert, we are given:
     * 1. refX, refY which are the screen/canvas midpoint (where the canvas starts at the 0,0 top-left).
     * The height and width are device dependent. E.g. Pixel7 has a different screen size compare Pixel5 or Samsung phone, etc
     *
     * 2. The coordinate in meters to convert.
     *
     * Returns the coordinate in pixel position (from top-left)
     *
     */
    private fun adjustToScreenGrid(refX: Float, refY: Float, coordinatePointInMeters: CoordinatePoint): CoordinatePoint {

        var adjustedXInPixel = 0.0
        if (coordinatePointInMeters.x > 0) {
            adjustedXInPixel = refX + (coordinatePointInMeters.x * noOfPixelsPerMeterInAxisX)
        } else if (coordinatePointInMeters.x < 0) {
            adjustedXInPixel = refX - (-1.0 * coordinatePointInMeters.x * noOfPixelsPerMeterInAxisX)
        }

        var adjustedYInPixel = 0.0
        if (coordinatePointInMeters.y > 0) {
            adjustedYInPixel = refY - (coordinatePointInMeters.y * noOfPixelsPerMeterInAxisY)
        } else if (coordinatePointInMeters.y < 0) {
            adjustedYInPixel = refY + (-1.0 * coordinatePointInMeters.y * noOfPixelsPerMeterInAxisY)
        }

        return CoordinatePoint(adjustedXInPixel, adjustedYInPixel)
    }

    /**
     * Calculate Position (in meters) When a human step is taken.
     *
     * This function is called when a step is taken to calculate the new position, given the current azimuth.
     * Given:
     * 1. The Coordinates X, Y in meters
     * 2. The Azimuth the user is in.
     * 3. The Reference angle we are referencing from.
     * We move the user in a human step distance (Asian Human Step), given the azimuth. As the distance is tracked in cartesian coordinate.
     * The azimuth is first converted to the cartesian plane, given a reference angle (an angle which we set as a reference.)
     *
     * Returns the new coordinates (in meters)
     */
    fun calculatePositionInMetersWhenAStepIsTaken(
        coordXForScreen: Double,
        coordYForScreen: Double,
        azimuthInDegrees: Double,
        referencePixelPerMeterX: Float,
        referencePixelPerMeterY: Float
    ): CoordinatePoint {

        val correctedAngleForUI = convertAzimuthToCartesianAngle(azimuthInDegrees)

        val movedX: Double = avgHumanStepInMeters * referencePixelPerMeterX * kotlin.math.cos(Math.toRadians(correctedAngleForUI))
        val movedY: Double = avgHumanStepInMeters * referencePixelPerMeterY * kotlin.math.sin(Math.toRadians(correctedAngleForUI))

        val adjustedX = coordXForScreen + movedX
        val adjustedY = coordYForScreen + movedY

        return CoordinatePoint(adjustedX, adjustedY, correctedAngleForUI)
    }

    /**
     * Correct Angle for SB1 Grid superimpose over the Grid-picture.
     *
     * Why?
     * The Grid chosen by Hai has the following issue:
     * 1. Azimuth is reference to Magnetic North.
     * 2. Grid (with the Picture of SB1) is not align to magnetic north.
     * In order to plot correctly the user facing direction in the grid, we need to correct Azimuth data to the grid.
     *
     * 1. Reference Angle is the angle set by the user, facing towards the  direction of tg the stairs in SB1.
     * 2. As the grid is not align to Magnetic North. (Actual Azimuth is 290 degrees approx)
     * 3. Hence with reference angle, with correct to the Grid alignment.
     * 4. Since we are plotting against cartesian plane, the angle starts at horizontal axis = 0 clockwise rotation.
     * 5. Hence, the Grid alignment facing the stairs in SB1 will need to be rotated 270 degrees.
     *
     * At the end of the process, the the corrected angle is now align to the SB1 Grid Picture in the app.
     */
    private fun convertAzimuthToCartesianAngle(azimuthInDegrees: Double): Double {

        //  Correct for screen drawing if reference angle is used.
        var correctedAngleForUI = azimuthInDegrees - referenceAngle
        if (correctedAngleForUI < 0) {
            correctedAngleForUI = 360 + correctedAngleForUI
        }

        //  Correct to Grid where the 0 degrees starts from vertical axis instead of horizontal
        //  We can either -90 degrees or +270, I do +270, easier to deal with mod operator.
        correctedAngleForUI = (correctedAngleForUI + 270) % 360
        return correctedAngleForUI
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}