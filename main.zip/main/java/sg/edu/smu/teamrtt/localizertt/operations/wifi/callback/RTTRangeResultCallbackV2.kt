package sg.edu.smu.teamrtt.localizertt.operations.wifi.callback

import android.annotation.SuppressLint
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.RangingResult
import android.net.wifi.rtt.RangingResultCallback
import android.util.Log
import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangingOpsV2
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations

/**
 * RTT Range Result Callback
 * (Implements the RangingResultCallback Interface)
 *
 * 1. Handles what happens if a range fails.
 * 2. Handles what occurs when range is success.
 *
 * In this implementation, in either mode, the callback will do the following:
 * 1. Setup the next AP range request, in the list of range request.
 * 2. Calls the AP Ranging AP with the range request.
 * 3. This is then recursively call again on Step 1 and 2 until all AP in the list is exhausted.
 * 4. This allows us to range the AP one at a time, setting up the next range after the previous one is completed (or fail)
 * 5. We are doing this to avoid issues with the chunk approach: Where a chunk of AP is set the to Range API where if 1 fails, all failed.
 * 6. Whereas this approach ensures only 1 AP is range at only 1 time.
 *
 * RTTRangeResultCallback is used in RTTRangingOps Class.
 *
 * @author William Tan Kiat Wee 2025 Sep 18.
 * Tracking:
 * 1. 2025 Nov 03, William Tan: New Operations blah blah blah
 */
class RTTRangeResultCallbackV2(
    val currentRequest: RangingRequest,
    var requestCounter: Int,
    var handle: RTTRangingOpsV2
) : RangingResultCallback() {

    //  TAG for Logging
    private val TAG = this.javaClass.name

    /**
     * See Docs: We are just implementing the interface.
     * For Error.
     */
    override fun onRangingFailure(code: Int) {

        //  Log the error when ranging fail and on which request.
        val errorMessage: String = when (code) {
            STATUS_CODE_FAIL -> "Ranging fail"
            STATUS_CODE_FAIL_RTT_NOT_AVAILABLE -> "RTT Not Available"
            else -> "Unknown"
        }

        Log.e(
            TAG,
            "  -- Ranging Failure. Error code: $code, $errorMessage. For $currentRequest"
            //"   - Ranging Error. Error code: $code, $errorMessage. Respond Index: ${reponseSetCounter}, Timestamp: ${Calendar.getInstance().timeInMillis}"
        )

        //  execute next RangeRequest
        rangeNextBSSID()
    }

    /**
     * See Docs: We are just implementing the interface.
     * For when result is available.
     */
    override fun onRangingResults(results: List<RangingResult?>) {

        //  DEBUG Log
        Log.i(TAG, "  -- Ranging Success. Result: ${results}. For $currentRequest")

        //  Local list for ViewModel updating
        val vmListOfRTTRangingResults: MutableList<RangingResult> = mutableListOf()

        //  Add to results to holder
        for (eachResult in results) {
            if (eachResult != null) {
                //Log.i(TAG, "    ---- RTT Range Result: $eachResult")

                //  Store the ranging result into final holder (to sort and identify candidate BSSID and ignore list)
                handle.listOfRTTRangingResults.add(eachResult)

                //  Store the ranging result into holder for updating the other hooks (other parts) that require the RangeResult
                //  E.g. The UI that shows the BSSID' details as well as MainActivity ProcessOps that is collecting the data to calculate PointVal
                vmListOfRTTRangingResults.add(eachResult)
            }
        }

        //  Save RTT Ranging to CSV
        if (vmListOfRTTRangingResults.isNotEmpty()) {
            val savingToCSVThread = Thread {
                handle.mainActivityContext.let { it1 ->
                    CSVOperations().saveToCSVRTTData(it1, vmListOfRTTRangingResults.toMutableList())
                }
            }
            savingToCSVThread.start()
        }

        //  Update the data so that Fragment and WiFiProcessOps can access
        if (vmListOfRTTRangingResults.isNotEmpty())
            handle.rttDetailsViewModel.setRangingResult(vmListOfRTTRangingResults.toMutableList())

        //  Range next RangeRequest
        rangeNextBSSID()
    }

    /**
     * Setup the next RTT Ranging after the result is captured Or failed.
     *
     * Recursively setup the Callback and range next BSSID (in the list)
     * Continue to do so until the list is exhausted, then clear the flag for next ranging.
     */
    @SuppressLint("MissingPermission")
    private fun rangeNextBSSID() {

        //  The requestCounter has been incremented since the last range,
        //  Hence, we check if the index is within the list.
        //  If not, list is exhausted, recursive call ends.
        if (requestCounter < handle.listOfRangingRequests.size) {

            // Log.i(TAG, " - requestCounter Next ${requestCounter}}")

            //  Get the next and single range request
            val singleRangeRequest = handle.listOfRangingRequests[requestCounter]

            //  Increment the counter to the next index.
            requestCounter++

            val recursiveRangeResultCallback = RTTRangeResultCallbackV2(
                singleRangeRequest,
                requestCounter,
                handle
            )

            //  Pass it on for RTT range
            handle.mainExecutor = handle.mainActivityContext.mainExecutor
            handle.mainExecutor.let {

                //  Start the range.
                if (it != null) {

                    //Log.i(TAG, " - Ranging Next ${singleRangeRequest}}")

                    handle.wifiRttManager.startRanging(
                        singleRangeRequest,
                        it,
                        recursiveRangeResultCallback
                    )
                }
            }
        } else {
            //  Recursive call ends, resets flag to true for next RTT Range.

            //  Sort all collected Range Result
            handle.sortRTTRangeResult()

            //  If held at false, the next RTT Range cannot happen.
            handle.rangeRTTIsFreeFlag = true
            // Log.i(TAG, " - Complete.")
        }
    }
}