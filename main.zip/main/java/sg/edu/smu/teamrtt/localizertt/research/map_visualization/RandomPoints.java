package sg.edu.smu.teamrtt.localizertt.research.map_visualization;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Utility for generating random 2D points with values
 * = distance to (x0,y0) + errorCoef + Normal(mu,sigma).
 * <p>
 * William Notes, 2025 Aug 28: Use for testing only in Android app.
 *
 * @author Thu Tran, 2025 Aug 27.
 * Tracking:
 * - 2025 Aug 27: Migrated from Thu's GIT codebase.
 */
public final class RandomPoints {

    private RandomPoints() {
    }

    /**
     * Generate k points uniformly in [-width/2,width/2] x [-height/2,height/2].
     * For each point, compute: distance((x,y),(x0,y0)) + errorCoef + Normal(mu, sigma).
     */
    public static List<PointVal> generatePoints(int k,
                                                double width,
                                                double height,
                                                double x0,
                                                double y0,
                                                double errorCoef,
                                                double mu,
                                                double sigma) {
        if (k < 0) throw new IllegalArgumentException("k must be >= 0");
        if (width <= 0 || height <= 0) throw new IllegalArgumentException("width/height must be > 0");
        if (sigma < 0) throw new IllegalArgumentException("sigma must be >= 0");

        ThreadLocalRandom tlr = ThreadLocalRandom.current();
        List<PointVal> result = new ArrayList<>(k);

        for (int i = 0; i < k; i++) {
            double x = tlr.nextDouble(-width / 2, width / 2);
            double y = tlr.nextDouble(-height / 2, height / 2);

            double distance = Math.hypot(x - x0, y - y0);
            double gaussian = tlr.nextGaussian() * sigma + mu;
            double value = distance + errorCoef + gaussian;

            result.add(new PointVal(x, y, value));
        }
        return result;
    }
}
