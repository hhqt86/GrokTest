package sg.edu.smu.teamrtt.localizertt.util

import android.content.Context
import android.net.wifi.rtt.RangingResult
import android.os.Environment
import androidx.datastore.preferences.core.booleanPreferencesKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import sg.edu.smu.teamrtt.localizertt.dataStoreW
import sg.edu.smu.teamrtt.localizertt.research.map_visualization.PointVal
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone


/**
 * CSV Operations
 *
 * All CSV Operations used in projects
 *  1. Store Scan results to CSV.
 *
 * Notes:
 *  1. Uses DataStore
 *
 * Ref:
 * //https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/DataStoreManager.kt
 * //val Context.dataStoreW: DataStore<Preferences> by preferencesDataStore(name = "appConfig")
 *
 * @author William Tan Kiat Wee, 2025 Apr 11.
 */
class CSVOperations {

    /**
     * 2025 Apr 4: Temporary code for saving to CSV for Hai to develop Algo: Can be removed once development is over.
     */
    fun saveStepAzimuthToCSV(context: Context, timestamp: Long, stepLogged: Long, azimuthData: Float, xPos: Double, yPos: Double) {

        //  Async Save to DataStore
        //  https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/MainActivity.kt
        CoroutineScope(Dispatchers.IO).launch {

            val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
            val values = context.dataStoreW.data.first()
            val flag = values[flagSaveToCSV] ?: false
            if (flag) {
                // Log.i("William", "saveStepCountToCSV: Saving to CSV is enabled!")

                val fileName = generateTimestampFileName("StepCountAzimuthData")

                val resultInStr = "${timestamp},${stepLogged},${azimuthData},${xPos},${yPos}\n"

                val headersOfCSV = "CapturedTime,StepID,Azimuth,X,Y"

                saveToFileUsingMediaStore(fileName, resultInStr, headersOfCSV)
            }
        }
    }

    /**
     * Save Accelerometer Data to CSV
     *
     * Capture:
     * 1. Timestamp
     * 2. Accelerometer data in  Axis-X, Axis-Y, Axis-Z
     *
     * Save to CSV file. Format "AccelerometerData_Year_Month_Date.csv"
     */
    fun saveToCSVAccelrometer(context: Context, timestamp: Long, axisX: Float, axisY: Float, axisZ: Float) {

        //  Save to CSV using the general 3 Parts function which is common for data that only has 3 parts.
        saveToCSV3Parts(context, "AccelerometerData", "capturedTime,axis_x,axis_y,axis_z", timestamp, axisX, axisY, axisZ)
    }

    /**
     * Save Magnetic Field Data to CSV
     *
     * Capture:
     * 1. Timestamp
     * 2. Magnetic Field data in  Axis-X, Axis-Y, Axis-Z
     *
     * Save to CSV file. Format "MagneticFieldData_Year_Month_Date.csv"
     */
    fun saveToCSVMagneticField(context: Context, timestamp: Long, axisX: Float, axisY: Float, axisZ: Float) {

        //  Save to CSV using the general 3 Parts function which is common for data that only has 3 parts.
        saveToCSV3Parts(context, "MagneticFieldData", "capturedTime,axis_x,axis_y,axis_z", timestamp, axisX, axisY, axisZ)
    }

    /**
     * Save Gyroscope Data to CSV
     *
     * Capture:
     * 1. Timestamp
     * 2. Gyroscope Field data in  Axis-X, Axis-Y, Axis-Z
     *
     * Save to CSV file. Format "GyroData_Year_Month_Date.csv"
     */
    fun saveToCSVGyroscope(context: Context, timestamp: Long, axisX: Float, axisY: Float, axisZ: Float) {

        //  Save to CSV using the general 3 Parts function which is common for data that only has 3 parts.
        saveToCSV3Parts(context, "GyroData", "capturedTime,axis_x,axis_y,axis_z", timestamp, axisX, axisY, axisZ)
    }

    /**
     * Save Orientation Data to CSV
     *
     * Capture:
     * 1. Timestamp
     * 2. Orientation data of Azimuth, Pitch, Roll
     *
     * Save to CSV file. Format "OrientationData_Year_Month_Date.csv"
     */
    fun saveToCSVOrientation(context: Context, timestamp: Long, azimuth: Float, pitch: Float, roll: Float) {

        //  Save to CSV using the general 3 Parts function which is common for data that only has 3 parts.
        saveToCSV3Parts(context, "OrientationData", "capturedTime,azimuth,pitch,roll", timestamp, azimuth, pitch, roll)
    }


    fun saveToCSVGPSLocation(context: Context, timestamp: Long, lat: Double, lng: Double, atd: Double) {

        //  Save to CSV using the general 3 Parts function which is common for data that only has 3 parts.
        saveToCSV3Parts(context, "LocationData", "capturedTime,latitude,longitude,attitude", timestamp, lat.toFloat(), lng.toFloat(), atd.toFloat())
    }

    fun saveToCSVGooglePlayAPILocation(context: Context, timestamp: Long, lat: Double, lng: Double, atd: Double) {

        //  Save to CSV using the general 3 Parts function which is common for data that only has 3 parts.
        saveToCSV3Parts(context, "LocationGPData", "capturedTimeGooglePlay,latitude,longitude,attitude", timestamp, lat.toFloat(), lng.toFloat(), atd.toFloat())
    }

    /**
     * General Function Save to CSV with sensors that has 3 parts.
     *
     * Save using:
     * 1. File name
     * 2. Headers of the CSV
     * 3. Timestamp
     * 4. Part 1 - 1st part of the 3 parts data. In Accelerometer, this is the axis-X data, etc.
     * 5. Part 2 - 2nd part of the 3 parts data. In Accelerometer, this is the axis-Y data, etc.
     * 6. Part 3 - 3rd part of the 3 parts data. In Accelerometer, this is the axis-Z data, etc.
     *
     */
    private fun saveToCSV3Parts(context: Context, fileName: String, headersOfCSV: String, timestamp: Long, part1: Float, part2: Float, part3: Float) {

        //  Async Save
        CoroutineScope(Dispatchers.IO).launch {

            //  Check if the CSV file save is toggle ON (True)
            val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
            val values = context.dataStoreW.data.first()
            val flag = values[flagSaveToCSV] ?: false
            if (flag) {

                //  Generate the filename
                val fileSName = generateTimestampFileName(fileName)

                //  Prepare the data
                val resultInStr = "${timestamp},${part1},${part2},${part3}\n"

                //  Save to file/or append to file.
                saveToFileUsingMediaStore(fileSName, resultInStr, headersOfCSV)
            }
        }
    }

    /**
     * Save Step Count to CSV
     *
     * Save using:
     * 1. Timestamp
     * 2. Steps Count captured
     *
     * Save to CSV file. Format "StepCountData_Year_Month_Date.csv"
     */
    fun saveToCSVStepCount(context: Context, timestamp: Long, stepLogged: Long) {

        //  https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/MainActivity.kt
        //  Check if the CSV file save is toggle ON (True)
        CoroutineScope(Dispatchers.IO).launch {

            val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
            val values = context.dataStoreW.data.first()
            val flag = values[flagSaveToCSV] ?: false
            if (flag) {

                // val timeZone: TimeZone = TimeZone.getTimeZone("Asia/Singapore")
                // val timeYear = Calendar.getInstance(timeZone).get(Calendar.YEAR)
                // val timeMonth = Calendar.getInstance(timeZone).get(Calendar.MONTH) + 1
                // val timeDate = Calendar.getInstance(timeZone).get(Calendar.DATE)

                val fileName = generateTimestampFileName("StepCountData")

                val headersOfCSV = "capturedTime,StepsLogged"
                val resultInStr = "${timestamp},${stepLogged}\n"

                saveToFileUsingMediaStore(fileName, resultInStr, headersOfCSV)
            }
        }
    }

    /**
     * Generate Filename given a basic name
     *
     * Generate filename like AccelerometerData_2025_12_31.csv
     * Where the Basic name is appended to the YEAR_MONTH_DATE
     *
     */
    private fun generateTimestampFileName(fileName: String): String {

        val timeZone: TimeZone = TimeZone.getTimeZone("Asia/Singapore")

        val timeYear = Calendar.getInstance(timeZone).get(Calendar.YEAR)
        val timeMonth = Calendar.getInstance(timeZone).get(Calendar.MONTH) + 1
        val timeDate = Calendar.getInstance(timeZone).get(Calendar.DATE)

        val genFileName = "${fileName}_${timeYear}_${timeMonth}_${timeDate}.csv"

        return genFileName
    }

    /**
     * Save WiFi RTT Scan to CSV
     *
     *  1. Check if saving to file is needed via DataStore
     *  2. Only save to file is configuration is toggle in Configuration page.
     *
     *  Ref:
     *      https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/MainActivity.kt
     */
    fun saveToCSVRTTData(context: Context, listOfScanResults: List<RangingResult>) {

        //  https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/MainActivity.kt
        CoroutineScope(Dispatchers.IO).launch {

            //  Check if the CSV file save is toggle ON (True)
            val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
            val values = context.dataStoreW.data.first()
            val flag = values[flagSaveToCSV] ?: false
            if (flag) {

                if (listOfScanResults.isNotEmpty()) {

                    val fileName = generateTimestampFileName("RTTCapturedData")

                    val csvHeaders =
                        "capturedTime,rangingTimestampMillis,macAddress,status,rssi,distanceMm,distanceStdDevMm,measurementBandwidth,measurementChannelFrequencyMHz,numAttemptedMeasurements,numSuccessfulMeasurements"

                    val dataStr = convertToCSV(listOfScanResults)

                    saveToFileUsingMediaStore(fileName, dataStr, csvHeaders)
                }
            }
        }
    }


    fun saveToCSVPointVal(context: Context, actionStr: String, timestamp: Long, listOfPointVal: MutableList<PointVal>) {

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.getDefault())
        val date = java.util.Date(timestamp)
        val humanReadableDate = dateFormat.format(date)

        //  https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/MainActivity.kt
        CoroutineScope(Dispatchers.IO).launch {

            //  Check if the CSV file save is toggle ON (True)
            val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
            val values = context.dataStoreW.data.first()
            val flag = values[flagSaveToCSV] ?: false
            if (flag) {

                if (listOfPointVal.isNotEmpty()) {

                    val fileName = generateTimestampFileName("PointValData")

                    val csvHeaders = "capturedTime,humanReadbleTime,action,Coord"

                    val listOfPointValStr = convertPointValToCSV(listOfPointVal)
                    val dataStr = "$timestamp,$humanReadableDate,$actionStr,$listOfPointValStr\n"

                    saveToFileUsingMediaStore(fileName, dataStr, csvHeaders)
                }
            }
        }
    }

    private fun convertPointValToCSV(listOfPointVal: MutableList<PointVal>): String {

        var pointValInStr = ""

        for (eachPoint in listOfPointVal)
            pointValInStr = pointValInStr + eachPoint.x + "_" + eachPoint.y + "_" + eachPoint.meanRTTDistance + "|"


        return pointValInStr
    }

    /**
     * Convert List of Ranging Result to CSV Data
     *
     * Convert the list of RangingResult to a single String CSV format.
     */
    private fun convertToCSV(listOfScanResults: List<RangingResult>): String {
        val timeZone: TimeZone = TimeZone.getTimeZone("Asia/Singapore")
        val currTime = Calendar.getInstance(timeZone).time

        var scanResultInStr = ""

        //   for (eachScanResult in scanRTTResultHolder) {
        for (eachScanResult in listOfScanResults) {
            if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {
                scanResultInStr = scanResultInStr + currTime.time +
                        "," + eachScanResult.rangingTimestampMillis +
                        "," + eachScanResult.macAddress +
                        "," + eachScanResult.status +
                        "," + eachScanResult.rssi +
                        "," + eachScanResult.distanceMm +
                        "," + eachScanResult.distanceStdDevMm +
                        "," + eachScanResult.measurementBandwidth +
                        "," + eachScanResult.measurementChannelFrequencyMHz +
                        "," + eachScanResult.numAttemptedMeasurements +
                        "," + eachScanResult.numSuccessfulMeasurements +
                        "\n"
            } else {
                scanResultInStr = scanResultInStr + currTime.time +
                        "," + "0" +
                        "," + eachScanResult.macAddress +
                        "," + eachScanResult.status +
                        "," + "0" +
                        "," + "0" +
                        "," + "0" +
                        "," + "0" +
                        "," + "0" +
                        "," + "0" +
                        "," + "0" +
                        "\n"
            }
        }

        return scanResultInStr
    }


    /**
     * Save the CSV String data to file
     *
     * https://developer.android.com/training/data-storage
     * https://developer.android.com/training/data-storage/app-specific
     */
    private fun saveToFileUsingMediaStore(
        fileName: String,
        dataToBeSaved: String,
        headers: String
    ) {

        val directory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS + "/LocalizeRTT/")
        if (!directory.exists()) {
            directory.mkdirs()
        }

        // Create file path
        val file = File(directory, fileName)

        val strData: String = if (file.exists()) {
            dataToBeSaved
        } else {
            headers + "\n" + dataToBeSaved
        }

        val outputStreamD = FileOutputStream(file, true)
        outputStreamD.write(strData.toByteArray())
        outputStreamD.close()
    }
}