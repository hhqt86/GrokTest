package sg.edu.smu.teamrtt.localizertt.research;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint;

/**
 * Point Suggestion
 *
 * @author Truong Quang Hai <qhtruong@smu.edu.sg>, 2025 Aug 28.
 * Tracking:
 * - 2025 Aug 28: Migrated from Hai's GIT codebase.
 * - 2025 Sep 25: Updated code from Hai. (Code Src: WhatsApp chat thread)
 */
public class PointSuggestion {
    private static final double X_AREA = 15.0;
    private static final double Y_AREA = 15.0;
    private static final int GRID_RES = 2 * (int) X_AREA;
    private static final int CANDIDATE_RESOLUTION = 2 * (int) X_AREA;
    private static final int Number_AP_SAMPLES = 10;
    private static final int NUM_RTT_SAMPLES = 5;
    private static final double MIN_DIST = 4.0;
    private static final double MAX_DIST = 6.0;
    private static final double CIRCLE_RADIUS = 5.0;
    private static final double COS_THRESHOLD = 0.86; // approx cos(30 degrees)

    public static CoordinatePoint suggestNextPoint(int num_points, double[] x_points, double[] y_points, double[] rtt_points, double error) {
        if (num_points < 2) {
            System.out.println("Need at least 2 points for suggestion.");
            return null;
        }

        // Get latest point
        double latest_x = x_points[num_points - 1];
        double latest_y = y_points[num_points - 1];
        double latest_rtt = rtt_points[num_points - 1];

        // Create grid centered on latest point
        double[] x_grid = linspace(latest_x - X_AREA, latest_x + X_AREA, GRID_RES);
        double[] y_grid = linspace(latest_y - Y_AREA, latest_y + Y_AREA, GRID_RES);
        double[][] X = new double[GRID_RES][GRID_RES];
        double[][] Y = new double[GRID_RES][GRID_RES];
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                X[i][j] = x_grid[j]; // Note: meshgrid convention, X[row, col] = x[col]
                Y[i][j] = y_grid[i]; // Y[row, col] = y[row]
            }
        }

        // Compute overlap_mask
        boolean[][] overlap_mask = new boolean[GRID_RES][GRID_RES];
        int[][] temp_mask = new int[GRID_RES][GRID_RES]; //This temp_mask will be similar to Thu approach to increase the count of each cell
        double temp_mask_threshold = 0.66; //hhqt hardcode value;
        int max_value_temp_mask = 0;
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                overlap_mask[i][j] = true;
                temp_mask[i][j] = 0;
            }
        }
        for (int idx1 = 0; idx1 < num_points; idx1++) {
            for (int idx2 = idx1 + 1; idx2 < num_points; idx2++) {
                double d1 = rtt_points[idx1];
                double d2 = rtt_points[idx2];
                double k = d1 - d2;
                double[][] XA = computeDistances(X, Y, x_points[idx1], y_points[idx1]);
                double[][] XB = computeDistances(X, Y, x_points[idx2], y_points[idx2]);
                for (int i = 0; i < GRID_RES; i++) {
                    for (int j = 0; j < GRID_RES; j++) {
                        double F = XA[i][j] - XB[i][j];
                        if (k - error <= F && F <= k + error) {
                            //overlap_mask[i][j] = false;
                            temp_mask[i][j]++;
                            if (temp_mask[i][j] > max_value_temp_mask) {
                                max_value_temp_mask = temp_mask[i][j];
                            }
                        }
                    }
                }
            }
        }
        //Then if the count of a cell < threshold * of the max_count_value then the overlap_mask of this cell will be false. Use different resolution with Thu to increase the speed
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                if (temp_mask[i][j] < temp_mask_threshold * max_value_temp_mask) {
                    overlap_mask[i][j] = false;
                }
            }
        }
        int area_of_current_overlap = 0;
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                if (overlap_mask[i][j]) area_of_current_overlap++;
            }
        }
        if (area_of_current_overlap == 0) {
            System.out.println("No overlap area; perfect localization already. No suggestion needed.");
            return null;
        }

        // Sample possible AP locations
        List<Integer> pixel_indices = new ArrayList<>();
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                if (overlap_mask[i][j]) {
                    pixel_indices.add(i * GRID_RES + j);
                }
            }
        }
        Collections.shuffle(pixel_indices, new Random());
        int num_to_sample = Math.min(Number_AP_SAMPLES, pixel_indices.size());
        List<Double> sample_ap_x = new ArrayList<>();
        List<Double> sample_ap_y = new ArrayList<>();
        for (int s = 0; s < num_to_sample; s++) {
            int idx = pixel_indices.get(s);
            int row = idx / GRID_RES;
            int col = idx % GRID_RES;
            sample_ap_x.add(X[row][col]);
            sample_ap_y.add(Y[row][col]);
        }

        // Candidate grid centered on latest point
        double[] cand_x = linspace(latest_x - X_AREA, latest_x + X_AREA, CANDIDATE_RESOLUTION);
        double[] cand_y = linspace(latest_y - Y_AREA, latest_y + Y_AREA, CANDIDATE_RESOLUTION);
        double[][] CX = new double[CANDIDATE_RESOLUTION][CANDIDATE_RESOLUTION];
        double[][] CY = new double[CANDIDATE_RESOLUTION][CANDIDATE_RESOLUTION];
        for (int i = 0; i < CANDIDATE_RESOLUTION; i++) {
            for (int j = 0; j < CANDIDATE_RESOLUTION; j++) {
                CX[i][j] = cand_x[j];
                CY[i][j] = cand_y[i];
            }
        }

        double min_avg_area = Double.POSITIVE_INFINITY;
        double best_cx = Double.NaN;
        double best_cy = Double.NaN;
        double best_rtt = Double.NaN;

        for (int i = 0; i < CANDIDATE_RESOLUTION; i++) {
            System.out.println(i);
            for (int j = 0; j < CANDIDATE_RESOLUTION; j++) {
                double cx = CX[i][j];
                double cy = CY[i][j];
                double dist_to_latest = Math.sqrt((cx - latest_x) * (cx - latest_x) + (cy - latest_y) * (cy - latest_y));
                if (dist_to_latest < MIN_DIST || dist_to_latest > MAX_DIST) {
                    continue;
                }

                List<Double> areas_for_candidate = new ArrayList<>();
                List<Double> true_rtt_new_for_samples = new ArrayList<>();
                for (int s = 0; s < num_to_sample; s++) {
                    double ap_x_s = sample_ap_x.get(s);
                    double ap_y_s = sample_ap_y.get(s);
                    double dist_latest_ap = Math.sqrt((latest_x - ap_x_s) * (latest_x - ap_x_s) + (latest_y - ap_y_s) * (latest_y - ap_y_s));
                    double dist_new_ap = Math.sqrt((cx - ap_x_s) * (cx - ap_x_s) + (cy - ap_y_s) * (cy - ap_y_s));
                    double true_rtt_new_s = latest_rtt - dist_latest_ap + dist_new_ap;
                    true_rtt_new_for_samples.add(true_rtt_new_s);

                    // RTT samples
                    List<Double> rtt_samples = new ArrayList<>();
                    if (NUM_RTT_SAMPLES == 1) {
                        rtt_samples.add(true_rtt_new_s);
                    } else {
                        double rtt_step = (2 * error) / (NUM_RTT_SAMPLES - 1);
                        for (int k = 0; k < NUM_RTT_SAMPLES; k++) {
                            double rtt_new_prime = true_rtt_new_s - error + k * rtt_step;
                            rtt_samples.add(rtt_new_prime);
                        }
                    }

                    List<Double> areas_for_this_sample = new ArrayList<>();
                    for (double rtt_new_testing_sample : rtt_samples) {
                        // Copy mask
                        boolean[][] new_mask = new boolean[GRID_RES][GRID_RES];
                        for (int a = 0; a < GRID_RES; a++) {
                            System.arraycopy(overlap_mask[a], 0, new_mask[a], 0, GRID_RES);
                        }

                        // Precompute XA_new for this candidate
                        double[][] XA_new = computeDistances(X, Y, cx, cy);

                        // For each existing point
                        for (int p = 0; p < num_points; p++) {
                            double k_p = rtt_new_testing_sample - rtt_points[p];
                            double[][] XB_p = computeDistances(X, Y, x_points[p], y_points[p]);
                            for (int row = 0; row < GRID_RES; row++) {
                                for (int col = 0; col < GRID_RES; col++) {
                                    double F_new = XA_new[row][col] - XB_p[row][col];
                                    if (!(k_p - error <= F_new && F_new <= k_p + error)) {
                                        new_mask[row][col] = false;
                                    }
                                }
                            }
                        }

                        // Compute area proxy (number of true cells)
                        int area_count = 0;
                        for (int row = 0; row < GRID_RES; row++) {
                            for (int col = 0; col < GRID_RES; col++) {
                                if (new_mask[row][col]) area_count++;
                            }
                        }
                        double area_testing_sample = area_count; // Since dx fixed, use count for comparison
                        areas_for_this_sample.add(area_testing_sample);
                    }

                    double avg_area_for_this_sample = 0;
                    for (double a : areas_for_this_sample) {
                        avg_area_for_this_sample += a;
                    }
                    avg_area_for_this_sample /= areas_for_this_sample.size();
                    areas_for_candidate.add(avg_area_for_this_sample);
                }

                double avg_area_for_candidate = 0;
                for (double a : areas_for_candidate) {
                    avg_area_for_candidate += a;
                }
                avg_area_for_candidate /= areas_for_candidate.size();

                if (avg_area_for_candidate < min_avg_area && avg_area_for_candidate > 0.5 * area_of_current_overlap) {
                    //hhqt: There are chances the algo tries to suggest a point to reduce the area into 0, we just want to reduce at most 50% of the current overlap area
                    min_avg_area = avg_area_for_candidate;
                    best_cx = cx;
                    best_cy = cy;
                    double sum_rtt = 0;
                    for (double r : true_rtt_new_for_samples) {
                        sum_rtt += r;
                    }
                    best_rtt = sum_rtt / true_rtt_new_for_samples.size();
                }
            }
        }

        if (Double.isNaN(best_cx)) {
            System.out.println("hhqt No suitable suggestion found within the distance constraint [" + MIN_DIST + ", " + MAX_DIST + "] meters from the latest point.");
            return null;
        }
        System.out.printf("hhqt Suggested next point at (%.2f, %.2f) with expected RTT %.2f\n", best_cx, best_cy, best_rtt);

        return new CoordinatePoint(best_cx, best_cy);
    }

    public static CoordinatePoint suggestNextPointVer2(int num_points, double[] x_points, double[] y_points, double[] rtt_points, double error) {
        if (num_points < 2) {
            System.out.println("Need at least 2 points for suggestion.");
            return null;
        }

        // Get latest point
        double latest_x = x_points[num_points - 1];
        double latest_y = y_points[num_points - 1];
        double latest_rtt = rtt_points[num_points - 1];

        // Get previous point
        double prev_x = x_points[num_points - 2];
        double prev_y = y_points[num_points - 2];
        double vx_prev = latest_x - prev_x;
        double vy_prev = latest_y - prev_y;
        double norm_prev = Math.sqrt(vx_prev * vx_prev + vy_prev * vy_prev);
        if (norm_prev == 0) {
            System.out.println("Previous point coincides with latest point; cannot compute direction.");
            return null;
        }

        // Create grid centered on latest point
        double[] x_grid = linspace(latest_x - X_AREA, latest_x + X_AREA, GRID_RES);
        double[] y_grid = linspace(latest_y - Y_AREA, latest_y + Y_AREA, GRID_RES);
        double[][] X = new double[GRID_RES][GRID_RES];
        double[][] Y = new double[GRID_RES][GRID_RES];
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                X[i][j] = x_grid[j]; // Note: meshgrid convention, X[row, col] = x[col]
                Y[i][j] = y_grid[i]; // Y[row, col] = y[row]
            }
        }

        // Compute overlap_mask
        boolean[][] overlap_mask = new boolean[GRID_RES][GRID_RES];
        int[][] temp_mask = new int[GRID_RES][GRID_RES]; //This temp_mask will be similar to Thu approach to increase the count of each cell
        double temp_mask_threshold = 0.66; //hhqt hardcode value;
        int max_value_temp_mask = 0;
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                overlap_mask[i][j] = true;
                temp_mask[i][j] = 0;
            }
        }
        for (int idx1 = 0; idx1 < num_points; idx1++) {
            for (int idx2 = idx1 + 1; idx2 < num_points; idx2++) {
                double d1 = rtt_points[idx1];
                double d2 = rtt_points[idx2];
                double k = d1 - d2;
                double[][] XA = computeDistances(X, Y, x_points[idx1], y_points[idx1]);
                double[][] XB = computeDistances(X, Y, x_points[idx2], y_points[idx2]);
                for (int i = 0; i < GRID_RES; i++) {
                    for (int j = 0; j < GRID_RES; j++) {
                        double F = XA[i][j] - XB[i][j];
                        if (k - error <= F && F <= k + error) {
                            //overlap_mask[i][j] = false;
                            temp_mask[i][j]++;
                            if (temp_mask[i][j] > max_value_temp_mask) {
                                max_value_temp_mask = temp_mask[i][j];
                            }
                        }
                    }
                }
            }
        }
        //Then if the count of a cell < threshold * of the max_count_value then the overlap_mask of this cell will be false. Use different resolution with Thu to increase the speed
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                if (temp_mask[i][j] < temp_mask_threshold * max_value_temp_mask) {
                    overlap_mask[i][j] = false;
                }
            }
        }
        int area_of_current_overlap = 0;
        for (int i = 0; i < GRID_RES; i++) {
            for (int j = 0; j < GRID_RES; j++) {
                if (overlap_mask[i][j]) area_of_current_overlap++;
            }
        }
        if (area_of_current_overlap == 0) {
            System.out.println("No overlap area; perfect localization already. No suggestion needed.");
            return null;
        }

        // Candidate grid centered on latest point
        double[] cand_x = linspace(latest_x - X_AREA, latest_x + X_AREA, CANDIDATE_RESOLUTION);
        double[] cand_y = linspace(latest_y - Y_AREA, latest_y + Y_AREA, CANDIDATE_RESOLUTION);
        double[][] CX = new double[CANDIDATE_RESOLUTION][CANDIDATE_RESOLUTION];
        double[][] CY = new double[CANDIDATE_RESOLUTION][CANDIDATE_RESOLUTION];
        for (int i = 0; i < CANDIDATE_RESOLUTION; i++) {
            for (int j = 0; j < CANDIDATE_RESOLUTION; j++) {
                CX[i][j] = cand_x[j];
                CY[i][j] = cand_y[i];
            }
        }

        double max_sum = -1;
        double best_cx = Double.NaN;
        double best_cy = Double.NaN;

        for (int i = 0; i < CANDIDATE_RESOLUTION; i++) {
            System.out.println(i);
            for (int j = 0; j < CANDIDATE_RESOLUTION; j++) {
                double cx = CX[i][j];
                double cy = CY[i][j];
                double dist_to_latest = Math.sqrt((cx - latest_x) * (cx - latest_x) + (cy - latest_y) * (cy - latest_y));
                if (dist_to_latest < MIN_DIST || dist_to_latest > MAX_DIST) {
                    continue;
                }

                // Compute angle variation
                double vx_new = cx - latest_x;
                double vy_new = cy - latest_y;
                double norm_new = dist_to_latest;
                double dot = vx_prev * vx_new + vy_prev * vy_new;
                double cos_theta = dot / (norm_prev * norm_new);
                if (Math.abs(cos_theta) > COS_THRESHOLD) {
                    continue; // Too aligned or opposite
                }

                // Compute sum of temp_mask within 5m circle
                double sum_temp = 0;
                for (int gi = 0; gi < GRID_RES; gi++) {
                    for (int gj = 0; gj < GRID_RES; gj++) {
                        double dx = X[gi][gj] - cx;
                        double dy = Y[gi][gj] - cy;
                        double d = Math.sqrt(dx * dx + dy * dy);
                        if (d <= CIRCLE_RADIUS) {
                            sum_temp += temp_mask[gi][gj];
                        }
                    }
                }

                if (sum_temp > max_sum) {
                    max_sum = sum_temp;
                    best_cx = cx;
                    best_cy = cy;
                }
            }
        }

        if (Double.isNaN(best_cx)) {
            System.out.println("hhqt No suitable suggestion found within the distance constraint [" + MIN_DIST + ", " + MAX_DIST + "] meters from the latest point with varied angle.");
            return null;
        }
        System.out.printf("hhqt Suggested next point at (%.2f, %.2f)", best_cx, best_cy);

        return new CoordinatePoint(best_cx, best_cy);
    }


    private static double[] linspace(double start, double end, int num) {
        double[] arr = new double[num];
        if (num == 1) {
            arr[0] = start;
            return arr;
        }
        double step = (end - start) / (num - 1);
        for (int i = 0; i < num; i++) {
            arr[i] = start + i * step;
        }
        return arr;
    }

    private static double[][] computeDistances(double[][] X, double[][] Y, double px, double py) {
        int n = X.length;
        int m = X[0].length;
        double[][] dist = new double[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                double dx = X[i][j] - px;
                double dy = Y[i][j] - py;
                dist[i][j] = Math.sqrt(dx * dx + dy * dy);
            }
        }
        return dist;
    }

    // Example usage
    public static void main(String[] args) {
        // Example: 2 points
        int num_points = 2;
        double[] x_points = {-10.0, 10.0};
        double[] y_points = {0.0, 0.0};
        double[] rtt_points = {2900.0, 2900.0};
        double error = 4;
        suggestNextPoint(num_points, x_points, y_points, rtt_points, error);
    }
}