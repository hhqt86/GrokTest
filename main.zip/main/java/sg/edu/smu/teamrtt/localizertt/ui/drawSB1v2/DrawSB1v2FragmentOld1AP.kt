package sg.edu.smu.teamrtt.localizertt.ui.drawSB1v2

//import androidx.compose.ui.graphics.Paint

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.icu.util.Calendar
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.createBitmap
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentDrawSb1Binding
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.model.dataview.DrawSB1DetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.research.map_visualization.PointVal
import sg.edu.smu.teamrtt.localizertt.ui.imu.IMUViewModel
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.avgHumanStepInMeters
import sg.edu.smu.teamrtt.localizertt.util.heatMapHeight
import sg.edu.smu.teamrtt.localizertt.util.heatMapWidth
import sg.edu.smu.teamrtt.localizertt.util.toastMessages
import java.lang.Math.PI
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt


/**
 * SOSS B1 User AP Draw Plot (Dynamic View) Fragment (DrawSB1v2Frament)
 *
 * Hai's (amd Thu) Probabilistic AP's location approach Version (used in period of August 2025)
 *
 * This UI Fragments has the following functionality:
 * 1. Renders the SOSS B1 Map on screen.
 * 2. TODO: Blah blah blah....
 *
 * William: DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * References
 * 1. Drawing with jetpack-compose
 *  -   Tap: https://stackoverflow.com/questions/68363029/how-to-add-click-events-to-canvas-in-jetpack-compose
 *  -   https://medium.com/@fctdev/drawing-with-compose-836eadd1a308
 *  -   https://github.com/SebastienFCT/articles/blob/main/code-samples/DrawingCanvasExample/app/src/main/java/com/tectes/drawingcanvasexample/DrawingCanvas.kt
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 Oct 13: Created by William Tan Kiat Wee. (Adopted from version DrawSB1Frament, now renamed as Static View)
 */
class DrawSB1v2FragmentOld1AP : Fragment() {

    //  Hardcoded AP MAC For Testing Only. (To be remove in Production)
    //  Original:   private val apList = arrayOf(HARDCODED_AP0, HARDCODED_AP1, HARDCODED_AP2, HARDCODED_AP3, HARDCODED_AP4)
    //  Position 0 to flexible, see AppPrefStore.kt to set the target AP for testing.
    //private val apList = arrayOf(HARDCODED_AP_TARGET, HARDCODED_AP1, HARDCODED_AP2, HARDCODED_AP3, HARDCODED_AP4)

    //  ===================================
    //      Plot/Device Drawable space
    //  ===================================

    //  Starting User Point
    private val userStartingX = 0.0
    private val userStartingY = 0.0


    //  Device's drawable space (Canvas)
    private var canvasWidth = 0.0f
    private var canvasHeight = 0.0f

    //  Center of the drawable space (values will be compute during runtime)
    var refOriginX = 0.0f
    var refOriginY = 200.0f

    //  =====================================
    //      Translation Meters to Pixel
    //  =====================================

    //  One meter in real world to equivalent in pixel (values will be compute during runtime)
    private var oneMeterXAxisInPx = 0.0f
    private var oneMeterYAxisInPx = 0.0f

    //  ================
    //      Heatmap
    //  ================

    //  Reference Heatmap Width in meters
    val refHeatmapWidthInMeters = 90

    //  Reference Heatmap Height in meters
    val refHeatmapHeightInMeters = 90

    //  Computed Heatmap Width in pixel
    var refHeatmapWidthInPx = 0.0f

    //  Computed Heatmap Height in pixel
    var refHeatmapHeightInPx = 0.0f

    //  Computed Cropped Heatmap Height,Width in px
    var cropHeatmapWidth = 0.0f
    var cropHeatmapHeight = 0.0f

    //  Computed Cropped Heatmap position in px
    var cropHeatmapX = 0.0f
    var cropHeatmapY = 0.0f

    //  ================
    //      Markers
    //  ================

    //  Number of markers in the vertical + horizontal grid.
    private var defaultNoOfHorizontalMarkers = 10
    private var defaultNoOfVerticalMarkers = 16

    //private var defaultAspectRatio = defaultNoOfHorizontalMarkers.toFloat()/defaultNoOfVerticalMarkers.toFloat()
    private var defaultAspectRatio = defaultNoOfVerticalMarkers.toFloat() / defaultNoOfHorizontalMarkers.toFloat()
    private var noOfHorizontalMarkers = defaultNoOfHorizontalMarkers
    private var noOfVerticalMarkers = defaultNoOfVerticalMarkers


    private var maxNumOfVertical = 0


    private var _binding: FragmentDrawSb1Binding? = null

    private var thisContext: Context? = null

    //  Handle to set/observe for stuff in DrawSB1Fragment
    private val drawDetailsViewModel: DrawSB1DetailsDataViewModel by activityViewModels()

    //  Handle to set/observe for stuff in IMU
    private val imuViewModel: IMUViewModel by activityViewModels()

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!


    private var captureTimeWindow = 20 * 1000L

    //  ================================================================================

    private var listOfAPCoordinatePointInMeters: MutableList<CoordinatePoint> = mutableListOf()

    private var listOfAPCoordinatePointInPx: MutableList<CoordinatePoint> = mutableListOf()

    //  ================================================================================
    private var userCoordinatePointInPx: CoordinatePoint = CoordinatePoint(0.0, 0.0)

    private var userCoordinatePointInMeters: CoordinatePoint = CoordinatePoint(userStartingX, userStartingY)

    //  ================================================================================

    private var targetCoordinatePointInPx: CoordinatePoint = CoordinatePoint(0.0, 0.0)
    private var targetCoordinatePointInMeters: CoordinatePoint = CoordinatePoint(0.0, 0.0)
    private var targetFlashingFlag: Boolean = true


    //  Reference angle for correcting UI Plot
    private var referenceAngle = 0.0

    //  Current received IMU Azimuth
    private var azimuthInDegrees = 0.0

    private var azimuthLock = false

    private var selectedAP = ""

    //  For Heatmap plot
    private var hmpMask: Array<IntArray?>? = null

    private var fullMaskBitmap = createBitmap(1, 1)
    private var maskBitmap = ImageBitmap(1, 1)

    private var currentListOfPointVal: MutableList<PointVal> = mutableListOf()

    private var currentAllListOfPointVal = ConcurrentHashMap<String, MutableSet<PointVal>>()

    private var flagIsInitialCondition = true

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        thisContext = this.context

        captureTimeWindow = thisContext?.let { AppPrefStore(it).loadCaptureTime() }!!

        val drawViewModel = ViewModelProvider(this).get(DrawSB1v2ViewModel::class.java)

        _binding = FragmentDrawSb1Binding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textDraw
        drawViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        val composeView = binding.composeView
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                DrawMap()
                CanvasDrawGrid()
            }
        }

        //  Setup the UI Button interactions
        setupUIComponents(composeView)

        //  Setup ViewModel Observers
        setupViewModelObservers(composeView)

        return root
    }


    /**
     * Setup UI View/Components and their interactions.
     * E.g. Buttons, Dropdown list, etc.
     */
    private fun setupUIComponents(composeView: ComposeView) {

        //  ======================================================================================================
        //  ======================================================================================================

        //  Button to Mark Reference Angle
        val buttonMarkAngle: Button = binding.buttonMark
        buttonMarkAngle.setOnClickListener {
            referenceAngle = azimuthInDegrees
            drawDetailsViewModel.setReferenceAngleForUI(referenceAngle.toFloat())
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Button to Lock Reference Angle
        val buttonLockAngle: Button = binding.buttonLock
        buttonLockAngle.setOnClickListener {
            if (azimuthLock) {
                azimuthLock = false
                buttonLockAngle.text = "LOCK"
            } else {
                azimuthLock = true
                buttonLockAngle.text = "UNLOCK"
            }
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Button Zoom In
        val buttonZoomIn: Button = binding.buttonZoomIn
        buttonZoomIn.setOnClickListener {

            if (noOfHorizontalMarkers > 10) {

                //  Toast message
                toastMessages(thisContext, "Zooming In...")

                //var aspectRatio = noOfVerticalMarkers.toFloat()/noOfHorizontalMarkers.toFloat()
                noOfHorizontalMarkers--
                noOfVerticalMarkers = (defaultAspectRatio * noOfHorizontalMarkers).toInt()

                adjustScreenItemsForUIComponents(composeView)
            } else
                toastMessages(thisContext, "Default Reached. Unable to Zoom In.")
        }


        //  Button Zoom Out
        val buttonZoomOut: Button = binding.buttonZoomOut
        buttonZoomOut.setOnClickListener {

            //  Toast message
            toastMessages(thisContext, "Zooming Out...")

            //var aspectRatio = noOfVerticalMarkers.toFloat()/noOfHorizontalMarkers.toFloat()
            noOfHorizontalMarkers++
            noOfVerticalMarkers = (defaultAspectRatio * noOfHorizontalMarkers).toInt()

            adjustScreenItemsForUIComponents(composeView)
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Button for Update
        val buttonPlot: Button = binding.buttonUpdate
        buttonPlot.text = "Start"
        buttonPlot.setOnClickListener {

            if (flagIsInitialCondition) {
                flagIsInitialCondition = false
                buttonPlot.text = "Update"

                //  Generate Random Suggest Point
                generateRandomSuggestedPointForInitialCondition()

                //  Capture the initial starting position
                //  Set the initial point (in meters)
                val userCoordinatePointInMeters = CoordinatePoint(0.0, 0.0)
                drawDetailsViewModel.setUserCoordPosPointInMeters(userCoordinatePointInMeters)

                //  Mark the time the user initial position.
                drawDetailsViewModel.setCreationTimestamp(Calendar.getInstance().timeInMillis)

                //  Suggestion Point Message
                toastMessages(thisContext, "Point and move towards blinking point!")
            } else
                drawDetailsViewModel.setTriggerFlag(true)
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Drop down/up List for list of AP (AP0 to AP4)
//        if (thisContext != null) {
//            val spinner: Spinner = binding.spinnerApList
//            // Create an ArrayAdapter using the string array and a default spinner layout.
//            ArrayAdapter.createFromResource(
//                thisContext!!,
//                R.array.Test_AP_List,
//                android.R.layout.simple_spinner_item
//            ).also { adapter ->
//                // Specify the layout to use when the list of choices appears.
//                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
//                // Apply the adapter to the spinner.
//                spinner.adapter = adapter
//            }
//
//            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
//                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
//                    selectedAP = apList[position]
//                    drawDetailsViewModel.setSelectedAP(selectedAP)
//                    //Log.i("William", "selectedAP=$selectedAP")
//                }
//
//                override fun onNothingSelected(parent: AdapterView<*>?) {
//                }
//            }
//        }
    }

    /**
     * Adjust Screen UI Items after parameters (params) have changed. (Zoom In/Out)
     *
     * This is triggered by Zoom In/Out when the screen parameters have changed, hence, items on the screen have to be redrawn due to the new params.
     */
    private fun adjustScreenItemsForUIComponents(composeView: ComposeView) {

        //  Notes: This is called after zoom in/out, the markers have changed at this point.

        //  Draw the screen to adjust for new (changed) markers
        //  Also allow the calculation of the parameters fo the canvas/map/etc.
        drawScreen(composeView)

        //  Calculate the Suggestion/Target Point in relation to the User Position (in cartesian coordinates meters)
        val relativeTargetInMeters = calculateTargetPositionRelativeToMe(
            userCoordinatePointInMeters,
            targetCoordinatePointInMeters
        )
        targetCoordinatePointInPx = adjustToScreenGrid(refOriginX, refOriginY, relativeTargetInMeters)


        //  If hmpMask is available, re-compute the new bitmap WRT to the zoom settings now.
        if (hmpMask != null) {

            //  Compute the new Bitmap
            fullMaskBitmap = createHmpMaskBitmap(hmpMask, refHeatmapWidthInPx.toInt(), refHeatmapHeightInPx.toInt())

            //  Determine the Crop position (depending where the user is on the cartesian coordinate)
            val cropPos = calculateCropPosition(userCoordinatePointInMeters, fullMaskBitmap)

            //  Crop a section out that repsents what the user is seeing.
            maskBitmap = cropBitmap(
                fullMaskBitmap,
                cropPos.x.toInt(),
                cropPos.y.toInt(),
                canvasWidth.toInt(),
                canvasHeight.toInt()
            )
        }

        //  Adjust the representative-AP relative to user
        listOfAPCoordinatePointInPx = mutableListOf()
        for (eachAPInMeters in listOfAPCoordinatePointInMeters) {

            //Log.i("William", "eachAPInMeters: $eachAPInMeters")

            val relativeAPInMeters = calculateTargetPositionRelativeToMe(
                userCoordinatePointInMeters,
                eachAPInMeters
            )
            listOfAPCoordinatePointInPx.add(adjustToScreenGrid(refOriginX, refOriginY, relativeAPInMeters))
        }

        //  After everything is adjusted, redraw again.
        drawScreen(composeView)

//        Log.i(
//            "William",
//            "noOfHorizontalMarkers: $noOfHorizontalMarkers, " +
//                    "noOfVerticalMarkers: $noOfVerticalMarkers, " +
//                    "aspectRatio: $defaultAspectRatio, " +
//                    "oneMeterXAxisInPx: $oneMeterXAxisInPx"
//        )
    }

    /**
     * Setup the Observers/Listeners of various ViewModels
     *
     * Notes:
     * ViewModels can be as datasource where you hook a observer/listener in which these following code will execute when the data is available.
     * (AKA a callback when the data becomes present. ViewModels allow you to hook it to anywhere in the app)
     */
    private fun setupViewModelObservers(composeView: ComposeView) {

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe for User Location changes (for displaying on screen)
        //  Update handle and redraw the user on screen.
        drawDetailsViewModel.currentUserCoordPosPoint.observe(viewLifecycleOwner, Observer { value ->

            userCoordinatePointInPx = value
            userCoordinatePointInMeters = adjustToReferenceGrid(
                refOriginX,
                refOriginY,
                userCoordinatePointInPx.x.toFloat(),
                userCoordinatePointInPx.y.toFloat()
            )

            // Draw on screen
            drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        drawDetailsViewModel.currentUserCoordPosPointInMeters.observe(viewLifecycleOwner, Observer { value ->

            userCoordinatePointInMeters = value
            userCoordinatePointInPx = adjustToScreenGrid(refOriginX, refOriginY, userCoordinatePointInMeters)

            // Draw on screen
            drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe for predicted AP location
        //  Update local handle and redraw the AP on screen
        //  Updated from MainActivity WiFiProcessOps has computed the AP Locations
        //  Currently, commented out as code is not ready yet for new Trigo-Algo (Hai and Thu Aug 2025)
        drawDetailsViewModel.currentCoordAPPosList.observe(viewLifecycleOwner, Observer { value ->

            //listOfAPCoordinatePoint = value

            // Draw on screen
            // drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the Azimuth from the IMU data.
        //  In DrawSB1Fragment, this is only use for UI purpose, to draw the user direction on screen.
        imuViewModel.currentComputedDataOrientation.observe(viewLifecycleOwner) { value ->

            //  If the user unlock the Azimuth, then get sensor data and draw the direction.
            //  Else, just redraw the screen, without changing the azimuth.
            if (!azimuthLock) {
                //  Get the orientation data
                val orientationData: FloatArray = value

                //  Convert to Degrees and update the handle
                azimuthInDegrees = (Math.toDegrees(orientationData[0].toDouble()) + 360) % 360
                //Log.i("William", "azimuthInDegrees=$azimuthInDegrees")
            }

            // Draw on screen (of where the user is facing)
            drawScreen(composeView)

            //  Toggle this flag to mimic flashing on the canvas on the suggestion point.
            targetFlashingFlag = !targetFlashingFlag
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the step data from the IMU data.
        imuViewModel.currentSensorStepDetectedEvent.observe(viewLifecycleOwner) { value ->

            //  With each step, update Position on Screen,
            //  Given the average step of 0.4 - 0.76 meters and the direction the user is facing.
            userCoordinatePointInMeters = calculatePositionInMetersWhenAStepIsTaken(
                userCoordinatePointInMeters.x,
                userCoordinatePointInMeters.y,
                azimuthInDegrees,
                referenceAngle
            )

            Log.i("William", "userCoordinatePointInMeters: $userCoordinatePointInMeters")

            //  If user is within target, snap user to target
            val distanceToTarget = calculateDistanceCartesian(userCoordinatePointInMeters, targetCoordinatePointInMeters)
            if (distanceToTarget < 1.0) {

                userCoordinatePointInMeters = targetCoordinatePointInMeters
                Log.i("William", "Snapping user to target: userCoordinatePointInMeters: $userCoordinatePointInMeters")
                //toastMessages(thisContext, "Reached Suggested Point! Please wait for 2-3 seconds and tap on Update.")
            }

            //  After the user has move, recalculate the Points (e.g. Suggested Point, AP Point, etc)
            //  But because the user has already move away from 0,0
            val relativeTargetInMeters = calculateTargetPositionRelativeToMe(
                userCoordinatePointInMeters,
                targetCoordinatePointInMeters
            )
            Log.i("William", "relativeTargetInMeters: $relativeTargetInMeters")
            targetCoordinatePointInPx = adjustToScreenGrid(refOriginX, refOriginY, relativeTargetInMeters)

            //  Re-cropping/crop the heatmap occurs here just before screen redraw
            if (fullMaskBitmap.width > 1 && fullMaskBitmap.height > 1) {
                val cropPos = calculateCropPosition(userCoordinatePointInMeters, fullMaskBitmap)

                maskBitmap = cropBitmap(
                    fullMaskBitmap,
                    cropPos.x.toInt(),
                    cropPos.y.toInt(),
                    canvasWidth.toInt(),
                    canvasHeight.toInt()
                )
            }

            //  Adjust AP relative to user
            listOfAPCoordinatePointInPx = mutableListOf()
            for (eachAPInMeters in listOfAPCoordinatePointInMeters) {

                val relativeAPInMeters = calculateTargetPositionRelativeToMe(
                    userCoordinatePointInMeters,
                    eachAPInMeters
                )

                listOfAPCoordinatePointInPx.add(adjustToScreenGrid(refOriginX, refOriginY, relativeAPInMeters))
            }


            // Draw on screen
            drawScreen(composeView)

            //  Update the holder in MainActivity of changes to user position.
            drawDetailsViewModel.setUserCoordPosPointInMeters(userCoordinatePointInMeters)

//            //  Convert position into meters and notify MainActivity (where Hai and Thu's Trigo-Algo Aug 2025 is being held and used)
//            val userCoordinatePointInMeters = adjustToReferenceGrid(
//                refOriginX,
//                refOriginY,
//                userCoordinatePointInPx.x.toFloat(),
//                userCoordinatePointInPx.y.toFloat()
//            )
//            drawDetailsViewModel.setUserCoordPosPointInMeters(userCoordinatePointInMeters)
        }

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the target point for the user to move to.
        //  This is updated in MainActivity via (Hai and Thu's Trigo-Algo Aug 2025)
        //  If there are any updates, we set the target and redraw the point on screen.
        drawDetailsViewModel.currentTargetCoordPosPointInMeters.observe(viewLifecycleOwner, Observer { value ->

            //  Store and show the updated target location.
            targetCoordinatePointInMeters = value
            //targetCoordinatePointInPx = adjustToScreenGrid(refOriginX, refOriginY, targetCoordinatePointInMeters)

            //  After the user has move, recalculate the Points (e.g. Suggested Point, AP Point, etc)
            //  But because the user has already move away from 0,0
            val relativeTargetInMeters = calculateTargetPositionRelativeToMe(userCoordinatePointInMeters, targetCoordinatePointInMeters)
            Log.i("William", "relativeTargetInMeters: $relativeTargetInMeters")
            targetCoordinatePointInPx = adjustToScreenGrid(refOriginX, refOriginY, relativeTargetInMeters)

            // Draw on screen
            drawScreen(composeView)
        })

        //  ======================================================================================================
        //  ======================================================================================================

        //  Observe the List of PointVal updated via (Hai and Thu's Trigo-Algo Aug 2025) in MainActivity.
        //  List of PointVal is use to draw the Heatmap.
        //  Once the list is updated, we build the mask and draw the heatmap on screen.
        drawDetailsViewModel.currentAllListOfPointVal.observe(viewLifecycleOwner, Observer { value ->

            Log.i("William", "Build Mask in DrawSB1Fragment")
            toastMessages(thisContext, "Building Heatmap...")

            //  Obtain the current list of PointVal
            currentAllListOfPointVal = value

//            //  DEBUG: List 2 Points
//            for (eachPointVal in currentListOfPointVal) {
//                Log.i("William", "eachPointVal: $eachPointVal")
//            }
//
//            //  Grid (this is based on the SOSS B1 Map from Hai)
//            val gridW = heatMapWidth * gridResolution
//            val gridH = heatMapHeight * gridResolution
//            hmpMask = OriginMask.buildMask(value, gridW.toInt(), gridH.toInt(), heatMapWidth, heatMapHeight, gridMaskTolerance)
//
//            //  Create bitmap from hmpMask
//            fullMaskBitmap = createHmpMaskBitmap(hmpMask, refHeatmapWidthInPx.toInt(), refHeatmapHeightInPx.toInt())
//
//            val cropPos = calculateCropPosition(userCoordinatePointInMeters, fullMaskBitmap)
//
//            maskBitmap = cropBitmap(
//                fullMaskBitmap,
//                cropPos.x.toInt(),
//                cropPos.y.toInt(),
//                canvasWidth.toInt(),
//                canvasHeight.toInt()
//            )
//
//            // Draw on screen
//            drawScreen(composeView)
        })

        //  Original
//        drawDetailsViewModel.currentListOfPointVal.observe(viewLifecycleOwner, Observer { value ->
//
//            Log.i("William", "Build Mask in DrawSB1Fragment")
//            toastMessages(thisContext, "Building Heatmap...")
//
//            //  Obtain the current list of PointVal
//            currentListOfPointVal = value
//
//            //  DEBUG: List 2 Points
//            for (eachPointVal in currentListOfPointVal) {
//                Log.i("William", "eachPointVal: $eachPointVal")
//            }
//
//            //  Grid (this is based on the SOSS B1 Map from Hai)
//            val gridW = heatMapWidth * gridResolution
//            val gridH = heatMapHeight * gridResolution
//            hmpMask = OriginMask.buildMask(value, gridW.toInt(), gridH.toInt(), heatMapWidth, heatMapHeight, gridMaskTolerance)
//
//            //  Create bitmap from hmpMask
//            fullMaskBitmap = createHmpMaskBitmap(hmpMask, refHeatmapWidthInPx.toInt(), refHeatmapHeightInPx.toInt())
//
//            val cropPos = calculateCropPosition(userCoordinatePointInMeters, fullMaskBitmap)
//
////            maskBitmap = cropBitmap(
////                fullMaskBitmap,
////                cropPos.x.toInt(),
////                cropPos.y.toInt(),
////                cropHeatmapWidth.toInt(),
////                cropHeatmapHeight.toInt()
////            )
//
//            maskBitmap = cropBitmap(
//                fullMaskBitmap,
//                cropPos.x.toInt(),
//                cropPos.y.toInt(),
//                canvasWidth.toInt(),
//                canvasHeight.toInt()
//            )
//
//            // Draw on screen
//            drawScreen(composeView)
//        })

        //  ======================================================================================================
        //  ======================================================================================================
    }

    /**
     * Draw or Re-Draw the Screen during any update.
     *
     * This is called from the view models during any data update.
     * In which, the whole screen is refreshed and data is redrawn.
     * These includes the map, tracked position, any AP plotted, etc.
     */
    private fun DrawSB1v2FragmentOld1AP.drawScreen(composeView: ComposeView) {
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                DrawMap()
                PlotAP()
                PlotUser()
                PlotTarget()
                PlotHeatmap()
                CanvasDrawGrid()
            }
        }
    }

    /**
     * Canvas Drawing: Plot User on the map
     *
     * On Dynamic View, heatmap changes instead of user point. Hence, user is always at the center of the canvas
     * However, the user is actually moving around the map. User Point (userCoordinatePointInPx) is actually changing with the step.
     */
    @Composable
    fun PlotUser() {

        val textMeasurer = rememberTextMeasurer()

        Canvas(modifier = Modifier.fillMaxSize()) {

            val correctedAngleForUI = convertAzimuthToCartesianAngle(azimuthInDegrees, referenceAngle)

            //  Drawing the line to represent the user's facing direction from the Azimuth data.
            //  To draw line, we need 2 point, since we already have the userCoordinatePoint,
            //  we just draw a short line of 70.0 pixels from that point along the azimuth/correctedAngleForUI
            val xPosToMove: Double = 70.0f * cos(Math.toRadians(correctedAngleForUI))
            val yPosToMove: Double = 70.0f * sin(Math.toRadians(correctedAngleForUI))

            val actualPosX = refOriginX
            val actualPosY = refOriginY

            //Log.i("William", "Plotting User Location. X=${userCoordinatePoint.x}, Y=${userCoordinatePoint.y}")

            //  Draw the circle representing the user
            drawCircle(
                color = Color.Magenta,
                radius = 7.dp.toPx(),
                center = Offset(actualPosX, actualPosY),
            )

            drawText(
                textMeasurer = textMeasurer,
                text = "(${String.format("%.1f", userCoordinatePointInMeters.x).toDouble()}, ${String.format("%.1f", userCoordinatePointInMeters.y).toDouble()})",
                topLeft = Offset(actualPosX + 10f, actualPosY + 10f),
                style = TextStyle(
                    color = Color.Magenta,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                )
            )

            //  Draw the line representing the user facing direction.
            drawLine(
                start = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                end = Offset((actualPosX + xPosToMove).toFloat(), (actualPosY + yPosToMove).toFloat()),
                color = Color.Magenta,
                strokeWidth = 10f

            )
        }
    }


    /**
     * Canvas Drawing: Plot Suggested Point on the map
     */
    @Composable
    fun PlotTarget() {

        //val textMeasurer = rememberTextMeasurer()
        //Log.i("William", "TargetFlag=$targetFlashingFlag, Target Location. X=${targetCoordinatePointInPx.x}, Y=${targetCoordinatePointInPx.y}")

        Canvas(modifier = Modifier.fillMaxSize()) {

            //  If target point is available (targetFlashingFlag is toggle by IMU to mimic flashing on the canvas)
            //if (targetFlashingFlag && targetCoordinatePointInPx.x != 0.0 && targetCoordinatePointInPx.y != 0.0) {
            if (targetFlashingFlag) {

                //Log.i("William", "TargetFlag=$targetFlashingFlag, Target Location. X=${targetCoordinatePointInPx.x}, Y=${targetCoordinatePointInPx.y}")

                drawCircle(
                    color = Color(0xFF78620A),  //  Colour: Gold.
                    radius = 9.dp.toPx(),
                    center = Offset(targetCoordinatePointInPx.x.toFloat(), targetCoordinatePointInPx.y.toFloat()),
                )
            }
        }
    }

    /**
     * Canvas Drawing: Plot (the list of) AP on the map
     */
    @Composable
    fun PlotAP() {

        //  Use to plot text
        val textMeasurer = rememberTextMeasurer()
        val result = remember {
            textMeasurer.measure(
                text = "AP",
                style = TextStyle(
                    color = Color.Red,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = TextDecoration.Underline
                ),
                overflow = TextOverflow.Ellipsis
            )
        }

        //  Plot the list of AP in the store(listOfAPCoordinatePoint)
        Canvas(modifier = Modifier.fillMaxSize()) {

            //  Iterate thru each Point and plot it.
            for (eachCoordinatePointInPx in listOfAPCoordinatePointInPx) {

                //Log.i("William", "eachCoordinatePointInPx: $eachCoordinatePointInPx")

                //  Draw Circle
                drawCircle(
                    color = Color.Red,
                    radius = 7.dp.toPx(),
                    center = Offset(eachCoordinatePointInPx.x.toFloat(), eachCoordinatePointInPx.y.toFloat()),
                )

                //  Draw Text
                drawText(
                    textLayoutResult = result,
                    topLeft = Offset(eachCoordinatePointInPx.x.toFloat() - 20F, eachCoordinatePointInPx.y.toFloat() + 15F),
                )
            }
        }
    }

    /**
     * Canvas Drawing: Plot Heatmap on the map
     */
    @Composable
    fun PlotHeatmap() {

        //  Plot only when the refMap handles are updated.
        if (cropHeatmapWidth > 0 && cropHeatmapHeight > 0) {

            if (maskBitmap.height > 1 && maskBitmap.width > 1) {

                Canvas(modifier = Modifier.fillMaxSize(), onDraw = {
                    drawImage(
                        image = maskBitmap,
                        dstSize = IntSize(
                            width = canvasWidth.toInt(),
                            height = canvasHeight.toInt()
                        ),
                        dstOffset = IntOffset(x = 0, y = 0)
                    )
                })
            }
        }
    }

    /**
     * Crop a section of the Heatmap Bitmap
     *
     * Given the whole Heatmap bitmap, crop out a section that represents the current user's location
     * The crop area is the size of the viewable canvas with the user at its center.
     */
    private fun cropBitmap(maskBitmap: Bitmap, cropX: Int, cropY: Int, cropWidth: Int, cropHeight: Int): ImageBitmap {

        // Create the cropped Bitmap
        val croppedMaskBitmap: Bitmap = Bitmap.createBitmap(maskBitmap, cropX, cropY, cropWidth, cropHeight)

        return croppedMaskBitmap.asImageBitmap()
    }

    /**
     * Create Bitmap from HmpMask (Heatmap)
     *
     * Given:
     * 1. HmpMask
     * 2. bitmapWidth, bitmapHeight The bitmap size to be created.
     *
     * Create and return a bitmap image repsenting the heatmap (HmpMask) defined by the bitmapWidth, bitmapHeight
     */
    private fun createHmpMaskBitmap(hmpMask: Array<IntArray?>?, bitmapWidth: Int, bitmapHeight: Int): Bitmap {

        val bitmap = createBitmap(bitmapWidth, bitmapHeight)
        val canvas = android.graphics.Canvas(bitmap)
        val paint = Paint()

        //  If mask data is avalilable
        if (hmpMask != null) {

            val gridH: Int = hmpMask!!.size
            val gridW: Int = hmpMask!![0]?.size!!

            //Log.i("William", "gridH: $gridH, gridW: $gridW")
            //Log.i("William", "refMapWidth: $refMapWidth, refMapHeight: $refMapHeight")

            val boxW = bitmapWidth / gridW.toFloat()
            val boxH = bitmapHeight / gridH.toFloat()

            //Log.i("William", "boxW: $boxW, boxH: $boxH")

            // Find max in mask for normalization
            val nPoints = currentListOfPointVal.size
            val max = nPoints * (nPoints - 1) / 2
            val normDen: Int = Math.max(1, max)

            for (gy in 0..<gridH) {
                for (gx in 0..<gridW) {

                    val t: Double = hmpMask!![gy]?.get(gx)!!.toDouble() / normDen.toDouble() // normalize to [0,1]

                    val c: Color = colormapTurbo(t)
                    val adjustColor = Color(c.red, c.green, c.blue, 0.5f)
                    paint.color = adjustColor.toArgb()

                    val x = floor(gx * boxW).toInt()
                    val y = floor(gy * boxH).toInt()
                    ceil((gx + 1) * boxW).toInt() - x
                    ceil((gy + 1) * boxH).toInt() - y

                    //Log.i("William", "x: $x, y: $y, adjustColor: $adjustColor")

                    canvas.drawRect(
                        (x.toFloat()),
                        (y.toFloat()),
                        (x.toFloat()) + boxW,
                        (y.toFloat()) + boxH,
                        paint
                    )
                }
            }
        }

        //return bitmap.asImageBitmap()
        return bitmap
    }

    /**
     * Thu's Colormap Turbo
     */
    private fun colormapTurbo(t: Double): Color {
        var t = t
        t = max(0.0, min(1.0, t))
        // Piecewise polynomial-ish approximation
        val r = min(1.0, max(0.0, -2 * t + 1)) // Red: 1 at t=0, 0 at t=0.5 and beyond
        val g = min(1.0, max(0.0, 2 * t - 1)) // Green: 0 at t=0, 0 at t=0.5, 1 at t=1
        val b = min(1.0, max(0.0, -4 * (t - 0.5) * (t - 0.5) + 1)) // Blue: 0 at t=0, 1 at t=0.5, 0 at t=1
        return Color(r.toFloat(), g.toFloat(), b.toFloat())
    }


    /**
     * Canvas Drawing: Draw Basic Map
     * 1. White back ground.
     * 2. Black dot at center.
     */
    @Composable
    fun DrawMap() {

        //val textMeasurer = rememberTextMeasurer()

        Canvas(
            modifier = Modifier
                .fillMaxSize(), onDraw = {

                setupPlotParams(size)

                val canvasQuadrantSize = size
                drawRect(
                    color = Color.White,
                    size = canvasQuadrantSize
                )

                //  Center
                drawCircle(
                    color = Color.Black,
                    radius = 5.dp.toPx(),
                    center = Offset(refOriginX.toFloat(), refOriginY.toFloat()),
                )
            })
    }


    /**
     * Setup the Canvas Plot Parameters
     *
     * The parameters will need to be setup during runtime, as each device's screen size differ from each other.
     *
     * This function setups:
     * 1. Canvas width/height
     * 2. Canvas center point
     * 3. Each grid size is 1 meter, this setups how much pixel per meter as well.
     * 4. The crop size
     * 5. The actual bitmap heatmap size given the current parameters.
     */
    private fun setupPlotParams(size: Size) {
        //  Assign width, height
        canvasWidth = size.width
        canvasHeight = size.height

        //  Get center point
        refOriginX = canvasWidth / 2
        refOriginY = canvasHeight / 2

        //
        val oneMeterInPx = canvasWidth / noOfHorizontalMarkers
        maxNumOfVertical = (canvasHeight / oneMeterInPx).toInt()

        if (maxNumOfVertical % 2 != 0) {
            //  Minus 1 if number is not even
            maxNumOfVertical = maxNumOfVertical - 1
        }

//        if (maxNumOfVertical > noOfVerticalMarkers)
//            maxNumOfVertical = noOfVerticalMarkers
//        else {
//            if (maxNumOfVertical % 2 != 0) {
//                //  Minus 1 if number is not even
//                maxNumOfVertical = maxNumOfVertical - 1
//            }
//        }

        //  We are setting up a square grid, so X,Y is the same.
        //  You can change this if the grid is of different aspect ratio.
        oneMeterXAxisInPx = oneMeterInPx
        oneMeterYAxisInPx = oneMeterInPx

        //  Setup where cropHeatmap start position X, Y should be. (in px)
        cropHeatmapX = refOriginX - (oneMeterInPx * (noOfHorizontalMarkers / 2))
        cropHeatmapY = refOriginY - (oneMeterInPx * (noOfVerticalMarkers / 2))

        //  Setup cropHeatmap size (in px)
        cropHeatmapWidth = noOfHorizontalMarkers * oneMeterInPx
        cropHeatmapHeight = noOfVerticalMarkers * oneMeterInPx

        //  Setup the full heatmap size (in px)
        //refHeatmapWidthInPx = refHeatmapWidthInMeters * oneMeterInPx
        //refHeatmapHeightInPx = refHeatmapHeightInMeters * oneMeterInPx
        refHeatmapWidthInPx = heatMapWidth.toFloat() * oneMeterInPx
        refHeatmapHeightInPx = heatMapHeight.toFloat() * oneMeterInPx
    }


    /**
     * Canvas Drawing: Draw Grid
     */
    @Composable
    fun CanvasDrawGrid() {

        // Log.i("William", "CanvasDrawGrid")

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { tapOffset ->
                        capturePointOnTap(tapOffset)
                    })
                }

        ) {
            //  Draw the vertical and horizontal markers
            drawGridVerticalMarkers()
            drawGridHorizontalMarkers()
        }
    }

    private fun DrawScope.drawGridVerticalMarkers() {

        val eachSegmentCount = maxNumOfVertical / 2

        //  Draw Horizontal Markers
        var counter = 0
        var posFlag = true
        var startPoint = refOriginX
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = refOriginY - (eachSegmentCount * oneMeterXAxisInPx)),
                end = Offset(x = startPoint, y = refOriginY + (eachSegmentCount * oneMeterXAxisInPx)),
                color = Color.Black
            )
            startPoint -= oneMeterXAxisInPx
            if (startPoint <= 0)
                posFlag = false
            else if (counter >= eachSegmentCount)
                posFlag = false

            counter++
        }

        counter = 0
        posFlag = true
        startPoint = refOriginX
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = refOriginY - (eachSegmentCount * oneMeterXAxisInPx)),
                end = Offset(x = startPoint, y = refOriginY + (eachSegmentCount * oneMeterXAxisInPx)),
                color = Color.Black
            )
            startPoint += oneMeterXAxisInPx
            if (startPoint >= canvasWidth)
                posFlag = false
            else if (counter >= eachSegmentCount)
                posFlag = false

            counter++
        }
    }

    private fun DrawScope.drawGridHorizontalMarkers() {

        val eachSegmentCount = maxNumOfVertical / 2

        //  Draw Vertical Markers Reverse
        var counter = 0
        var posFlag = true
        var startPoint = refOriginY
        while (posFlag) {
            drawLine(
                start = Offset(x = 0f, y = startPoint),
                end = Offset(x = refOriginX * 2, y = startPoint),
                color = Color.Black
            )
            startPoint -= oneMeterYAxisInPx
            if (startPoint <= 0)
                posFlag = false
            else if (counter >= eachSegmentCount)
                posFlag = false

            counter++
        }


        //  Draw Vertical Markers Forward
        counter = 0
        posFlag = true
        startPoint = refOriginY
        while (posFlag) {
            drawLine(
                start = Offset(x = 0f, y = startPoint),
                end = Offset(x = refOriginX * 2, y = startPoint),
                color = Color.Black
            )
            startPoint += oneMeterYAxisInPx
            if (startPoint >= canvasHeight)
                posFlag = false
            else if (counter >= eachSegmentCount)
                posFlag = false

            counter++
        }
    }


    /**
     * Tapping on the canvas: Set the test-AP (BSSID) location on the canvas
     *
     * When tapping on the the canvas, this action will set the AP (BSSID) position on the map, indicating the AP we are testing against it.
     */
    private fun capturePointOnTap(tapOffset: Offset) {

        //Log.i("William", "tapOffset: $tapOffset")

        //  Reset the AP holder list. (AP holder is a list, as the future requires testing against multiple AP)
        listOfAPCoordinatePointInMeters = mutableListOf()
        listOfAPCoordinatePointInPx = mutableListOf()

        //  Adjust the touch position on canvas to actual meters
        //  This creates position in meters referencing 0,0
        val apTestPointInMetersRef00 = adjustToReferenceGrid(refOriginX, refOriginY, tapOffset.x, tapOffset.y)

        //  If the user is not a 0,0: We have to adjust the AP position relative to where the user actually is located.
        val actualAPTestPointInMeters = CoordinatePoint(
            userCoordinatePointInMeters.x + apTestPointInMetersRef00.x,
            userCoordinatePointInMeters.y + apTestPointInMetersRef00.y
        )

        //Log.i("William", "actualAPTestPointInMeters: $actualAPTestPointInMeters")

        //  Add to AP holder
        listOfAPCoordinatePointInMeters.add(actualAPTestPointInMeters)

        //  As per process, we create the AP position in pixel as well.
        //  Remember the AP position is relative to the user (at screen center), we calculate the AP position relative to the user.
        //  Then adjust to screen grid to get the pixel values.
        val relativeAPInMeters = calculateTargetPositionRelativeToMe(
            userCoordinatePointInMeters,
            actualAPTestPointInMeters
        )
        listOfAPCoordinatePointInPx.add(adjustToScreenGrid(refOriginX, refOriginY, relativeAPInMeters))
    }


    /**
     * Adjust to (Human) Actual Grid
     *
     * Calculate the real space position in meters given the position on screen/canvas.
     *
     * To convert, we are given:
     * 1. refX, refY which are the screen/canvas midpoint (where the canvas starts at the 0,0 top-left).
     * The height and width are device dependent. E.g. Pixel7 has a different screen size compare Pixel5 or Samsung phone, etc
     *
     * 2. The coordinate measuredX, measuredY in pixel to be converted.
     *
     * Returns the coordinate in real space position (reference grid 0,0 at the center)
     */
    private fun adjustToReferenceGrid(refX: Float, refY: Float, measuredX: Float, measuredY: Float): CoordinatePoint {

        //  Coordinate in meters start at center 0,0
        //  Coordinate in pixel start at top-left 0,0
        //  Hence to convert meter to pixel, we need the center point to make the appropriate adjustment.
        //  i.e. Anything more than 0 is add, less than is minus, etc.
        //  In addition,  we scale the meters into its appropriate pixel size. Typically, 1 meter in real space is more than 1 pixel.

        var actualXInMeters = 0.0f
        if (measuredX < refX) {
            actualXInMeters = -1.0f * (refX - measuredX) / oneMeterXAxisInPx
        } else if (measuredX >= refX) {
            actualXInMeters = (measuredX - refX) / oneMeterXAxisInPx
        }

        var actualYInMeters = 0.0f
        if (measuredY <= refY) {
            actualYInMeters = (refY - measuredY) / oneMeterYAxisInPx
        } else if (measuredY > refY) {
            actualYInMeters = -1.0f * (measuredY - refY) / oneMeterYAxisInPx
        }

        return CoordinatePoint(actualXInMeters.toDouble(), actualYInMeters.toDouble())
    }

    /**
     * Adjust to (Device) Screen Grid
     *
     * Calculate the (device) screen/canvas equivalent position given the actual position in meters.
     *
     * To convert, we are given:
     * 1. refX, refY which are the screen/canvas midpoint (where the canvas starts at the 0,0 top-left).
     * The height and width are device dependent. E.g. Pixel7 has a different screen size compare Pixel5 or Samsung phone, etc
     *
     * 2. The coordinate in meters to convert.
     *
     * Returns the coordinate in pixel position (from top-left)
     *
     */
    private fun adjustToScreenGrid(refX: Float, refY: Float, coordinatePointInMeters: CoordinatePoint): CoordinatePoint {

        //  Coordinate in meters start at center 0,0
        //  Coordinate in pixel start at top-left 0,0
        //  Hence to convert meter to pixel, we need the center point to make the appropriate adjustment.
        //  i.e. Anything more than 0 is add, less than is minus, etc.
        //  In addition,  we scale the meters into its appropriate pixel size. Typically, 1 meter in real space is more than 1 pixel.

        //  X-Axis
        var adjustedXInPixel = 0.0
        if (coordinatePointInMeters.x >= 0) {
            adjustedXInPixel = refX + (coordinatePointInMeters.x * oneMeterXAxisInPx)
        } else if (coordinatePointInMeters.x <= 0) {
            adjustedXInPixel = refX - (-1.0 * coordinatePointInMeters.x * oneMeterXAxisInPx)
        }

        //  Y-Axis
        var adjustedYInPixel = 0.0
        if (coordinatePointInMeters.y >= 0) {
            adjustedYInPixel = refY - (coordinatePointInMeters.y * oneMeterYAxisInPx)
        } else if (coordinatePointInMeters.y <= 0) {
            adjustedYInPixel = refY + (-1.0 * coordinatePointInMeters.y * oneMeterYAxisInPx)
        }

        return CoordinatePoint(adjustedXInPixel, adjustedYInPixel)
    }

    /**
     * Calculate Position (in meters) When a human step is taken.
     *
     * This function is called when a step is taken to calculate the new position, given the current azimuth.
     * Given:
     * 1. The Coordinates X, Y in meters
     * 2. The Azimuth the user is in.
     * 3. The Reference angle we are referencing from.
     * We move the user in a human step distance (Asian Human Step), given the azimuth. As the distance is tracked in cartesian coordinate.
     * The azimuth is first converted to the cartesian plane, given a reference angle (an angle which we set as a reference.)
     *
     * Returns the new coordinates (in meters)
     */
    fun calculatePositionInMetersWhenAStepIsTaken(
        coordXInMeters: Double,
        coordYInMeters: Double,
        azimuthInDegrees: Double,
        referenceAngleForUI: Double
    ): CoordinatePoint {

        //  Convert Azimuth Angle to Cartesian plane angle
        val correctedAngleForUI = convertAzimuthToCartesianAngle(azimuthInDegrees, referenceAngleForUI)
        //Log.i("William", "correctedAngleForUI: $correctedAngleForUI. azimuthInDegrees:$azimuthInDegrees, referenceAngleForUI: $referenceAngleForUI")

        //  Calculate the new Point on Cartesian plane
        val movedX: Double = avgHumanStepInMeters * cos(Math.toRadians(correctedAngleForUI))
        val movedY: Double = avgHumanStepInMeters * sin(Math.toRadians(correctedAngleForUI))

        //  New location
        val adjustedXInMeters = coordXInMeters + movedX
        val adjustedYInMeters = coordYInMeters - movedY

        return CoordinatePoint(adjustedXInMeters, adjustedYInMeters, correctedAngleForUI)
    }


    /**
     * Correct Azimuth to Cartesian Plane Angle
     *
     * Why?
     * The Grid chosen by Hai has the following issue:
     * 1. Azimuth is reference to Magnetic North.
     * 2. Grid (with the Picture of SB1) is not align to magnetic north.
     * In order to plot correctly the user facing direction in the grid, we need to correct Azimuth data to the grid.
     *
     * 1. Reference Angle is the angle set by the user, facing towards the  direction of tg the stairs in SB1.
     * 2. As the grid is not align to Magnetic North. (Actual Azimuth is 290 degrees approx)
     * 3. Hence with reference angle, with correct to the Grid alignment.
     * 4. Since we are plotting against cartesian plane, the angle starts at horizontal axis = 0 clockwise rotation.
     * 5. Hence, the Grid alignment facing the stairs in SB1 will need to be rotated 270 degrees.
     *
     * At the end of the process, the the corrected angle is now align to the SB1 Grid Picture in the app.
     */
    private fun convertAzimuthToCartesianAngle(azimuthInDegrees: Double, referenceAngle: Double): Double {

        //  Correct for screen drawing if reference angle is used.
        var correctedAngleForUI = azimuthInDegrees - referenceAngle
        if (correctedAngleForUI < 0) {
            correctedAngleForUI = 360 + correctedAngleForUI
        }

        //  Correct to Grid where the 0 degrees starts from vertical axis instead of horizontal
        //  We can either -90 degrees or +270, I do +270, easier to deal with mod operator.
        correctedAngleForUI = (correctedAngleForUI + 270) % 360
        return correctedAngleForUI
    }

    /**
     * Generate Random Suggested Point For Initial Condition
     *
     * Generate the 1st Target/Suggestion point for the user.
     */
    private fun generateRandomSuggestedPointForInitialCondition() {

        //  Generate a point between 2 circle center around a starting point.
        val randomPoint = randomPointInCircle(userStartingX, userStartingY, 4.0, 5.0)
        // Log.i("William", "randomPoint: $randomPoint")

        //  Set the target point and generate the equivalent point in Pixel for plotting.
        targetCoordinatePointInMeters = randomPoint
        targetCoordinatePointInPx = adjustToScreenGrid(refOriginX, refOriginY, randomPoint)
        // Log.i("William", "targetCoordinatePoint: $targetCoordinatePointInPx, targetCoordinatePointInMeters: $targetCoordinatePointInMeters")
    }

    /**
     * Generate random point within a circle between 2 radius.
     *
     * Centered at xPos, yPos
     * Generate a point between the circle of radius minRadius to circle of radius maxRadius
     */
    private fun randomPointInCircle(xPos: Double, yPos: Double, minRadius: Double, maxRadius: Double): CoordinatePoint {
        val randomAngle = Random().nextDouble() * 2 * PI
        val randomRadius = sqrt(Random().nextDouble()) * (maxRadius - minRadius) + minRadius

        val x = xPos + randomRadius * cos(randomAngle).toFloat()
        val y = yPos + randomRadius * sin(randomAngle).toFloat()

        return CoordinatePoint(x, y)
    }

    /**
     * Calculate the Target's Position relative to Me (the user)
     *
     * This function is used calculate the target position relative to the user position. Why?
     * 1. Although the user stays in the center of the device, the map itself is moving when the user moves.
     * 2. Hence, the target position will also moves, hence, we need to calculate where the target is relative to the user (becuse the user stays in the middle of the screen)
     * 3. So if the user don't move, the target and heatmap have to move.
     *
     * Example:
     * 1. If user moves from 0,0 to 1,1.
     * 2. And target is -1,-1.
     * 3. DeltaX,Y = 1
     * 4. Target is now -2, -2
     * Hence, if you draw it out, this gives the illusion that the user is now moving away from the target. Remember, the user always stays in the middle of the screen.
     */
    private fun calculateTargetPositionRelativeToMe(currentUserPositionInMeters: CoordinatePoint, currentTargetPositionInMeters: CoordinatePoint): CoordinatePoint {

        //Log.i("William", "  - currentUserPosition: $currentUserPositionInMeters,")
        //Log.i("William", "  - currentTargetPosition: $currentTargetPositionInMeters")

        //  Get the delta from the user's starting position
        val deltaXMeters = currentUserPositionInMeters.x - userStartingX
        val deltaYMeters = currentUserPositionInMeters.y - userStartingY
        //Log.i("William", "      - deltaXMeters: $deltaXMeters, deltaYMeters: $deltaYMeters")

        //  Once we have the delta of where the user is from the starting point,
        //  We can convert the target's position to where relative to the user.
        return CoordinatePoint(currentTargetPositionInMeters.x - deltaXMeters, currentTargetPositionInMeters.y - deltaYMeters)
    }

    /**
     * Calculate Crop Position on the bitmap.
     *
     * The crop position is the device's viewport on to the bitmap.
     *
     * Typically, the bitmap (heatmap) is bigger than the viewport of the device, hence, we need to crop out the area the user is in.
     *
     * This function provides the cropping start position on the bitmap. Given:
     * 1. The current user position in meters (x,y)
     * 2. The generated bitmap heatmap
     *
     * Returns the crop start position.
     */
    private fun calculateCropPosition(currentUserPositionInMeters: CoordinatePoint, heatmapInBitmap: Bitmap): CoordinatePoint {

        //  Get Midpoint of the map, which is the equivalent starting point.
        val midPointX = heatmapInBitmap.width.toFloat() / 2
        val midPointY = heatmapInBitmap.height.toFloat() / 2

        //  Given the user position in meters (x,y), convert to the bitmap coordinate
        val userPosInBitmap: CoordinatePoint = adjustToScreenGrid(midPointX, midPointY, currentUserPositionInMeters)

        //  Return the coordinate, minus the refOrigin values (which is the viewport center), which returns the top-left for the crop position.
        return CoordinatePoint(userPosInBitmap.x - refOriginX, userPosInBitmap.y - refOriginY)
    }

    /**
     * Calculate Distance between two cartesian point.
     *
     * Given 2 coordinate point, get the distance between them.
     */
    private fun calculateDistanceCartesian(point1: CoordinatePoint, point2: CoordinatePoint): Double {
        val deltaX = point2.x - point1.x
        val deltaY = point2.y - point1.y
        return sqrt(deltaX * deltaX + deltaY * deltaY)
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


}