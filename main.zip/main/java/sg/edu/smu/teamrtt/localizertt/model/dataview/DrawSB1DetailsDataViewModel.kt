package sg.edu.smu.teamrtt.localizertt.model.dataview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.research.map_visualization.PointVal

/**
 * Meant for Hai's Probabilistic AP's location approach (August 2025)
 * Adapted from older version (see DrawSB1DetailsDataViewModelOld1)
 */
class DrawSB1DetailsDataViewModel : ViewModel() {

    private var coordPosList = MutableLiveData<MutableList<CoordinatePoint>>()
    val currentCoordPosList: LiveData<MutableList<CoordinatePoint>> get() = coordPosList

    fun setCoordPosList(coordPos: MutableList<CoordinatePoint>) {
        coordPosList.value = coordPos
    }

    fun getArrayOfCoordinates(): Array<CoordinatePoint> {

        var arrayOfCoord: Array<CoordinatePoint> = emptyArray()

        if (currentCoordPosList.value?.isNotEmpty() == true) {
            for (eachCoordinate in currentCoordPosList.value!!) {
                arrayOfCoord += eachCoordinate
            }
        }

        return arrayOfCoord
    }

    //  ================================================================

    private var userCoordPosPoint = MutableLiveData<CoordinatePoint>()
    val currentUserCoordPosPoint: LiveData<CoordinatePoint> get() = userCoordPosPoint

    fun setUserCoordPosPoint(coordPos: CoordinatePoint) {
        userCoordPosPoint.value = coordPos
    }

    //  ================================================================

    private var userCoordPosPointInMeters = MutableLiveData<CoordinatePoint>()
    val currentUserCoordPosPointInMeters: LiveData<CoordinatePoint> get() = userCoordPosPointInMeters

    fun setUserCoordPosPointInMeters(coordPos: CoordinatePoint) {
        userCoordPosPointInMeters.value = coordPos
    }

    //  ================================================================

    private var targetCoordPosPointInMeters = MutableLiveData<CoordinatePoint>()
    val currentTargetCoordPosPointInMeters: LiveData<CoordinatePoint> get() = targetCoordPosPointInMeters

    fun setTargetCoordPosPointInMeters(coordPos: CoordinatePoint) {
        targetCoordPosPointInMeters.value = coordPos
    }

    //  ================================================================

    fun getListOfTimestamp(): MutableList<Long> {

        var listOfTimestamps: MutableList<Long> = mutableListOf()

        if (currentCoordPosList.value?.isNotEmpty() == true) {
            for (eachCoordinate in currentCoordPosList.value!!) {
                listOfTimestamps.add(eachCoordinate.timestamp)
            }
        }

        //Log.i("DrawDetailsDataViewModel", "getListOfTimestamp(): $listOfTimestamps")

        return listOfTimestamps
    }

    //  ================================================================

    private var triggerFlag = MutableLiveData<Boolean>()
    val currentTriggerFlag: LiveData<Boolean> get() = triggerFlag

    fun setTriggerFlag(flag: Boolean) {
        triggerFlag.value = flag
    }

    //  ================================================================

    private var coordAPPosList = MutableLiveData<MutableList<CoordinatePoint>>()
    val currentCoordAPPosList: LiveData<MutableList<CoordinatePoint>> get() = coordAPPosList

    fun setCoordAPPosList(coordAPPos: MutableList<CoordinatePoint>) {
        coordAPPosList.value = coordAPPos
    }

    //  ================================================================


    private var referenceAngleForUI = MutableLiveData<Float>()
    val currentReferenceAngleForUI: LiveData<Float> get() = referenceAngleForUI

    fun setReferenceAngleForUI(referenceAngle: Float) {
        referenceAngleForUI.value = referenceAngle
    }

    //  ================================================================

    private var selectedAP = MutableLiveData<String>()
    val currentSelectedAP: LiveData<String> get() = selectedAP

    fun setSelectedAP(apSelected: String) {
        selectedAP.value = apSelected
    }

    //  ================================================================

    private var creationTimestamp = MutableLiveData<Long>()
    val currentCreationTimestamp: LiveData<Long> get() = creationTimestamp

    fun setCreationTimestamp(timestamp: Long) {
        creationTimestamp.value = timestamp
    }

    //  ================================================================

    private var listOfPointVal = MutableLiveData<MutableList<PointVal>>()
    val currentListOfPointVal: LiveData<MutableList<PointVal>> get() = listOfPointVal

    fun setListOfPointVal(mlistOfPointVal: MutableList<PointVal>) {
        listOfPointVal.value = mlistOfPointVal
    }

    //  ================================================================

    private var allListOfPointVal = MutableLiveData<MutableList<MutableList<PointVal>>>()
    val currentAllListOfPointVal: LiveData<MutableList<MutableList<PointVal>>> get() = allListOfPointVal

    fun setAllListOfPointVal(mAllListOfPointVal: MutableList<MutableList<PointVal>>) {
        allListOfPointVal.value = mAllListOfPointVal
    }

    //  ================================================================

}