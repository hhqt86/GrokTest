package sg.edu.smu.teamrtt.localizertt.model.dataview

import android.location.Location
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.android.gms.maps.model.LatLng

/**
 * Location Data View Mode
 *
 * Transferring of location data from MainActivity to GPS Fragment (Gallery)
 */
class LocationDataViewModel : ViewModel() {

    private var mutableLatLng = MutableLiveData<LatLng>()

    //var holdPosition:LatLng = LatLng(1.2973621724152964, 103.84926432802061)
    val holdPosition: LiveData<LatLng> get() = mutableLatLng

    fun setLatLng(position: LatLng) {
        mutableLatLng.value = position
    }

    //  =======================================================

    //  Non-Google Play Location Data
    //  Location data obtained via LocationManager
    private var mutableLocation = MutableLiveData<Location>()

    //var holdPosition:LatLng = LatLng(1.2973621724152964, 103.84926432802061)
    val holdLocation: LiveData<Location> get() = mutableLocation

    fun setLocation(position: Location) {
        mutableLocation.value = position
    }
}