package sg.edu.smu.teamrtt.localizertt.operations.wifi

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.net.wifi.rtt.RangingRequest
import android.net.wifi.rtt.RangingResult
import android.net.wifi.rtt.WifiRttManager
import android.util.Log
import sg.edu.smu.teamrtt.localizertt.model.dataview.RTTDetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.model.dataview.WiFiScanDataViewModel
import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangeResult.UniqueAccessPoint
import sg.edu.smu.teamrtt.localizertt.operations.wifi.callback.RTTRangeResultCallbackV2
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.RSSI_FILTER
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executor

/**
 * WiFi RTT Ranging Operation Class
 *
 * What this does:
 * 1. Store the AP Scan result
 * 2. Filter the AP Scan result based on RSSI, channel and channel width.
 * 3. Invokes the RTT Ranging of all available APs
 * 4. As RTT scan has Max Peer Limits (only can certain number of APs at one time)
 * 5. This class chunks the list of available APs into the limit and RTT scan them in chunks
 * 6. So that ALL APs are scanned.
 * 7. Once ranged, Updates the respective ViewModels such that the corresponding UI are updated accordingly.
 *
 * Ref:
 *  https://developer.android.com/develop/connectivity/wifi/wifi-scan
 *  https://developer.android.com/develop/connectivity/wifi/wifi-rtt#:~:text=Wi%2DFi%20RTT%20was%20introduced,store%20and%20retrieve%20this%20data.
 *
 * @author William Tan. 2025 Jan 17.
 * Tracking:
 * 1. 2025 Nov 03, William Tan: New Operations blah blah blah
 */
class RTTRangingOpsV2(
    val mainActivityContext: Context,
    private val wifiManager: WifiManager,
    val wifiRttManager: WifiRttManager,
    private val wifiScanDataViewModel: WiFiScanDataViewModel,
    val rttDetailsViewModel: RTTDetailsDataViewModel
) {

    /**
     * TAG for Logging
     */
    private val classTAG = this.javaClass.name

    /**
     *  Current List of ScanResult from the AP
     *  (Sorted descending in order of RSSI)
     */
    private var currentScanResult: List<ScanResult> = emptyList()

    /**
     *  All collected scanResult seen throughout the app is active.
     *  (Sorted descending in order of RSSI)
     */
    private var pickedScanResultForRTT: List<ScanResult> = emptyList()


    private var rttCandidateSet = ConcurrentHashMap<String, ScanResult>()
    private var rttIgnoreSet = ConcurrentHashMap<String, ScanResult>()

    /**
     *
     */
    private var availableBSSIDForRangingFlag: Boolean = false

    /**
     * RSSI Filter
     *
     * Extracted from the App's preferences store in DataStore.
     * Used to filter away BSSID that is below this filter level and keep only those above this leve.
     */
    private var filterRSSILevel: Int = RSSI_FILTER.toInt()

    /**
     * List of RTT scan results of all APs
     */
    var listOfRTTRangingResults: MutableList<RangingResult> = mutableListOf()

    /**
     * Range Request Counter
     * Tracks the index of listOfReq when calling each RangeRequest one by one.
     */
    var requestCounter: Int = 0

    /**
     * List of RangingRequest which will be called one by one.
     */
    var listOfRangingRequests = mutableListOf<RangingRequest>()

    /**
     * RTT Scan is Free Flag
     * True indicates that RTT ranging is available.
     * False indicates that the previous RTT ranging is still going on. Wait until Flag becomes True.
     */
    var rangeRTTIsFreeFlag: Boolean = true

    /**
     * Executor to run separately task
     */
    var mainExecutor: Executor? = null

    /**
     * Init for this class.
     *
     * Doe the following:
     * 1. Obtain the RSSI level to filter BSSID.
     */
    init {
        //  Obtain the RSSI Level to filter BSSID for RTT Scan.
        filterRSSILevel = AppPrefStore(mainActivityContext).loadRSSIFilter()
    }


    /**
     *  Store the AP Scan Results
     *
     *  This is initiated in MainActivity and is triggered from the WiFiScanBCR.
     *
     *  Does the following:
     *  1. Sort the result (via RSSI) and store the result.
     *  2. Extract the result for the UI for displaying to the user
     *  3. Call filterSelectBestBSSIDForRTT() function to select the best BSSID for RTT Scan. (See the function for details.)
     */
    @SuppressLint("MissingPermission")  //  William: I suppressed Missing Permission, as the check already performed on MainActivty, so no idea why Android Studio kept prompting this.
    fun storeScanResults() {

        //  Obtain the wifi scan result
        val scanResult: List<ScanResult> = wifiManager.scanResults

        //  Sort by RSSI strength and store.
        currentScanResult = scanResult.sortedByDescending { it.level }

        //  Update view models. i.e. Such that other parts like UI Fragments can use it.
        updateViewModels()

        //  Filter and select the best BSSID for RTT scan
        pickBSSIDForRTTRanging()
    }

    /**
     * Update the View Models
     *
     * 1. Extract the relevant data from the WiFi scan.
     * 2. Push to ViewModels.
     * 3. Such that other parts such as UI Fragment can get updated with the scan results.
     */
    private fun updateViewModels() {

        //  List of SSID for UI, In format BSSID, SSID, RSSI. Eg: 94:43:F3:2A:30:2F, WLAN-SMU, -52, 5210
        var reformattedListOfSSID = emptyArray<String>()

        //  Generate list of scan result
        for (eachScan in currentScanResult) {

            //  Channel width check
            //            if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_20MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_20MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_40MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_40MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_80MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_80MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_160MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_160MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_320MHZ) {
            //                Log.i(classTAG, "CHANNEL_WIDTH_320MHZ")
            //            }
            //            else if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ) {
            //                Log.i("classTAG, "CHANNEL_WIDTH_80MHZ_PLUS_MHZ")
            //            }
            //            else {
            //                Log.i(classTAG, "CHANNEL_UNKNOWN")
            //            }

            //  Find the frequency of the channel
            val channelFreq: Int = if (eachScan.channelWidth == ScanResult.CHANNEL_WIDTH_20MHZ)
                eachScan.frequency
            else
                eachScan.centerFreq0

            if (eachScan.channelWidth != ScanResult.CHANNEL_WIDTH_20MHZ &&
                channelFreq >= 5000
                && eachScan.level >= filterRSSILevel
            ) {
                reformattedListOfSSID += eachScan.BSSID + ", " + eachScan.SSID + ", " + eachScan.level + ", " + channelFreq
            }

            //reformattedListOfSSID += eachScan.BSSID + ", " + eachScan.SSID + ", " + eachScan.level + ", " + channelFreq
        }

        //  Update the view models. E.g. For UI
        wifiScanDataViewModel.setListOfSSID(reformattedListOfSSID)
    }

    /**
     * Given ScanResult, filter and select the best set of BSSID for RTT scan
     *
     * Executed during storeScanResults() function call then use for RTT scan.
     *  - - Filter BSSID before RTT using widest channel in 5GH range for BSSID check
     *
     * Returns set of selected ScanResult tag with timestamp
     *
     * Ref: https://developer.android.com/reference/android/net/wifi/ScanResult
     * @author William Tan 2025 Mar 07.
     */
    private fun pickBSSIDForRTTRanging() {

        //  Filter only if scan result is available.
        if (currentScanResult.isNotEmpty()) {

            //  Reload the filter level if there was any changes by the user in the config(UI) fragment.
            filterRSSILevel = AppPrefStore(mainActivityContext).loadRSSIFilter()

            //  Init empty Best Picked ScanResult
            val localPickedScanResultForRTT: MutableList<ScanResult> = mutableListOf()

            //  Iterate through current WiFi scan result.
            for (eachScan in currentScanResult) {

                //  Check if each scan is already inside Candidate Group
                if (rttCandidateSet.isNotEmpty() && rttCandidateSet.containsKey(eachScan.BSSID)) {
                    Log.i(classTAG, "${eachScan.BSSID} exist in rttCandidateSet")

                    //  Update rttCandidateSet with that BSSID's ScanResult
                    val existingScanResult = rttCandidateSet.get(eachScan.BSSID)
                    if (existingScanResult != null && (eachScan.timestamp > existingScanResult.timestamp)) {
                        //  Update existing set.
                        rttCandidateSet[eachScan.BSSID] = eachScan
                    }

                    //  Add to RTT ranging list
                    localPickedScanResultForRTT.add(eachScan)
                } else if (rttIgnoreSet.isNotEmpty() && rttIgnoreSet.containsKey(eachScan.BSSID)) {
                    Log.i(classTAG, "${eachScan.BSSID} exist in rttIgnoreSet. Don't Range to these BSSID.")

                    //  Update rttIgnoreSet with that BSSID's ScanResult
                    val existingScanResult = rttIgnoreSet.get(eachScan.BSSID)
                    if (existingScanResult != null && (eachScan.timestamp > existingScanResult.timestamp)) {
                        //  Update existing set.
                        rttIgnoreSet[eachScan.BSSID] = eachScan
                    }
                } else {
                    //  =====================
                    //  BSSID not seen before
                    //  =====================
                    Log.i(classTAG, "${eachScan.BSSID} not seen before. Range at least once.")

                    //  Unlike previous method, we range to un-seen BSSID atleast once.
                    //  We then filter them post Ranging. Such that if those BSSID that cannot range in 5GHz,
                    //  eligible BSSID from the same AP can still have a chance in 2GH, etc, etc to be included.
                    localPickedScanResultForRTT += eachScan
                }
            }

            if (localPickedScanResultForRTT.isNotEmpty()) {

                //  Store to handle.
                pickedScanResultForRTT = localPickedScanResultForRTT

                //  Setup the flag to trigger RTT scan, since the RTT scan is a separate thread/process
                availableBSSIDForRangingFlag = true
            } else
                Log.e(classTAG, "No BSSID available for RTT Ranging during this WiFi Scan.")
        }
    }


    /**
     * Invoke RTT Scan
     *
     *  1. Get the WiFi Scan result
     *  2. Extract only the APs that the phone currently see (because, we might have walk around, some AP may no longer in range)
     *  2. Sort in descending order
     *  3. Chunk the list of AP to the size of 1: So each RangeRequest has only 1 AP.
     *  4. Start the RTT Scan. Only moving to the next AP Range ONLY if the AP has completed ranging.
     *  5. Save the result to CSV routine. (CSV Ops will check if we need to store the data to file or not)
     *  6. RTT Scan is recursive, scan only stop if all APs ranging is completed.
     *
     *  William Notes: 2025 Sep 18, New version: Recursive scan one AP at a time.
     */
    //  William: I suppressed Missing Permission, as the check already performed on MainActivty, so no idea why Android Studio kept prompting this.
    @SuppressLint("MissingPermission")
    fun invokeRTTScan() {

        //  Check if storeFlag is set, this indicate a stored result is present.
        //  Check if rttScanIsFreeFlag is set, this indicate there are no previous ranging occurring at this moment.
        if (availableBSSIDForRangingFlag && rangeRTTIsFreeFlag && currentScanResult.isNotEmpty() && pickedScanResultForRTT.isNotEmpty()) {

            // Log.i(TAG,"Invoking RTT Scan...")

            //  Init: Empty the list requests and results for new Ranging.
            listOfRangingRequests = mutableListOf()
            listOfRTTRangingResults = mutableListOf()

            //  Chunk the List to max peers to size of 1.
            val listOfChunkedOfOneSortedScanResult = pickedScanResultForRTT.sortedByDescending { it.level }.chunked(1)
            for (element in listOfChunkedOfOneSortedScanResult) {
                val chunkResult: List<ScanResult> = element
                val req: RangingRequest = RangingRequest.Builder().addAccessPoints(chunkResult).build()
                // Log.i(TAG," - Eligible Range Request: $req")
                listOfRangingRequests.add(req)
            }

            //  Start Ranging if list is not empty.
            if (listOfRangingRequests.isNotEmpty()) {

                //  New ranging, reset counter to zero.
                requestCounter = 0

                //  Get the 1st and single range request
                val singleRangeRequest = listOfRangingRequests[requestCounter]

                //  Increment the counter to the next index.
                requestCounter++

                // Build the callback: Callback will setup next Ranging within it. (Recursive call)
                val rangeResultCallback = RTTRangeResultCallbackV2(
                    singleRangeRequest,
                    requestCounter,
                    this
                )

                //  Pass it on for RTT ranging
                mainExecutor = mainActivityContext.mainExecutor
                mainExecutor.let {

                    //  Start the ranging.
                    if (it != null) {

                        //Log.i(TAG, " - Scanning ${rrequest}}")

                        wifiRttManager.startRanging(
                            singleRangeRequest,
                            it,
                            rangeResultCallback
                        )

                        //  Once range start, set the flag to false.
                        //  This indicates that ranging is happening.
                        //  Hence, if next invokeRTTScan() occurs while ranging is still running,
                        //  we skip to the next one, while not interrupting the current one.
                        rangeRTTIsFreeFlag = false
                    }
                }
            } else
                Log.i(classTAG, "No Range Requests. Deferring to next scan.")
        }
    }

    /**
     * Execute when all BSSID have been Ranged
     *
     * 1. When all BSSID in pickedScanResultForRTT is ranged. This function is called.
     */
    fun sortRTTRangeResult() {

        //  Check if the collected data is present
        if (listOfRTTRangingResults.isNotEmpty()) {

            //  Init the empty holder to hold each unique Access-Point identified.
            var localCollectionOfUniqueAccessPoint: HashSet<UniqueAccessPoint> = hashSetOf()

            //  Go through every single RTT Ranging Results
            for (eachRangingResult in listOfRTTRangingResults) {

                //  For each Range Result, use addToCollectionOfUniqueAccessPoints to sort it into its own unique AccessPoint holder.
                //  E.g. Each AP might have multiple BSSID (with same re-occurring 5 HexDec out of 6)
                //  This function sorts BSSID that has the same into its own Unique-AccessPoint holder, so that all similar BSSID all contain in one holder.
                localCollectionOfUniqueAccessPoint = UniqueAccessPoint.addToCollectionOfUniqueAccessPoints(
                    strBSSID = eachRangingResult.macAddress.toString(),
                    rangingResult = eachRangingResult,
                    currentCollectionOfUniqueAccessPoint = localCollectionOfUniqueAccessPoint)
            }

            //  Go through each holder and sort into RTT Candidate and Ignore List
            for (eachUniqueAP in localCollectionOfUniqueAccessPoint) {
                val bestBSSID = eachUniqueAP.getBestBSSIDToRepresentAP()
                val setOfRejectedBSSID = eachUniqueAP.getRestOfBSSIDNotSelected(bestBSSID)

                //  Store to RTT Candidate Set.
                if (!rttCandidateSet.containsKey(bestBSSID)) {
                    for (eachScanResult in currentScanResult) {
                        if (eachScanResult.BSSID.compareTo(bestBSSID) == 0) {
                            rttCandidateSet[bestBSSID] = eachScanResult
                            break
                        }
                    }
                }

                //  Store rejected BSSID into Ignore Set.
                if (setOfRejectedBSSID.isNotEmpty()) {
                    for (eachRejectedBSSID in setOfRejectedBSSID) {
                        if (!rttIgnoreSet.containsKey(eachRejectedBSSID)) {
                            for (eachScanResult in currentScanResult) {
                                if (eachScanResult.BSSID.compareTo(bestBSSID) == 0) {
                                    rttIgnoreSet[eachRejectedBSSID] = eachScanResult
                                    break
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Get all candidate BSSID
     */
    fun getRTTCandidatesBSSIDs(): MutableSet<String> {

        //  These are the keys of the rttCandidateSet hashmap
        return rttCandidateSet.keys
    }
}