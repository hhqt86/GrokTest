package sg.edu.smu.teamrtt.localizertt.callbacks

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.util.Log
import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangingOpsV2

/**
 * Wifi Scan Callback using BroadcastReceiver
 *
 * For our purpose:
 * 1. Callback after scan for the result.
 * 2. Scan for the list of APs
 * 3. Invoke the ScanOps to save the list of APs for RTT Scan.
 *
 * @author William Tan Kiat Wee, 2025 Apr 11.
 */
class WiFiScanBCR(private val rangingRTTOps: RTTRangingOpsV2) : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {

        val success = intent?.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
        if (success == true) {

            //  Invoke to store the result.
            rangingRTTOps.storeScanResults()
        } else
            Log.e(this.javaClass.name, "WiFi Scan Failure")
    }
}