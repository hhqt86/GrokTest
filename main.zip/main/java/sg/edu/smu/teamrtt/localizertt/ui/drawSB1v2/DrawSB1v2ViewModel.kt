package sg.edu.smu.teamrtt.localizertt.ui.drawSB1v2

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DrawSB1v2ViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        //value = "SOSS B1 Dynamic"
        value = "Dynamic View"
    }
    val text: LiveData<String> = _text
}