package sg.edu.smu.teamrtt.localizertt.research.map_visualization;

import androidx.annotation.NonNull;

/**
 * Immutable container for (x,y,value).
 *
 * @author Thu Tran, 2025 Aug 27.
 * Tracking:
 * - 2025 Aug 27: Migrated from Thu's GIT codebase.
 * - 2025 Nov 5: Added BSSID, RSSI
 */
public class PointVal {

    private final String strBSSID;
    private final double x;
    private final double y;
    private final double meanRTTDistance;

    private final double meanRSSI;

    public PointVal(double x, double y, double meanRTTDistance) {
        this.strBSSID = "";
        this.x = x;
        this.y = y;
        this.meanRTTDistance = meanRTTDistance;
        this.meanRSSI = 0.0;
    }

    public PointVal(String strBSSID, double x, double y, double meanRTTDistance, double meanRSSI) {
        this.strBSSID = strBSSID;
        this.x = x;
        this.y = y;
        this.meanRTTDistance = meanRTTDistance;
        this.meanRSSI = meanRSSI;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getMeanRTTDistance() {
        return meanRTTDistance;
    }

    public double getMeanRSSI() {
        return meanRSSI;
    }

    public String getStrBSSID() {
        return strBSSID;
    }

    @NonNull
    @Override
    public String toString() {
        return String.format("BSSID: %s, (%.2f, %.2f) -> Mean Distance: %.3f, Mean RSSI: %.3f", strBSSID, x, y, meanRTTDistance, meanRSSI);
    }
}
