package sg.edu.smu.teamrtt.localizertt.callbacks

import com.google.android.gms.location.LocationAvailability
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import com.google.android.gms.maps.model.LatLng
import sg.edu.smu.teamrtt.localizertt.MainActivity
import sg.edu.smu.teamrtt.localizertt.model.dataview.LocationDataViewModel
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations

/**
 * Location Callback for GPS Location (Google Play Edition)
 *
 * Triggered when location result is available
 *
 * @author William Tan Kiat Wee 2025 May 15.
 */
class LocationCB(private val mainActivity: MainActivity, private val locationDataViewModel: LocationDataViewModel) : LocationCallback() {

    override fun onLocationAvailability(availability: LocationAvailability) {
//        if (availability.isLocationAvailable) {
//            // Location available
//            Log.i("William", "Location available")
//        } else {
//            // Handle location being unavailable
//            Log.e("William", "Location Unavailable")
//        }
    }

    override fun onLocationResult(result: LocationResult) {

        //  For each result update the view model based on whichever location modality it obtained from via Google Play Services.
        //  E.g. GPS/WiFi/Cellular/etc
        result.locations.forEach { location ->
            // Update data using location
            //Log.i("William", "Location Data. Lat: ${location.latitude}, Long: ${location.longitude}")

            //  Update the viewModel location via lat lng.
            locationDataViewModel.setLatLng(LatLng(location.latitude, location.longitude))

            //  Save to CSV
            CSVOperations().saveToCSVGooglePlayAPILocation(
                mainActivity,
                location.time,
                location.latitude,
                location.longitude,
                location.altitude
            )
        }
    }
}