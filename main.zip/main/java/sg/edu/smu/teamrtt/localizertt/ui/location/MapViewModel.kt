package sg.edu.smu.teamrtt.localizertt.ui.location

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MapViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "GPS"
    }
    val text: LiveData<String> = _text
}