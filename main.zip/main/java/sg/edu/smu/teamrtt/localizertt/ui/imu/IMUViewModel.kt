package sg.edu.smu.teamrtt.localizertt.ui.imu

import android.hardware.SensorEvent
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * IMU View Model
 *
 * The sensor data View Model for updating the UI Fragment from MainActivity
 */
class IMUViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "IMU"
    }
    val text: LiveData<String> = _text

    // =======================================

    //  Accel Data
    private var lSensorAccelEvent = MutableLiveData<SensorEvent>()
    val currentSensorAccelEvent: LiveData<SensorEvent> get() = lSensorAccelEvent

    fun setSensorAccelEvent(sensorEvent: SensorEvent) {
        lSensorAccelEvent.value = sensorEvent
    }

    // =======================================

    //  Magnetic Field Data
    private var lSensorMagEvent = MutableLiveData<SensorEvent>()
    val currentSensorMagEvent: LiveData<SensorEvent> get() = lSensorMagEvent

    fun setSensorMagEvent(sensorEvent: SensorEvent) {
        lSensorMagEvent.value = sensorEvent
    }

    // =======================================

    //  Gyro Data
    private var lSensorGyroEvent = MutableLiveData<SensorEvent>()
    val currentSensorGyroEvent: LiveData<SensorEvent> get() = lSensorGyroEvent

    fun setSensorGyroEvent(sensorEvent: SensorEvent) {
        lSensorGyroEvent.value = sensorEvent
    }

    // =======================================

    //  Step Detector Data
    private var lSensorStepDetectedEvent = MutableLiveData<Long>()
    val currentSensorStepDetectedEvent: LiveData<Long> get() = lSensorStepDetectedEvent

    fun setSensorStepDetectedEvent(stepData: Long) {
        lSensorStepDetectedEvent.value = stepData
    }

    // =======================================

    //  Orientation Data
    private var lSensorComputedDataOrientation = MutableLiveData<FloatArray>()
    val currentComputedDataOrientation: LiveData<FloatArray> get() = lSensorComputedDataOrientation

    fun setComputedDataOrientation(computedOrientation: FloatArray) {
        lSensorComputedDataOrientation.value = computedOrientation
    }


    // =======================================

    private var flagStartScan = MutableLiveData<Boolean>()
    val currentFlagStartScan: LiveData<Boolean> get() = flagStartScan

    fun setFlagStartScan(flagSS: Boolean) {
        flagStartScan.value = flagSS
    }
}