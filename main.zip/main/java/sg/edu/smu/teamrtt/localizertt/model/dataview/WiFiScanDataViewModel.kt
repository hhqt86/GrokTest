package sg.edu.smu.teamrtt.localizertt.model.dataview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * WiFi Scan Data View Model
 *
 * Transferring of WiFi scan result from MainActivity to HomeFragment
 */
class WiFiScanDataViewModel : ViewModel() {

    private var flagStartScan = MutableLiveData<Boolean>()
    val currentFlagStartScan: LiveData<Boolean> get() = flagStartScan

    fun setFlagStartScan(flagSS: Boolean) {
        flagStartScan.value = flagSS
    }

    //  ===================================================================================

    private var listOfSSID = MutableLiveData<Array<String>>()
    val currentListOfSSID: LiveData<Array<String>> get() = listOfSSID

    fun setListOfSSID(ssidList: Array<String>) {
        listOfSSID.value = ssidList
    }

}