package sg.edu.smu.teamrtt.localizertt.util

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import sg.edu.smu.teamrtt.localizertt.dataStoreW

//  ========================================================================================================================
//  ========================================================================================================================

const val APSKEY_AP_DEFAULT_TEST: String = "apDefaultTest"
const val APSKEY_AP_SCAN_TIME: String = "apScanTime"
const val APSKEY_RTT_SCAN_TIME: String = "rttScanTime"
const val APSKEY_CACHE_AP_TRACK_TIME: String = "cacheAPTrackTime"
const val APSKEY_CELS_CAPTURE_TIME: String = "celsCaptureTime"
const val APSKEY_RSSI_FILTER: String = "rssiFilter"
const val APSKEY_MAX_NO_OF_AP: String = "maxNoOfAP"
const val APSKEY_SAVE_TO_CSV: String = "saveToCSV"

//  ========================================================================================================================
//  ========================================================================================================================

/**
 * CONSTANTS.
 * RSSI FILTER Value: Only APs above it will be considered.
 * Initially chosen at -75, then lowered to -85 to take in account, user towards and away from an AP.
 */
const val RSSI_FILTER: Long = -85

/**
 * CONSTANTS.
 * Average Human Step in meters. Default: 0.76 meters, but need to adjust, seems to big for asians. E.g. William: Mine is 0.4 meters
 */
const val avgHumanStepInMeters = 0.4f

//  ========================================================================================================================
//  ========================================================================================================================

/**
 * Heatmap
 * Mask Grid Width for static map (gridWidth = 21.0) of SOSS and dynamic map (heatMapWidth = 50.0)
 */
const val gridWidth = 21.0
const val heatMapWidth = 50.0

/**
 * Heatmap
 * Mask Grid Height for static map (gridHeight = 21.0) of SOSS and dynamic map (heatMapHeight = 50.0)
 */
const val gridHeight = 22.0
const val heatMapHeight = 50.0

/**
 * Heatmap
 * Mask Grid Resolution
 */
const val gridResolution = 20

/**
 * Heatmap
 * set the error of the rtt as 4 meters
 */
const val gridMaskTolerance = 4.0 //meters
const val apCircleThresholdToMarkAsFound = 6.0 //meters
//  ========================================================================================================================
//  ========================================================================================================================

//  HARDCODED AP
//  List of 5 hardcoded AP MAC For Testing Only. (To be remove in Production)
//  AP listed are from SOSS B1, see soss_b1_v2.jpg in drawable folder.
//  AP are name from HARDCODED_AP0 to HARCODED_AP4
//const val HARDCODED_AP0 = "1c:28:af:41:97:92"
//const val HARDCODED_AP1 = "1c:28:af:41:90:f2"
//const val HARDCODED_AP2 = "1c:28:af:41:b8:32"
//const val HARDCODED_AP3 = "1c:28:af:41:df:32"
//const val HARDCODED_AP4 = "1c:28:af:41:89:b2"

//  AP outside Rajesh's  office
//const val RAJESH_OFFICE_AP = "b0:b8:67:62:54:12"

//  AP in Research Way 4
//const val RESEARCH_WAY4_AP = "b0:b8:67:63:1f:31"

//  This is the target AP currently under test in SOSS B1.
//  When set, App only range to this hardcoded AP
//  Default: HARDCODED_AP_TARGET=HARDCODED_AP0
//const val HARDCODED_AP_TARGET = HARDCODED_AP0

//  ========================================================================================================================
//  ========================================================================================================================


/**
 * App Preference Store Class
 *
 * Interfaces with data store to load the app preferences.
 *
 * ref: https://stackoverflow.com/questions/73414839/how-to-load-instantly-data-from-data-store
 *
 *
 * @author William Tan Kiat Wee. 3 Apr 2025
 */
class AppPrefStore(private val context: Context) {

    /**
     * Load AP Scan Time
     *
     * AP Scan Time = The time each AP scan will be initiated (loop).
     * E.g. If AP Scan Time = 10000ms, AP Scanning will occur at every 10 seconds.
     * Loads from the datastore. Default= 10000ms or 10 seconds, if no previous data is stored.
     *
     * Return in Long, milliseconds.
     */
    fun loadAPScanTime(): Long {

        var apScanPeriod: Long = 10000

        val dsKeyAPScanTime = longPreferencesKey(APSKEY_AP_SCAN_TIME)
        runBlocking {
            apScanPeriod = context.dataStoreW.data.map {
                it[dsKeyAPScanTime] ?: 10000
            }.first()
        }

        return apScanPeriod
    }

//    /**
//     * Load AP Scan Time
//     *
//     * AP Scan Time = The time each AP scan will be initiated (loop).
//     * E.g. If AP Scan Time = 10000ms, AP Scanning will occur at every 10 seconds.
//     * Loads from the datastore. Default= 10000ms or 10 seconds, if no previous data is stored.
//     *
//     * Return in Long, milliseconds.
//     */
//    fun loadAPDefaultTest(): String {
//
//        var apBSSID: String = HARDCODED_AP_TARGET
//
//        val dsKeyAPDefaultTest = stringPreferencesKey(APSKEY_AP_DEFAULT_TEST)
//        runBlocking {
//            apBSSID = context.dataStoreW.data.map {
//                it[dsKeyAPDefaultTest] ?: HARDCODED_AP_TARGET
//            }.first()
//        }
//
//        return apBSSID
//    }

    /**
     * Load RTT Scan Time
     *
     * RTT Scan Time = The time each RTT scan will be initiated (loop)
     * E.g. If RTT Scan Time = 2000ms, AP Scanning will occur at every 2 seconds.
     * Loads from the datastore. Default= 2000ms or 2 seconds, if no previous data is stored.
     *
     * Return in Long, milliseconds.
     */
    fun loadRTTScanTime(): Long {

        var rttScanPeriod: Long = 100

        val dsKeyRTTScanTime = longPreferencesKey(APSKEY_RTT_SCAN_TIME)
        runBlocking {
            rttScanPeriod = context.dataStoreW.data.map {
                it[dsKeyRTTScanTime] ?: 100
            }.first()
        }

        return rttScanPeriod
    }

    /**
     * Load AP Tracking Time
     *
     * AP Tracking Time = The cache of how long data should be kept (tracked).
     * E.g. If Time = 10 * 60 * 1000s, this meant that data would be kept for 10minutes (any data older than 10min will be removed).
     * Loads from the datastore. Default= 10 * 60 * 1000ms or 10min, if no previous data is stored.
     *
     * Return in Long, milliseconds.
     */
    fun loadAPTrackingTime(): Long {

        var trackingTime: Long = 10 * 60 * 1000L

        val dsKeyCacheAPTrackTime = longPreferencesKey(APSKEY_CACHE_AP_TRACK_TIME)
        runBlocking {
            trackingTime = context.dataStoreW.data.map {
                it[dsKeyCacheAPTrackTime] ?: (10 * 60 * 1000L)
            }.first()
        }

        return trackingTime
    }

    /**
     * Load Capture Time
     *
     * Capture Time = The time needed to capture data for the least-square constant-error algo.
     * In this case, a user needs to remain in a position to capture the data, this is the time needed to stay in that position.
     * E.g. If Time = 20000ms, This means the user has to stay in that position for 20 seconds before moving to the next location.
     * Loads from the datastore. Default= 20000ms or 20 seconds, if no previous data is stored.
     *
     * Return in Long, milliseconds.
     */
    fun loadCaptureTime(): Long {

        var celsCaptureTime: Long = 20 * 1000L

        val dsKeyCELSCaptureTime = longPreferencesKey(APSKEY_CELS_CAPTURE_TIME)
        runBlocking {
            celsCaptureTime = context.dataStoreW.data.map {
                it[dsKeyCELSCaptureTime] ?: (20 * 1000L)
            }.first()
        }

        return celsCaptureTime
    }

    /**
     * Load RSSI Filter
     *
     * RSSI Filter = The minimum level in dBm to select the appropriate AP
     * During the AP Scan, if the RSSI of the AP falls below this filter, the AP will not be considered for RTT scan.
     *
     * Loads from the datastore. Default= -70 or -70dBm, if no previous data is stored.
     *
     * Return in Int (dBm)
     */
    fun loadRSSIFilter(): Int {

        var rssiFilterValue: Long = RSSI_FILTER

        val dsKeyrssiFilter = longPreferencesKey(APSKEY_RSSI_FILTER)
        runBlocking {
            rssiFilterValue = context.dataStoreW.data.map {
                it[dsKeyrssiFilter] ?: RSSI_FILTER
            }.first()
        }

        return rssiFilterValue.toInt()
    }


    /**
     * Set RSSI Filter
     *
     * RSSI Filter = The minimum level in dBm to select the appropriate AP
     * During the AP Scan, if the RSSI of the AP falls below this filter, the AP will not be considered for RTT scan.
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setRSSIFilter(rssiValue: Long) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyrssiFilter = longPreferencesKey(APSKEY_RSSI_FILTER)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyrssiFilter] = rssiValue
            }
        }
    }


    /**
     * Set Maximum No of AP
     *
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setMaxNoOfAP(noOfAP: Long) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyMaxNoOfAp = longPreferencesKey(APSKEY_MAX_NO_OF_AP)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyMaxNoOfAp] = noOfAP
            }
        }
    }

    /**
     * Set RTT Scan Time
     *
     * RTT Scan Time = The time each RTT scan will be initiated (loop)
     * E.g. If RTT Scan Time = 2000ms, AP Scanning will occur at every 2 seconds.
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setRTTScanTime(scanTime: Long) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyRTTScanTime = longPreferencesKey(APSKEY_RTT_SCAN_TIME)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyRTTScanTime] = scanTime
            }
        }
    }

    /**
     * Set Capture Time
     *
     * Capture Time = The time needed to capture data for the least-square constant-error algo.
     * In this case, a user needs to remain in a position to capture the data, this is the time needed to stay in that position.
     * E.g. If Time = 20000ms, This means the user has to stay in that position for 20 seconds before moving to the next location.
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setCaptureTime(captureTime: Long) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyCELSCaptureTime = longPreferencesKey(APSKEY_CELS_CAPTURE_TIME)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyCELSCaptureTime] = captureTime
            }
        }
    }

    /**
     * Set Capture Time
     *
     * Capture Time = The time needed to capture data for the least-square constant-error algo.
     * In this case, a user needs to remain in a position to capture the data, this is the time needed to stay in that position.
     * E.g. If Time = 20000ms, This means the user has to stay in that position for 20 seconds before moving to the next location.
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setCacheAPTrackTime(cacheAPTrackTime: Long) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyCacheAPTrackTime = longPreferencesKey(APSKEY_CACHE_AP_TRACK_TIME)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyCacheAPTrackTime] = cacheAPTrackTime
            }
        }
    }

    /**
     * Set AP Scan Time
     *
     * AP Scan Time = The time each AP scan will be initiated (loop).
     * E.g. If AP Scan Time = 10000ms, AP Scanning will occur at every 10 seconds.
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setAPScanTime(apScanTime: Long) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyAPScanTime = longPreferencesKey(APSKEY_AP_SCAN_TIME)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyAPScanTime] = apScanTime
                //Log.i("William", "textEditAPScanTime addTextChangedListener!")
            }
        }
    }

    /**
     * Set AP Scan Time
     *
     * AP Scan Time = The time each AP scan will be initiated (loop).
     * E.g. If AP Scan Time = 10000ms, AP Scanning will occur at every 10 seconds.
     *
     * Stores the data to the datastore asynchronously.
     */
    fun setDefaultTestAP(apBSSID: String) {

        CoroutineScope(Dispatchers.IO).launch {
            val dsKeyAPDefaultTest = stringPreferencesKey(APSKEY_AP_DEFAULT_TEST)
            context.dataStoreW.edit { usrData ->
                usrData[dsKeyAPDefaultTest] = apBSSID
                //Log.i("William", "textEditAPScanTime addTextChangedListener!")
            }
        }
    }

    /**
     * Set Save to CSV Flag
     *
     * If set, RTT scan and sensor data will be saved to CSV files
     *
     * Stores the flag to the datastore asynchronously.
     */
    fun setSaveCSVFlag(saveFlag: Boolean) {

        //  https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/MainActivity.kt
        CoroutineScope(Dispatchers.IO).launch {
            val flagSaveToCSV = booleanPreferencesKey(APSKEY_SAVE_TO_CSV)
            context.dataStoreW.edit { usrData ->
                usrData[flagSaveToCSV] = saveFlag
            }
        }
    }
}