package sg.edu.smu.teamrtt.localizertt.callbacks

import android.location.Location
import android.location.LocationListener
import sg.edu.smu.teamrtt.localizertt.MainActivity
import sg.edu.smu.teamrtt.localizertt.model.dataview.LocationDataViewModel
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations

/**
 * Location Callback Non-Google Play Service Version
 *
 * Location data is obtained via LocationManager.
 *
 * Notes: This callback can only work if device have access to GPS signals.
 *
 * @author William Tan Kiat Wee 2025 May 15.
 */
class LocationCBNGP(private val mainActivity: MainActivity, private val locationDataViewModel: LocationDataViewModel) : LocationListener {

    override fun onLocationChanged(locData: Location) {
        //Log.i("William", "Non-Google Play Services. Location available. Lat:${p0.latitude}, Lng:${p0.longitude}")

        //  Save to CSV
        CSVOperations().saveToCSVGooglePlayAPILocation(
            mainActivity,
            locData.time,
            locData.latitude,
            locData.longitude,
            locData.altitude
        )

        //  Update the viewModel location
        //locationDataViewModel.setLocation(locData)
    }
}