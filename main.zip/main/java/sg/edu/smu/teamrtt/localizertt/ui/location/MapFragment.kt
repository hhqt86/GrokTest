package sg.edu.smu.teamrtt.localizertt.ui.location

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.ViewModelProvider
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentGalleryBinding
import sg.edu.smu.teamrtt.localizertt.model.dataview.LocationDataViewModel

/**
 * Map Fragment
 *
 * This UI Fragment has the following functionality:
 * 1. Displays the user position on Google Play Services Map
 *
 * William Notes:
 * 1. For testing purpose we use the map, in actual production roll out for Police, this map functionality may be disabled.
 * 2. DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 19: Created by William Tan Kiat Wee.
 */
class MapFragment : Fragment() {

    private var _binding: FragmentGalleryBinding? = null

    private var thisContext: Context? = null
    private var position: LatLng = LatLng(1.29743, 103.84958)
    private val locationDataViewModel: LocationDataViewModel by activityViewModels()

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        thisContext = this.context

        val mapViewModel = ViewModelProvider(this).get(MapViewModel::class.java)

        _binding = FragmentGalleryBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textGallery
        mapViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        val mapView = binding.mapView
        with(mapView) {
            // Initialise the MapView
            onCreate(null)

            // Set the map ready callback to receive the GoogleMap object
            getMapAsync {
                MapsInitializer.initialize(this.context)
                setMapLocation(it)
            }
        }

        //        locationDataViewModel.holdPosition.observe(viewLifecycleOwner, Observer { value ->
        //            Log.i("William", "Location Data. Lat: ${value.latitude}, Long: ${value.longitude}")
        //            position = value
        //        })

        locationDataViewModel.holdPosition.observe(viewLifecycleOwner) { value ->
            // Log.i("William", "Location Data. Lat: ${value.latitude}, Long: ${value.longitude}")
            position = LatLng(value.latitude, value.longitude)

            refresh()
        }

        locationDataViewModel.holdLocation.observe(viewLifecycleOwner) { value ->
            // Log.i("William", "Location Data. Lat: ${value.latitude}, Long: ${value.longitude}")
            position = LatLng(value.latitude, value.longitude)

            refresh()
        }

        return root
    }

    /**
     * Refresh the map View
     *
     * Given the updated position (lat, lng)
     */
    private fun refresh() {

        val mapView = binding.mapView
        with(mapView) {

            getMapAsync {
                //  Clear the marker.
                it.clear()

                //  Mark the new position in map.
                setMapLocation(it)
            }
        }
    }

    /**
     * Set the map location
     *
     * Given the updated position (lat, lng)
     */
    private fun setMapLocation(map: GoogleMap) {

        with(map) {
            moveCamera(CameraUpdateFactory.newLatLngZoom(position, 17f))
            addMarker(MarkerOptions().position(position))
            mapType = GoogleMap.MAP_TYPE_NORMAL
            setOnMapClickListener {
                Toast.makeText(thisContext, "Clicked on map", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}