package sg.edu.smu.teamrtt.localizertt.callbacks

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import android.view.Display
import sg.edu.smu.teamrtt.localizertt.MainActivity
import sg.edu.smu.teamrtt.localizertt.ui.imu.IMUViewModel
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations
import java.util.Calendar
import kotlin.math.sqrt

/**
 * Sensor Event Callback Listener
 *
 * For our use:
 * 1. Obtain the sensors that we are interested:
 *  - TYPE_ACCELEROMETER
 *  - TYPE_MAGNETIC_FIELD
 *  - TYPE_GYROSCOPE
 *  - TYPE_STEP_DETECTOR
 * 2. Save the sensors we are interested to CSV
 * 3. Also compute Orientation based on Accel, Mag and Gyro
 * 4. Init in MainActivity.
 *
 * Ref:
 *  1. https://developer.android.com/develop/sensors-and-location/sensors/sensors_motion
 *  2. https://developer.android.com/develop/sensors-and-location/sensors/sensors_position
 *      - https://dev.to/dhruvjoshi9/how-to-make-a-simple-compass-app-for-android-os-easy-step-by-step-guide-with-sample-code-13h4
 *
 * @author William Tan Kiat Wee 2025 May 15.
 */
class SensorEventCB(
    private val mainActivity: MainActivity,
    private val displayHandle: Display,
    private val imuViewModel: IMUViewModel
) : SensorEventListener {

    //  Store the current Accel and Mag data.
    private val accelerometerReading = FloatArray(3)
    private val magnetometerReading = FloatArray(3)

    //  Store the current Rotation and Orientation angles.
    private val rotationMatrix = FloatArray(9)
    private val orientationAngles = FloatArray(3)

    //  Current Step count
    private var stepsCounted: Long = 0

    override fun onSensorChanged(event: SensorEvent?) {

        //  Get current time
        val timestampData = Calendar.getInstance().timeInMillis

        if (event != null) {

            //  Based on the type, capture the data, update the viewmodel and save to CSV

            if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {

                //  Update to ViewModel so that the UI can update
                imuViewModel.setSensorAccelEvent(event)

                //  Array copy: Copy all data at once.
                System.arraycopy(event.values, 0, accelerometerReading, 0, accelerometerReading.size)

                //  Save to CSV
                CSVOperations().saveToCSVAccelrometer(mainActivity, timestampData, event.values[0], event.values[1], event.values[2])

                //  Under test
                //stepDetectorGemini(event)
            }

            if (event.sensor.type == Sensor.TYPE_MAGNETIC_FIELD) {

                //  Update to ViewModel so that the UI can update
                imuViewModel.setSensorMagEvent(event)

                //  Array copy: Copy all data at once.
                System.arraycopy(event.values, 0, magnetometerReading, 0, magnetometerReading.size)

                //  Save to CSV
                CSVOperations().saveToCSVMagneticField(mainActivity, timestampData, event.values[0], event.values[1], event.values[2])
            }

            if (event.sensor.type == Sensor.TYPE_GYROSCOPE) {

                //  Update to ViewModel so that the UI can update
                imuViewModel.setSensorGyroEvent(event)

                //  Save to CSV
                CSVOperations().saveToCSVGyroscope(mainActivity, timestampData, event.values[0], event.values[1], event.values[2])
            }

            if (event.sensor.type == Sensor.TYPE_STEP_DETECTOR) {

                stepsCounted++

                //  Update to ViewModel so that the UI can update
                imuViewModel.setSensorStepDetectedEvent(stepsCounted)

                //  Save Steps Count
                CSVOperations().saveToCSVStepCount(mainActivity, timestampData, stepsCounted)
            }

            //  ===================================
            //  Compute Orientation (Derived from sensor values)
            //  - Orientation Data consists of: Azimuth, Pitch and Roll of the device (phone)
            //  - Where Azimuth is the difference in relation to Magnetic North
            if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                val rotationMatrix = FloatArray(9)
                FloatArray(3)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)

                SensorManager.getOrientation(rotationMatrix, orientationAngles)

                // "orientationAngles" now has up-to-date information.
                imuViewModel.setComputedDataOrientation(orientationAngles)

                //  Save to CSV
                CSVOperations().saveToCSVOrientation(
                    mainActivity,
                    timestampData,
                    orientationAngles[0],
                    orientationAngles[1],
                    orientationAngles[2]
                )

            }

//            //  ===================================
//            //  Compute Orientation (Derived from sensor values)
//            //  - Orientation Data consists of: Azimuth, Pitch and Roll of the device (phone)
//            //  - Where Azimuth is the difference in relation to Magnetic North
//            if (accelerometerReading.isNotEmpty() && magnetometerReading.isNotEmpty()) {
//                // Update rotation matrix, which is needed to update orientation angles.
//                SensorManager.getRotationMatrix(
//                    rotationMatrix,
//                    null,
//                    accelerometerReading,
//                    magnetometerReading
//                )
//
//                //  Temp Disable for Hai
//                //  Following code is to remapped RotationMatrix based on how the user is holding the phone.
//                //  Ref: https://stackoverflow.com/questions/18782829/android-sensormanager-strange-how-to-remapcoordinatesystem
////                val axisX: Int
////                val axisY: Int
////                val isUpSideDown = accelerometerReading[2] < 0
////                //  Based on the Phone's orientation (Upright, flat, etc) set the axis for remapping the rotation matrix.
////                //  so that the Azimuth, Pitch and Roll display correctly based on how the user is holding the phone.
////                when (displayHandle.rotation) {
////                    Surface.ROTATION_0 -> {
////                        axisX = (if (isUpSideDown) SensorManager.AXIS_MINUS_X else SensorManager.AXIS_X)
////                        axisY =
////                            (if (abs(accelerometerReading[1]) > 6.0f) (if (isUpSideDown) SensorManager.AXIS_MINUS_Z else SensorManager.AXIS_Z) else (if (isUpSideDown) SensorManager.AXIS_MINUS_Y else SensorManager.AXIS_Y))
////                    }
////
////                    Surface.ROTATION_90 -> {
////                        axisX = (if (isUpSideDown) SensorManager.AXIS_MINUS_Y else SensorManager.AXIS_Y)
////                        axisY =
////                            (if (abs(accelerometerReading[0]) > 6.0f) (if (isUpSideDown) SensorManager.AXIS_Z else SensorManager.AXIS_MINUS_Z) else (if (isUpSideDown) SensorManager.AXIS_X else SensorManager.AXIS_MINUS_X))
////                    }
////
////                    Surface.ROTATION_180 -> {
////                        axisX = (if (isUpSideDown) SensorManager.AXIS_X else SensorManager.AXIS_MINUS_X)
////                        axisY =
////                            (if (abs(accelerometerReading[1]) > 6.0f) (if (isUpSideDown) SensorManager.AXIS_Z else SensorManager.AXIS_MINUS_Z) else (if (isUpSideDown) SensorManager.AXIS_Y else SensorManager.AXIS_MINUS_Y))
////                    }
////
////                    Surface.ROTATION_270 -> {
////                        axisX = (if (isUpSideDown) SensorManager.AXIS_Y else SensorManager.AXIS_MINUS_Y)
////                        axisY =
////                            (if (abs(accelerometerReading[0]) > 6.0f) (if (isUpSideDown) SensorManager.AXIS_MINUS_Z else SensorManager.AXIS_Z) else (if (isUpSideDown) SensorManager.AXIS_MINUS_X else SensorManager.AXIS_X))
////                    }
////
////                    else -> {
////                        axisX = (if (isUpSideDown) SensorManager.AXIS_MINUS_X else SensorManager.AXIS_X)
////                        axisY = (if (isUpSideDown) SensorManager.AXIS_MINUS_Y else SensorManager.AXIS_Y)
////                    }
////                }
////
////                //  Remapped the rotation matrix based on how the phone is held (e.g. upright or flat)
////                val remappedRotationMatrix = FloatArray(9)
////                SensorManager.remapCoordinateSystem(rotationMatrix, axisX, axisY, remappedRotationMatrix)
////
////                // "rotationMatrix" now has up-to-date information.
////                //SensorManager.getOrientation(rotationMatrix, orientationAngles)
////                SensorManager.getOrientation(remappedRotationMatrix, orientationAngles)
//
//                //  Rotation Matrix that is not adjusted to phone orientation. Level off with ground
//                //  To handle orientation, look at the commented code above. The rotation matrix needs to remapped based on phone orientation.
//                //  Remember to disable/remove this line if using the above code.
//                SensorManager.getOrientation(rotationMatrix, orientationAngles)
//
//                // "orientationAngles" now has up-to-date information.
//                imuViewModel.setComputedDataOrientation(orientationAngles)
//
//                //  Save to CSV
//                CSVOperations().saveToCSVOrientation(
//                    mainActivity,
//                    timestampData,
//                    orientationAngles[0],
//                    orientationAngles[1],
//                    orientationAngles[2]
//                )
//            }
        }
    }

    //  Under Test: Step Detection
    private val filterWindowSize = 10 // Adjust as needed
    private val magnitudeBuffer = FloatArray(filterWindowSize)
    private var bufferIndex = 0
    private var isBufferFull = false

    // --- Parameters for peak detection (adjust these carefully) ---
    private var lastPeakTimeNs: Long = 0
    private val minTimeBetweenStepsNs: Long = 300_000_000L // 250 ms, approx 4 steps/sec max
    private val stepThreshold = 9.89f // Example threshold, needs tuning! Lower for more sensitivity.

    /**
     * Under Test
     */
    fun stepDetectorGemini(event: SensorEvent) {


        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        // 1. Calculate magnitude
        val magnitude = sqrt(x * x + y * y + z * z)

        // 2. Simple Moving Average Filter
        magnitudeBuffer[bufferIndex] = magnitude
        bufferIndex = (bufferIndex + 1) % filterWindowSize
        if (bufferIndex == 0) {
            isBufferFull = true
        }

        if (isBufferFull) {
            val filteredMagnitude = magnitudeBuffer.average().toFloat()

            // 3. Basic Peak Detection and Debouncing
            val currentTimeNs = event.timestamp
            if (filteredMagnitude > stepThreshold && (currentTimeNs - lastPeakTimeNs > minTimeBetweenStepsNs)) {
                // Check if it's a local maximum (simplistic check)
                // A more robust peak detector would look at values before and after
                // For this example, we'll assume a peak if above threshold and time condition met
                // In a real app, you'd likely compare to previous filtered values.
                val previousIndex = (bufferIndex - 2 + filterWindowSize) % filterWindowSize
                if (filteredMagnitude > magnitudeBuffer[previousIndex]) { // Basic check against previous value
                    stepsCounted++
                    lastPeakTimeNs = currentTimeNs
                    Log.d("StepDetector", "Step detected! Count: $stepsCounted, Magnitude: $filteredMagnitude")

                    //  Update to ViewModel so that the UI can update
                    imuViewModel.setSensorStepDetectedEvent(stepsCounted)

                    //  Save Steps Count
                    //CSVOperations().saveToCSVStepCount(mainActivity, currentTimeNs, stepsCounted)
                }
            }
        }

    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        //  TODO("Not yet implemented")
    }
}