package sg.edu.smu.teamrtt.localizertt.callbacks

import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangingOpsV2
import java.util.TimerTask

/**
 * Timer Task for Invoking WiFi RTT Scan
 *
 * Scheduled by MainActivity to invoke RTT Scan on a scheduled loop. See MainActivity.
 *
 * @author William Tan. 2025 Mar 28.
 */
class WiFiTimerRTTScanTask(private val RTTScanOps: RTTRangingOpsV2) : TimerTask() {

    override fun run() {

        //  Invoke the WiFi RTT Scan.
        RTTScanOps.invokeRTTScan()
    }
}