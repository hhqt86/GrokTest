package sg.edu.smu.teamrtt.localizertt.ui.draw

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.ToggleButton
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentDrawBinding
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.model.stepDistanceCalc.StepData
import sg.edu.smu.teamrtt.localizertt.ui.imu.IMUViewModel
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * (Temporary Disable for Demo. Main Purpose is for Main Demo that is not tied to a fixed location.)
 * AP Draw Plot Fragment (DrawFrament)
 *
 * This UI Fragments has the following functionality:
 * 1. Plots the user position and AP location on the map.
 * 2. To do so, it performs 2 phase.
 * 3. Phase 1: Environment sensing=Together with the IMU, the user will walk around in the environment to sense the environment.
 * 4. Phase 2: AP Plot, after sensing, the AP will be plot in the environment.
 * 5. Unlike the DrawSB1Fragment, this fragment is NOT restricted to SOSS B1 and can be use anywhere.
 *
 * William: DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 13: Created by William Tan Kiat Wee.
 */
class DrawFragment : Fragment() {

    private val NO_OF_MARKERS = 70

    private var _binding: FragmentDrawBinding? = null

    private var thisContext: Context? = null

    //private val drawDetailsViewModel: DrawDetailsDataViewModel by activityViewModels()
    private val imuViewModel: IMUViewModel by activityViewModels()

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private var stepsCounted: Long = 0
    private val stepLength = 0.72
    private var xPos: Double = 0.0
    private var yPos: Double = 0.0
    private var orientationAngles = FloatArray(3)

    private var listOfTrackPOSCoordinatePoint: MutableList<CoordinatePoint> = mutableListOf()
    private var listOfAPCoordinatePoint: MutableList<CoordinatePoint> = mutableListOf()

    private var userCoordinatePoint: CoordinatePoint = CoordinatePoint(0.0, 0.0)
    private var listOfUserStepData: MutableList<StepData> = mutableListOf()

    private var currentStepData: StepData = StepData(-1, -1, Calendar.getInstance().timeInMillis)
    private val listOfDegreeChanged: MutableList<Double> = mutableListOf()
    private var movingFlag = false
    private var movingStampAzimuth: Int = 0

    //  Indicate if Sampling of Space is taking place. False indicates it is not taking place.
    private var flagSampleSpace = false

    private lateinit var textViewMessage: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        thisContext = this.context

        val drawViewModel =
            ViewModelProvider(this).get(DrawViewModel::class.java)

        _binding = FragmentDrawBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textDraw
        drawViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        textViewMessage = binding.textViewMessage

        val composeView = binding.composeView
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                PlotUser(NO_OF_MARKERS)
                CanvasDrawGrid(NO_OF_MARKERS)
            }
        }


//        val buttonClear: Button = binding.buttonClear
//        buttonClear.setOnClickListener() {
//            composeView.apply {
//                // Dispose of the Composition when the view's LifecycleOwner
//                // is destroyed
//                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
//                setContent {
//                    EmptyCanvasWilliam()
//                }
//            }
//        }

        val buttonSample: ToggleButton = binding.buttonSampleSpace
        buttonSample.setOnCheckedChangeListener { _, isChecked ->
            flagSampleSpace = isChecked
        }

        val buttonPlot: Button = binding.buttonPlotap
        buttonPlot.setOnClickListener {


        }

        val buttonClear: Button = binding.buttonClear
        buttonClear.setOnClickListener {

            currentStepData = StepData(-1, -1, Calendar.getInstance().timeInMillis)
            listOfUserStepData = mutableListOf()
            movingFlag = false
            movingStampAzimuth = 0
            stepsCounted = 0
            orientationAngles = FloatArray(3)

            flagSampleSpace = false
            buttonSample.isChecked = false

        }


//        //  Update from MainActivity WiFiProcessOps has computed the AP Locations
//        drawDetailsViewModel.currentStepData.observe(viewLifecycleOwner, Observer { value ->
//
//            //listOfAPCoordinatePoint = value
//            if(currentStepData.stepID==-1L) {
//                currentStepData=value
//                listOfUserStepData.add(value)
//
//                // Draw on screen
//                drawScreen(composeView)
//            }
//            else {
//
//                // rotating(value)
//
//                currentStepData=value
//
//                if(addToList(value)) {
//                    // Draw on screen
//                    drawScreen(composeView)
//                }
//            }
//        })


        imuViewModel.currentSensorStepDetectedEvent.observe(viewLifecycleOwner, Observer { value ->

            if (flagSampleSpace) {
                //Log.i("William", "Step")
                stepsCounted++

                initStepData(composeView)
            }

        })

        imuViewModel.currentComputedDataOrientation.observe(viewLifecycleOwner, Observer { value ->

            if (flagSampleSpace) {
                //Log.i("William", "Orientation")
                orientationAngles = value
            }

        })



        return root
    }

    private fun initStepData(composeView: ComposeView) {
        val timestampData = Calendar.getInstance().timeInMillis
        val azimuthInDegrees = (Math.toDegrees(orientationAngles[0].toDouble()) + 360).toFloat() % 360
        val cStepData = StepData(stepsCounted, azimuthInDegrees.roundToInt(), timestampData)

        if (currentStepData.stepID == -1L) {
            currentStepData = cStepData
            listOfUserStepData.add(cStepData)

            //  2025 Apr 4: Temporary code for saving to CSV for Hai to develop Algo: Can be removed once development is over.
            CSVOperations().saveStepAzimuthToCSV(thisContext!!, timestampData, stepsCounted, azimuthInDegrees, xPos, yPos)

            // Draw on screen
            drawScreen(composeView)
        } else {

            // rotating(value)

            currentStepData = cStepData

            if (addToList(cStepData)) {

                val azimuthRad = Math.toRadians(cStepData.azimuth.toDouble())
                val deltaX: Double = stepLength * sin(azimuthRad)
                val deltaY: Double = stepLength * cos(azimuthRad)

                xPos += deltaX
                yPos += deltaY

                //  2025 Apr 4: Temporary code for saving to CSV for Hai to develop Algo: Can be removed once development is over.
                CSVOperations().saveStepAzimuthToCSV(thisContext!!, timestampData, stepsCounted, azimuthInDegrees, xPos, yPos)

                // Draw on screen
                drawScreen(composeView)
            }
        }
    }

    private fun addToList(stepData: StepData): Boolean {

        for (eachStepData in listOfUserStepData) {

            if (stepData.stepID == eachStepData.stepID)
                return false
        }

        listOfUserStepData.add((stepData))

        return true
    }

    private fun rotating(value: StepData) {
        val degreeChanged = (value.azimuth - currentStepData.azimuth).toDouble()
        val sdegreeChanged = smoothCurrentValue(listOfDegreeChanged, degreeChanged, 10)

        if (abs(sdegreeChanged) > 1) {
            Log.i("William", "Theta: $degreeChanged")
            Log.i("William", "STheta: $sdegreeChanged")
            Log.i("William", "========")

            if (!movingFlag) {
                movingFlag = true
                movingStampAzimuth = currentStepData.azimuth
            }
        } else {
            if (movingFlag) {
                val finaldegreeChanged = (value.azimuth - movingStampAzimuth).toDouble() * -1
                Log.i("William", "value.azimuth: ${value.azimuth}")
                Log.i("William", "movingStampAzimuth: $movingStampAzimuth")
                Log.i("William", "*************************")

                //val newX = userCoordinatePoint.x * cos(finaldegreeChanged) - userCoordinatePoint.y * sin(finaldegreeChanged)
                //val newY = userCoordinatePoint.x * sin(finaldegreeChanged) + userCoordinatePoint.y * cos(finaldegreeChanged)

                val newX = userCoordinatePoint.x * cos(Math.toRadians(finaldegreeChanged)) - userCoordinatePoint.y * sin(Math.toRadians(finaldegreeChanged))
                val newY = userCoordinatePoint.x * sin(Math.toRadians(finaldegreeChanged)) + userCoordinatePoint.y * cos(Math.toRadians(finaldegreeChanged))

                userCoordinatePoint = CoordinatePoint(newX, newY)

                movingFlag = false

                Log.i("William", "Stop moving point.")
            }

        }
    }

    private fun smoothCurrentValue(values: MutableList<Double>, currentValue: Double, windowSize: Int): Double {
        if (windowSize <= 0) {
            throw IllegalArgumentException("Window size must be greater than zero")
        }

        // Remove the oldest value from the list if it exceeds the window size
        while (values.size > windowSize) {
            values.removeAt(0)
        }

        // Add the new value to the end of the list
        values.add(currentValue)

        // Calculate the sum of all values in the window
        var sumOfValuesInWindow = 0.0
        for (index in values.indices) {
            sumOfValuesInWindow += values[index]
        }

        return sumOfValuesInWindow / values.size.toDouble()
    }

    private fun DrawFragment.drawScreen(composeView: ComposeView) {
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                PlotUser(NO_OF_MARKERS)
                PlotUserSteps(NO_OF_MARKERS)
                CanvasDrawGrid(NO_OF_MARKERS)
            }
        }
    }


    @Composable
    fun PlotUser(numOfMakers: Int) {

        //val textMeasurer = rememberTextMeasurer()

        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            val interval = canvasWidth / numOfMakers

            if (userCoordinatePoint.x != 0.0 && userCoordinatePoint.y != 0.0) {

                //  Conversion
                val posXcanvas = userCoordinatePoint.x * interval
                val posYcanvas = userCoordinatePoint.y * interval

                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                if (actualPosX in 0.0..canvasHeight.toDouble() && actualPosY >= 0 && actualPosY <= canvasWidth) {

                    //Log.i("William", "Plotting User Location. X=${userCoordinatePoint.x}, Y=${userCoordinatePoint.y}")

                    drawCircle(
                        color = Color.Green,
                        radius = 7.dp.toPx(),
                        center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                    )

//                        drawText(
//                            textMeasurer = textMeasurer,
//                            text = eachCoordinatePoint.label,
//                            topLeft = Offset(actualPosX.toFloat() + 50F, actualPosY.toFloat() + 50F),
//                            style = TextStyle(
//                                color = Color.Yellow,
//                                fontSize = 17.sp,
//                                fontWeight = FontWeight.Bold,
//                                textDecoration = TextDecoration.Underline
//                            )
//
//                        )
                }
                //else {
                //    Log.i("William", "Not Plotting User Location. X=${userCoordinatePoint.x}, Y=${userCoordinatePoint.y}")
                //}
            }
        }
    }

    @Composable
    fun PlotUserSteps(numOfMakers: Int) {

        //val textMeasurer = rememberTextMeasurer()
        if (listOfUserStepData.size == 0)
            return

        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            val interval = canvasWidth / numOfMakers

            //  Sort by RSSI strength
            val sortedListOfUserStepData = listOfUserStepData.sortedBy { it.timestampMillis }

            var posX = 0.0
            var posY = 0.0


            for (eachStepData in sortedListOfUserStepData) {

                val azimuthRad = Math.toRadians(eachStepData.azimuth.toDouble())
                val deltaX: Double = stepLength * sin(azimuthRad)
                val deltaY: Double = stepLength * cos(azimuthRad)

                posX += deltaX
                posY += deltaY

                if (posX != 0.0 && posY != 0.0) {

                    //  Conversion
                    val posXcanvas = posX * interval
                    val posYcanvas = posY * interval

                    val actualPosX = widthMid + posXcanvas
                    val actualPosY = heightMid - posYcanvas

                    if (actualPosX in 0.0..canvasWidth.toDouble() && actualPosY >= 0 && actualPosY <= canvasHeight) {

                        drawCircle(
                            color = Color.Green,
                            radius = 7.dp.toPx(),
                            center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                        )
                    }
                    //else {
                    //    Log.i("William", "Outside Bound. Azimuth=${eachStepData.azimuth}, actualPosX=${actualPosX}, actualPosY=${actualPosY}. posX=${posX}, posY=${posY}, deltaX=${deltaX}, deltaY=${deltaY}")
                    //}
                }
            }
        }
    }


    @Composable
    fun PlotAP(numOfMakers: Int) {

        val textMeasurer = rememberTextMeasurer()
        // Log.i("William", "PlotAP")

        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            val interval = canvasWidth / numOfMakers

            for (eachCoordinatePoint in listOfAPCoordinatePoint) {

                //val returnedIndex=getIndexFromMac(eachCoordinatePoint.label)

                //  Conversion
                var posXcanvas = eachCoordinatePoint.x * interval
                var posYcanvas = eachCoordinatePoint.y * interval

                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                if (actualPosX in 0.0..canvasHeight.toDouble() && actualPosY >= 0 && actualPosY <= canvasWidth) {

                    drawCircle(
                        color = Color.Yellow,
                        radius = 7.dp.toPx(),
                        center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                    )

                    drawText(
                        textMeasurer = textMeasurer,
                        text = "none",
                        topLeft = Offset(actualPosX.toFloat(), actualPosY.toFloat() + 5F),
                        style = TextStyle(
                            color = Color.Black,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )

                    )
                }
                //else {
                //    Log.i("William", "Not Plotting Point. X=${eachCoordinatePoint.x}, Y=${eachCoordinatePoint.y}")
                //}
            }
        }
    }


    @Composable
    fun PlotTrackPOS(numOfMakers: Int) {

        val textMeasurer = rememberTextMeasurer()

        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            val interval = canvasWidth / numOfMakers

            for (eachCoordinatePoint in listOfTrackPOSCoordinatePoint) {
                //  Conversion
                val posXcanvas = eachCoordinatePoint.x * interval
                val posYcanvas = eachCoordinatePoint.y * interval

                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                drawCircle(
                    color = Color.Magenta,
                    radius = 7.dp.toPx(),
                    center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = eachCoordinatePoint.label,
                    topLeft = Offset(actualPosX.toFloat() - 30F, actualPosY.toFloat() + 25F),
                    style = TextStyle(
                        color = Color.Magenta,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        textDecoration = TextDecoration.Underline
                    )
                )
            }
        }
    }


    @Composable
    fun CanvasDrawGrid(numOfMakers: Int) {

        //  Tap: https://stackoverflow.com/questions/68363029/how-to-add-click-events-to-canvas-in-jetpack-compose
        //  https://medium.com/@fctdev/drawing-with-compose-836eadd1a308
        //  https://github.com/SebastienFCT/articles/blob/main/code-samples/DrawingCanvasExample/app/src/main/java/com/tectes/drawingcanvasexample/DrawingCanvas.kt
        // [START android_compose_graphics_canvas_diagonal_line]

        // Log.i("William", "CanvasDrawGrid")

        val textMeasurer = rememberTextMeasurer()

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { tapOffset ->
                        //capturePoint(tapOffset)
                    })
                }

        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            val interval = canvasWidth / numOfMakers


            //  Horizontal Mid Line Right-Left
            drawLine(
                start = Offset(x = canvasWidth, y = heightMid),
                end = Offset(x = 0f, y = heightMid),
                color = Color.Red
            )

            //  Vertical Mid Line Top-Down
            drawLine(
                start = Offset(x = widthMid, y = 0f),
                end = Offset(x = widthMid, y = canvasHeight),
                color = Color.Red
            )

            drawGridHorizontalMarkers(heightMid, widthMid, interval, canvasWidth)
            drawGridVerticalMarkers(heightMid, widthMid, interval, canvasHeight)

            //  Horizontal axis text in meters
            drawText(
                textMeasurer = textMeasurer,
                text = "${numOfMakers / 2}m",
                topLeft = Offset(canvasWidth - 80F, heightMid + 20F),
                style = TextStyle(
                    color = Color.Red,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = TextDecoration.Underline
                )

            )

            //  Vertical axis text in meters
            drawText(
                textMeasurer = textMeasurer,
                text = "${(heightMid / interval).toInt()}m",
                topLeft = Offset(widthMid + 20F, 1F),
                style = TextStyle(
                    color = Color.Red,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = TextDecoration.Underline
                )
            )
        }
    }


    private fun DrawScope.drawGridHorizontalMarkers(heightMid: Float, widthMid: Float, interval: Float, canvasWidth: Float) {

        //  Draw Horizontal Markers
        var posFlag = true
        var startPoint = widthMid
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = heightMid - 10),
                end = Offset(x = startPoint, y = heightMid + 10),
                color = Color.Red
            )
            startPoint -= interval
            if (startPoint <= 0)
                posFlag = false
        }

        posFlag = true
        startPoint = widthMid
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = heightMid - 10),
                end = Offset(x = startPoint, y = heightMid + 10),
                color = Color.Red
            )
            startPoint += interval
            if (startPoint >= canvasWidth)
                posFlag = false
        }
    }


    private fun DrawScope.drawGridVerticalMarkers(
        heightMid: Float,
        widthMid: Float,
        interval: Float,
        canvasHeight: Float
    ) {
        //  Draw Vertical Markers Reverse
        var posFlag = true
        var startPoint = heightMid
        while (posFlag) {
            drawLine(
                start = Offset(x = widthMid - 10, y = startPoint),
                end = Offset(x = widthMid + 10, y = startPoint),
                color = Color.Red
            )
            startPoint -= interval
            if (startPoint <= 0)
                posFlag = false
        }


        //  Draw Vertical Markers Forward
        posFlag = true
        startPoint = heightMid
        while (posFlag) {
            drawLine(
                start = Offset(x = widthMid - 10, y = startPoint),
                end = Offset(x = widthMid + 10, y = startPoint),
                color = Color.Red
            )
            startPoint += interval
            if (startPoint >= canvasHeight)
                posFlag = false
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}