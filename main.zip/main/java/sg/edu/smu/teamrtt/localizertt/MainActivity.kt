package sg.edu.smu.teamrtt.localizertt

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.net.wifi.rtt.WifiRttManager
import android.os.Bundle
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.view.Menu
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.material.navigation.NavigationView
import sg.edu.smu.teamrtt.localizertt.callbacks.LocationCB
import sg.edu.smu.teamrtt.localizertt.callbacks.LocationCBNGP
import sg.edu.smu.teamrtt.localizertt.callbacks.SensorEventCB
import sg.edu.smu.teamrtt.localizertt.callbacks.WiFiScanBCR
import sg.edu.smu.teamrtt.localizertt.callbacks.WiFiTimerAPScanTask
import sg.edu.smu.teamrtt.localizertt.callbacks.WiFiTimerRTTScanTask
import sg.edu.smu.teamrtt.localizertt.databinding.ActivityMainBinding
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.model.dataview.DrawSB1DetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.model.dataview.LocationDataViewModel
import sg.edu.smu.teamrtt.localizertt.model.dataview.RTTDetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.model.dataview.WiFiScanDataViewModel
import sg.edu.smu.teamrtt.localizertt.operations.coord.CoordOpsV2
import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTProcessOps
import sg.edu.smu.teamrtt.localizertt.operations.wifi.RTTRangingOpsV2
import sg.edu.smu.teamrtt.localizertt.ui.imu.IMUViewModel
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import sg.edu.smu.teamrtt.localizertt.util.CSVOperations
import sg.edu.smu.teamrtt.localizertt.util.toastMessages
import java.util.Calendar
import java.util.TimeZone
import java.util.Timer

/**
 * Data Store Handle
 *
 * Stores the app's data (e.g. Configurations, etc)
 * William: Using this instead of sharedpreferences since Google is going forward with this, high likely sharedpreferences will be deprecated in the future.
 * Ref: https://github.com/karim-eg/DataStore-Android-Example/blob/master/app/src/main/java/co/encept/datastore/DataStoreManager.kt
 */
val Context.dataStoreW: DataStore<Preferences> by preferencesDataStore(name = "appConfig")

/**
 * MainActivity
 *
 * Main Entry Point, does the following:
 * - Drawer-Navigation UI Handling (for switching between the views)
 * - Data gathering handles:
 *      - SensorManager
 *      - FusedLocationProviderClient
 *      - wifiManager
 *      - wifiRttManager
 * As well as it associated callbacks (BCR, etc)
 *
 * William: DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee.
 * Tracking:
 *  - 2025 Aug 28: Modify and add in stuff for DrawSB1Fragment: For Hai and Thu's Probabilistic AP's location approach Aug 2025. Retiring Leastsquare Algo May 2025.
 */
class MainActivity : AppCompatActivity() {

    private val TAG = this.javaClass.name

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    val timeZone: TimeZone = TimeZone.getTimeZone("Asia/Singapore")

    //  App Preferences Store
    private var appPrefStore = AppPrefStore(this)

    //  Wakelock
    private lateinit var wakeLock: PowerManager.WakeLock

    //private var TimeWindowForDataCapture = 20 * 1000L

    //  Sensors Stuff
    //  https://developer.android.com/develop/sensors-and-location/sensors/sensors_motion#sensors-motion-significant
    //  https://nhkarthick.medium.com/handling-sensors-in-android-kotlin-d728ddc20394
    //  William Notes: This is callback, callback registration/removal is onPause/onResume. (If you are adding or removing, please edit these function as well)
    private lateinit var mSensorManager: SensorManager
    private var mSensorAccel: Sensor? = null
    private var mSensorGyro: Sensor? = null
    private var mSensorMag: Sensor? = null
    private var mSensorStepDetector: Sensor? = null

    private var mSensorRotation: Sensor? = null
    private lateinit var callbackSensorEvent: SensorEventCB
    private var sensorCaptureFlag: Boolean = false
    private var orientationAngles = FloatArray(3)

    //  From DrawSB1Fragment Stuff
    //  Holds the user location in meters in SOSS B1.
    private var userLocationInSOSSB1CoordinatePointInMeters = CoordinatePoint(0.0, 0.0)

    //  The selected AP from AP list AP0 to AP4 (Hai's picked AP)
    //private var selectedAP = ""

    //  Holds the timestamp of user in SOSS B1 when the user touches the screen in DrawSB1Fragment
    private var userInSOSSB1CreationTimestamp = 0L

    //  Location Stuff Type 1 (Google Play Services)
    //  https://blog.stackademic.com/android-location-gps-explained-d9b04dac79cd?gi=9a387ea33cf3
    //  https://developers.google.com/codelabs/maps-platform/maps-platform-101-android#3
    //  https://developers.google.com/maps/documentation/android-sdk/examples/basic-map
    //  https://github.com/googlemaps-samples/android-samples/blob/main/tutorials/kotlin/MapWithMarker/app/build.gradle.kts
    private var location_client: FusedLocationProviderClient? = null

    //  Location Request
    val request = LocationRequest.Builder(
        /* Priority */ Priority.PRIORITY_HIGH_ACCURACY,
        /* intervalMillis */ 100
    ).build()


    //  Location Stuff Type 2 (Non Google Play Services)
    //  (Pure GPS Provider, no network assist. Only works if device have access to GPS signals AKA outside, may not work indoors)
    //  https://developer.android.com/reference/android/location/LocationManager
    //  https://medium.com/@kostovtd/location-without-google-services-a591352ed0ba
    //  https://medium.com/@psarakisnick/android-location-manager-with-kotlin-flows-082c992d1b31
    //  https://sachankapil.medium.com/latest-method-how-to-get-current-location-latitude-and-longitude-in-android-give-support-for-c5132474c864
    private lateinit var mLocationManager: LocationManager
    private lateinit var mLocationCBNGP: LocationCBNGP


    //  WiFi Handles
    //  https://developer.android.com/develop/connectivity/wifi/wifi-rtt#:~:text=Wi%2DFi%20RTT%20was%20introduced,store%20and%20retrieve%20this%20data.
    private val wifiManager: WifiManager get() = getSystemService(WIFI_SERVICE) as WifiManager
    private var wifiScanningFlag: Boolean = false
    private val wifiRttManager: WifiRttManager get() = getSystemService(WIFI_RTT_RANGING_SERVICE) as WifiRttManager


    //  William's View Models for communicating with Fragments
    //  Ref: https://developer.android.com/guide/fragments/communicate#:~:text=The%20Fragment%20library%20provides%20two,use%20the%20Fragment%20Result%20API.
    //  1. With GalleryFragment where GPS UI is located
    private val locationDataViewModel: LocationDataViewModel by viewModels()

    //  2. With Home Fragment where the Wifi Scanning UI is located
    private val wifiScanDataViewModel: WiFiScanDataViewModel by viewModels()

    //  3. With RTTDetails Fragment where details of RTT Scan details of selected AP
    private val rttDetailsViewModel: RTTDetailsDataViewModel by viewModels()

    //  4. With IMU Fragment where details of SensorEvent to be displayed
    private val imuViewModel: IMUViewModel by viewModels()

    //  5. With Draw SOSS B1 Fragment where the location is plotted
    private val drawSB1DetailsViewModel: DrawSB1DetailsDataViewModel by viewModels()

    //  6. With Draw Fragment where the location is plotted
    //private val drawDetailsViewModel: DrawDetailsDataViewModel by viewModels()

    //  Util Operations
    private lateinit var wifiRTTRangingOps: RTTRangingOpsV2
    private lateinit var wifiRTTProcessOps: RTTProcessOps

    //  Position Operations
    private lateinit var coordOps: CoordOpsV2

    //  BCRs
    private lateinit var bcrWiFiScan: WiFiScanBCR
    private lateinit var callbackLocation: LocationCB

    //  Timer Tasks
    private val TIMER_TASK_DELAY: Long = 3000
    private var timerAPScanPeriod: Long = 10 * 1000
    private var timerRTTScanPeriod: Long = 2 * 1000
    private var timeTasks = Timer()
    private lateinit var timerTaskWiFiRTTScan: WiFiTimerRTTScanTask
    private lateinit var timerTaskWiFiAPScan: WiFiTimerAPScanTask

    //  (Archived) Processed/Computed Items
    //private var listOfEstimatedAP: MutableList<CoordinatePoint> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appBarMain.toolbar)

        //  Setup wakelock
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MainActivity::NoSleepTag")

//        binding.appBarMain.fab.setOnClickListener { view ->
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null)
//                .setAnchorView(R.id.fab).show()
//        }

        val drawerLayout: DrawerLayout = binding.drawerLayout
        val navView: NavigationView = binding.navView
        val navController = findNavController(R.id.nav_host_fragment_content_main)

        // Passing each menu ID as a set of Ids because each menu should be considered as top level destinations.
//        appBarConfiguration = AppBarConfiguration(
//            setOf(
//                R.id.nav_home, R.id.nav_draw, R.id.nav_gallery, R.id.nav_imu, R.id.nav_slideshow
//            ), drawerLayout
//        )
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_imu, R.id.nav_slideshow
            ), drawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        //  Check Permission
        checkPermissionGiven()

        //  Location Handle (Google Play). Disabled as final app will not be using Google Play Services. Kept for testing.
        location_client = LocationServices.getFusedLocationProviderClient(this)

        //  Location Handle (Non-Google Play)
        mLocationManager = this.getSystemService(LOCATION_SERVICE) as LocationManager
        //val hasGps = mLocationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        //Log.i("William", "Non-Google Play Services. hasGps:${hasGps}")

        //  WiFi-RTT Check
        if (!this.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_RTT)) {

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Title")
            builder.setMessage("No WiFi-RTT Feature Available!")
            builder.setPositiveButton("OK") { dialog, which ->
                // handle OK button click
            }
            builder.setNegativeButton("Cancel") { dialog, which ->
                // handle Cancel button click
            }
            val dialog = builder.create()
            dialog.show()
        }

        //  Location Stuff
        //  Google-Play
        callbackLocation = LocationCB(this, locationDataViewModel)
        //  Non Google-Play
        mLocationCBNGP = LocationCBNGP(this, locationDataViewModel)

        //  Sensors Stuff
        //  https://developer.android.com/develop/sensors-and-location/sensors/sensors_motion#sensors-motion-significant
        //  https://github.com/kavinduchamiran/simpleSensorReader/blob/master/app/src/main/java/com/kavinduchamiran/sensorreader/MainActivity.kt
        mSensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        mSensorAccel = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        mSensorGyro = mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        mSensorMag = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        mSensorStepDetector = mSensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        mSensorRotation = mSensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        callbackSensorEvent = SensorEventCB(this, display, imuViewModel)

        //  Setup the RTT WiFi Scan and BCR
        wifiRTTRangingOps = RTTRangingOpsV2(
            this,
            wifiManager,
            wifiRttManager,
            wifiScanDataViewModel,
            rttDetailsViewModel
        )
        bcrWiFiScan = WiFiScanBCR(wifiRTTRangingOps)

        //  Set Hardcoded AP
        //selectedAP = appPrefStore.loadAPDefaultTest()
        //wifiRTTRangingOps.addToHardcodedAP(selectedAP, 1)

        //  Setup the RTT WiFi Processing/Research Module
        wifiRTTProcessOps = RTTProcessOps(appPrefStore.loadAPTrackingTime())

        //  Setup Position Processing Module
        coordOps = CoordOpsV2()

        //  Setup Timer Task
        timerTaskWiFiRTTScan = WiFiTimerRTTScanTask(wifiRTTRangingOps)
        timerTaskWiFiAPScan = WiFiTimerAPScanTask(this)

        //  Setup View Model Observation
        //  - https://developer.android.com/guide/fragments/communicate
        setupViewModelObservationCallbacks()
    }

    /**
     * Setup the ViewModel Observation
     *
     * These are callbacks when observing for value changes.
     *  - Value changes can be uni/bi-directional between MainActivity and its associated fragments.
     */
    private fun setupViewModelObservationCallbacks() {

        //  Observe Toggle button occurring in Home Fragment: This is to trigger the WiFi scan
        wifiScanDataViewModel.currentFlagStartScan.observe(this) { value ->

            //Log.i("William", "Triggered! wifiScanDataViewModel.currentFlagStartScan. Flag: $wifiScanningFlag")

            if (value) {

                if (!wifiScanningFlag) {
                    //  Start Wifi Scan
                    startWiFiScan()
                }
            } else {
                wifiScanningFlag = false

                unregisterReceiver(bcrWiFiScan)

                timeTasks.cancel()
                timeTasks = Timer()
                //Log.i("William", "Home Scan Stop!")
            }
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observe Toggle Button if the IMU sensors are toggle on/off in the IMU Fragment
        //  This triggers the sensors capturing.
        imuViewModel.currentFlagStartScan.observe(this) { value ->

            //Log.i("William", "imuViewModel.currentFlagStartScan Triggered!")
            if (value) {

                if (!sensorCaptureFlag) {
                    //  Start Sensor Listening
                    //  SENSOR_DELAY_NORMAL, SENSOR_DELAY_UI, SENSOR_DELAY_GAME, SENSOR_DELAY_FASTEST (Ascending order of fast-ness)
                    mSensorManager.registerListener(callbackSensorEvent, mSensorAccel, SensorManager.SENSOR_DELAY_UI)
                    mSensorManager.registerListener(callbackSensorEvent, mSensorGyro, SensorManager.SENSOR_DELAY_UI)
                    mSensorManager.registerListener(callbackSensorEvent, mSensorMag, SensorManager.SENSOR_DELAY_UI)
                    mSensorManager.registerListener(callbackSensorEvent, mSensorStepDetector, SensorManager.SENSOR_DELAY_UI)
                    mSensorManager.registerListener(callbackSensorEvent, mSensorRotation, SensorManager.SENSOR_DELAY_UI)

                    sensorCaptureFlag = true
                }

                //Log.i("William", "Sensor Capture Started!")
            } else {
                sensorCaptureFlag = false

                mSensorManager.unregisterListener(callbackSensorEvent)

                //Log.i("William", "Sensor Capture Stop!")
            }
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observes the IMU Step Sensor: Update the
        imuViewModel.currentSensorStepDetectedEvent.observe(this) { value ->

            //  Update step in Coord Ops
            coordOps.updateStepData(Calendar.getInstance().timeInMillis)

            //  (Deprecated: CoordOps already capture) Update step in WiFi Process Ops
            // wiFiRTTProcessOps.updateStepData(orientationAngles)
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observes the IMU Computed Orientation:  Update the Orientation angles in MainActivity.
        imuViewModel.currentComputedDataOrientation.observe(this) { value ->
            orientationAngles = value
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observe and Update the MainActivity's User Location from DrawSB1Fragment.
        //  User location in SOSS B1 for DrawSB1Fragment, user location capture and use for Hai's TrigoAlgo
        drawSB1DetailsViewModel.currentUserCoordPosPointInMeters.observe(this) { value ->

            //  Note this coordinate Point is in meters adjusted to Hai's SOSS B1 Map V2
            userLocationInSOSSB1CoordinatePointInMeters = value
            //Log.i("William", "coordinatePointInMeters: $userLocationInSOSSB1CoordinatePointInMeters")

            coordOps.captureCoordPoint(
                Calendar.getInstance().timeInMillis,
                CoordinatePoint(userLocationInSOSSB1CoordinatePointInMeters.x, userLocationInSOSSB1CoordinatePointInMeters.y)
            )
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observe and Update the MainActivity's SelectedAP from AP list AP0 to AP4 from DrawSB1Fragment.
        //drawSB1DetailsViewModel.currentSelectedAP.observe(this) { value ->
        //    selectedAP = value
        //}

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observe and Update the MainActivity's CreationTimestamp from DrawSB1Fragment.
        //  This is when the user touches the screen for starting point. The timestamp is capture on Touch.
        drawSB1DetailsViewModel.currentCreationTimestamp.observe(this) { value ->
            userInSOSSB1CreationTimestamp = value

            coordOps.captureCoordPoint(
                userInSOSSB1CreationTimestamp,
                CoordinatePoint(userLocationInSOSSB1CoordinatePointInMeters.x, userLocationInSOSSB1CoordinatePointInMeters.y))

            Log.i(TAG, "Creation CoordinatePoint= $userLocationInSOSSB1CoordinatePointInMeters")
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observe the (Update button) trigger flag: Once triggered, we estimated the AP Location
        //  Using Hai & Thu TrigoAlgo (Aug 2025)
        drawSB1DetailsViewModel.currentTriggerFlag.observe(this) { value ->

            if (value) {

                Log.i(TAG, "Button Triggered.")

                //val currTime = Calendar.getInstance(timeZone).time.time
                val currTime = Calendar.getInstance().timeInMillis

                //  Reset the trigger (if else condition has code, else default: disabled)
                //drawSB1DetailsViewModel.setTriggerFlag(false)

                //  We only want RTT Candidate BSSID
                val listOfCandidateBSSID = wifiRTTRangingOps.getRTTCandidatesBSSIDs()

                //  Iterate through the BSSID list to generate PointVal for each
                for (eachBSSID in listOfCandidateBSSID) {

                    //  Get this BSSID's Hashmap Timestamp-ListOfRangeResult
                    val hashMapTimestampToListOfRangeResultRelatedToThisBSSID = wifiRTTProcessOps.getCollectedRTTRangeResult(eachBSSID)
                    if (!hashMapTimestampToListOfRangeResultRelatedToThisBSSID.isEmpty()) {

                        //  Returns cumulative list of all points
                        val listOfAllPointVal = coordOps.thusPointValGeneratorCumulativePoints(
                            eachBSSID,
                            userInSOSSB1CreationTimestamp,
                            wifiRTTProcessOps.getCollectedRTTRangeResult(eachBSSID))

                        //  Write PointVal of BSSID to
                        if (!listOfAllPointVal.isEmpty() && listOfAllPointVal.size >= 2) {

                            //  Update the target Position
//                            val coordinatePoint = coordOps.directionGuidance(listOfAllPointVal.toMutableList())
//                            if (coordinatePoint != null)
//                                drawSB1DetailsViewModel.setTargetCoordPosPointInMeters(coordinatePoint)

                            // Save to CSV
                            CSVOperations().saveToCSVPointVal(this, "PointValOf$eachBSSID", currTime, listOfAllPointVal)
                        } else {
                            //  No computed PointVal: This is likely range did not occur when user stop walking, wait for a while to allow data to capture.
                            Log.e(TAG, "listOfAllPointVal is empty or not enough values.")
                            toastMessages(this, "Please wait for 1-2 seconds and tap on Update again!")
                        }
                    } else {
                        //  No scan/range data.
                        Log.e(TAG, "hashMapTimestampToListOfRangeResultRelatedToThisBSSID is empty")
                        toastMessages(this, "No Range Data for $eachBSSID. Please check if WiFi Scan is on.")
                    }
                }

                //  Update so that the Heatmap can be draw using the Mask
                val listOfListOfPointVal = coordOps.getAllBSSIDCumulativeListOfPointVal()
                drawSB1DetailsViewModel.setAllListOfPointVal(listOfListOfPointVal)
            }
        }

        //  Original
//        drawSB1DetailsViewModel.currentTriggerFlag.observe(this) { value ->
//
//            if (value) {
//
//                Log.i(TAG, "Button Triggered.")
//
//                //val currTime = Calendar.getInstance(timeZone).time.time
//                val currTime = Calendar.getInstance().timeInMillis
//
//                //  Reset the trigger (if else condition has code, else default: disabled)
//                //drawSB1DetailsViewModel.setTriggerFlag(false)
//
//                val scanResultsHashMap = RTTProcessOps.getCollectedRTTRangeResult()
//                if (!scanResultsHashMap.isEmpty()) {
//                    //  Returns cumulative list of all points
//                    val listOfAllPointVal = coordOps.thusPointValGeneratorCumulativePoints(
//                        selectedAP,
//                        userInSOSSB1CreationTimestamp,
//                        RTTProcessOps.getCollectedRTTRangeResult())
//
//                    //  Update the fragment if the list is not empty.
//                    if (!listOfAllPointVal.isEmpty() && listOfAllPointVal.size >= 2) {
//
//                        //  Update so that the Heatmap can be draw using the Mask
//                        drawSB1DetailsViewModel.setListOfPointVal(listOfAllPointVal.toMutableList())
//
//                        //  Update the target Position
//                        val coordinatePoint = coordOps.directionGuidance(listOfAllPointVal.toMutableList())
//                        if (coordinatePoint != null)
//                            drawSB1DetailsViewModel.setTargetCoordPosPointInMeters(coordinatePoint)
//
//                        // Save to CSV
//                        CSVOperations().saveToCSVPointVal(this, "UpdateButton", currTime, listOfAllPointVal)
//                    } else {
//                        //  No computed PointVal: This is likely range did not occur when user stop walking, wait for a while to allow data to capture.
//                        Log.e(TAG, "listOfAllPointVal is empty or not enough values.")
//                        toastMessages(this, "Please wait for 1-2 seconds and tap on Update again!")
//                    }
//                } else {
//                    //  No scan/range data.
//                    Log.e(TAG, "scanResultsHashMap is empty")
//                    toastMessages(this, "No Range Data. Please check if WiFi Scan is on and default AP (BSSID) is selected.")
//                }
//            }
//        }


        //  ============================================================================================================================================
        //  ============================================================================================================================================

        //  Observe and Update the MainActivity's WiFi RTT handle from any RTT Scan result
        //  Modify for Hai and Thu's Algo in Aug 2025.
        //  For Hai's Leastsquare Algo May 2025, see commented (Archived) code below.
        rttDetailsViewModel.currentRangingResult.observe(this) { value ->

            //  Timestamp
            val capturedTimestamp = Calendar.getInstance().timeInMillis

            //  Add the result to the collection of existing results held in wiFiRTTProcessOps
            wifiRTTProcessOps.addCapturedRTTRangeResult(capturedTimestamp, value)

            //  Similarly, at the same time instance, capture User Location and
            //  And add the coord to the collection of existing results held in coordOps.
            //  We are doing this, so that at any time instance a location is paired with RTT Scan result.
            coordOps.captureCoordPoint(
                capturedTimestamp,
                CoordinatePoint(userLocationInSOSSB1CoordinatePointInMeters.x, userLocationInSOSSB1CoordinatePointInMeters.y)
            )
        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

//        rttDetailsViewModel.currentRefTestAP.observe(this) { value ->
//
//            //  Set Hardcoded AP
//            selectedAP = value
//            wifiRTTRangingOps.addToHardcodedAP(selectedAP, 1)
//        }

        //  ============================================================================================================================================
        //  ============================================================================================================================================

        /*
         *  (Archived)
         *
         *  (Deprecated)
         *  (Previously use for APLocationConstantErrorLeastSquare)
         *
         *  Code archived, as Fragment is now use for Hai's TrigoAlgo. This older code is kept for reference.
         *
         * Based on the RTT Scan, update the Localization Inference (Research: Hai's Algo. May 2025)
         *  - Estimate the user location
         *  - Prerequisite: List of Estimated AP is not empty.
         */
        /* (Archived)
        rttDetailsViewModel.currentRangingResult.observe(this) { value ->

            //  Update the AP Tracking
            wiFiRTTProcessOps.updateRTTRangeResult(Calendar.getInstance().timeInMillis, value)

            //  If List of estimated Access Point is generated, we can compute user location and update the draw UI.
            //  If not, wait until the list is computed
            if (listOfEstimatedAP.isNotEmpty()) {
                //Log.i("William", "User Location Triggered")
                //val userCoord = wiFiRTTProcessOps.getUserLocation(listOfEstimatedAP, TimeWindowForDataCapture)
                val userCoord = wiFiRTTProcessOps.getUserLocation(listOfEstimatedAP, 4 * 1000L)
                if (userCoord.x != 99999.99 && userCoord.y != 99999.99) {
                    drawSB1DetailsViewModel.setUserCoordPosPoint(userCoord)
                }
            }
        }
        */
    }

    /**
     * Start WiFi Scan for available Access Points.
     *
     * Triggered by
     * 1. Initial scan toggle in Home Fragment
     * 2. the Timer task: WiFiTimerAPScanTask (so that we can increase the scan frequency, this require developer mode option to be turn on)
     *
     * Note scan result is processed via callback
     */
    fun startWiFiScan() {
        val intentFilter = IntentFilter()
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        registerReceiver(bcrWiFiScan, intentFilter)

        val success = wifiManager.startScan()
        if (!success) {
            // scan failure handling
            Log.e(TAG, "startWiFiScan() Failed.")
            wifiScanningFlag = false
        } else {

            if (!wifiScanningFlag) {

                timeTasks.cancel()
                timeTasks = Timer()

                //  Setup Timer Task
                timerTaskWiFiRTTScan = WiFiTimerRTTScanTask(wifiRTTRangingOps)
                timerTaskWiFiAPScan = WiFiTimerAPScanTask(this)

                //  Load AP Scan time
                timerAPScanPeriod = appPrefStore.loadAPScanTime()
                timeTasks.schedule(timerTaskWiFiAPScan, TIMER_TASK_DELAY, timerAPScanPeriod)

                //  Load the RTT Scan time (with a delay)
                timerRTTScanPeriod = appPrefStore.loadRTTScanTime()
                timeTasks.schedule(timerTaskWiFiRTTScan, TIMER_TASK_DELAY, timerRTTScanPeriod)
            }

            wifiScanningFlag = true
            //Log.i("William", "Home Scan requested! Flag: $wifiScanningFlag")
        }
    }


    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    //  ============
    //  Permissions
    //  TODO: William: Fill in all the proper code, for now, just do minimum to get the code working first.
    //  https://developer.android.com/training/permissions/requesting
    //  https://medium.com/codex/android-runtime-permissions-using-registerforactivityresult-68c4eb3c0b61
    //  https://github.com/AndroidCodility/Multiple-Permissions/blob/master/app/src/main/java/com/codility/mpermissions/MainActivity.kt
    //  https://gist.github.com/SurajBahadur/671521c379502495d9ef0f6f1dc21724
    //   Manifest.permission.ACCESS_BACKGROUND_LOCATION, Manifest.permission.WRITE_EXTERNAL_STORAGE,
    private var permissionsRequired = arrayOf(
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_WIFI_STATE,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission
            .ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.NEARBY_WIFI_DEVICES,
        Manifest.permission.ACTIVITY_RECOGNITION
    )
//    private var permissionsRequired = arrayOf(Manifest.permission.ACCESS_WIFI_STATE, Manifest.permission.ACCESS_FINE_LOCATION)

    private val requestMultiplePermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
            permissions.entries.forEach {
                Log.e("DEBUG", "${it.key} = ${it.value}")
            }
        }

    private fun checkPermissionGiven() {

        requestLocationPermission()

//        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_WIFI_STATE) == PackageManager.PERMISSION_GRANTED
//        ) {
//            //permission granted
//            //getCurrentSsid(this)
//        }
////        else if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
////
////        }
//        else
//            requestLocationPermission()
    }

    private fun requestLocationPermission() {

        if (shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_FINE_LOCATION)) {
//            layout.showSnackbar(
//                R.string.location_access_required,
//                Snackbar.LENGTH_INDEFINITE,
//                R.string.ok
//            ) {
//                launchMultiPermission()
//            }
            launchMultiPermission()
        } else {
            // You can directly ask for the permission.
            launchMultiPermission()
        }
    }

    private fun launchMultiPermission() {
        requestMultiplePermissions.launch(permissionsRequired)
    }

    /**
     * Restore any pause/stop collection when App comes back to foreground.
     */
    override fun onStart() {
        super.onStart()

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }

        //  Google Play Services Location
        location_client?.requestLocationUpdates(
            request,
            callbackLocation,
            Looper.getMainLooper(),
        )

        //  Non Google Play Services Location
        mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 0F, mLocationCBNGP)

        //        Register the sensor on resume of the activity
        //mSensorManager.registerListener(this, mSensors, SensorManager.SENSOR_DELAY_NORMAL)

        if (wifiScanningFlag) {
            // unregisterReceiver(bcrWiFiScan)
            timeTasks.cancel()
            timeTasks = Timer()

            //  Setup Timer Task
            timerTaskWiFiRTTScan = WiFiTimerRTTScanTask(wifiRTTRangingOps)
            timerTaskWiFiAPScan = WiFiTimerAPScanTask(this)

            //  Start Wifi Scan
            val intentFilter = IntentFilter()
            intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            registerReceiver(bcrWiFiScan, intentFilter)

            timerRTTScanPeriod = appPrefStore.loadRTTScanTime()
            timeTasks.schedule(timerTaskWiFiRTTScan, TIMER_TASK_DELAY, timerRTTScanPeriod)

            //  Load AP Scan time
            timerAPScanPeriod = appPrefStore.loadAPScanTime()
            timeTasks.schedule(timerTaskWiFiAPScan, TIMER_TASK_DELAY, timerAPScanPeriod)
        }
    }

    /**
     * Stop/Pause any collection when App goes into background.
     */
    override fun onStop() {
        super.onStop()

        //  Google Play Services Location
        location_client?.removeLocationUpdates(callbackLocation)

        //  Non Google Play Services Location
        mLocationManager.removeUpdates(mLocationCBNGP)

        //  Unregister the sensor onPause else it will be active even if the activity is closed
        //mSensorManager.unregisterListener(this)

        if (wifiScanningFlag) {
            unregisterReceiver(bcrWiFiScan)
            timeTasks.cancel()
            timeTasks = Timer()
        }
    }


    override fun onResume() {
        super.onResume()

        //  Setup wakelock
        wakeLock.acquire(10 * 60 * 1000L /*10 minutes*/)

        if (sensorCaptureFlag) {
            // Register the sensor on resume of the activity
            mSensorManager.registerListener(
                callbackSensorEvent,
                mSensorAccel,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }

//        if (wifiScanningFlag) {
//            //  Start Wifi Scan
//            val intentFilter = IntentFilter()
//            intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
//            this.registerReceiver(bcrWiFiScan, intentFilter)
//        }

    }

    override fun onPause() {
        super.onPause()

        //  Release wakelock
        wakeLock.release()

        //  Resume
        if (sensorCaptureFlag) {
            // Unregister the sensor onPause else it will be active even if the activity is closed
            mSensorManager.unregisterListener(callbackSensorEvent)
        }

//        if (wifiScanningFlag) {
//            this.unregisterReceiver(bcrWiFiScan)
//            Log.i("William", "Home Scan Stop!")
//        }
    }
}