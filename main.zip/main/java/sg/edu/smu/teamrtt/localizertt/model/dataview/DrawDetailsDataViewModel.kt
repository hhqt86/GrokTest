package sg.edu.smu.teamrtt.localizertt.model.dataview

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import sg.edu.smu.teamrtt.localizertt.model.stepDistanceCalc.StepData

class DrawDetailsDataViewModel : ViewModel() {

    private var stepData = MutableLiveData<StepData>()
    val currentStepData: LiveData<StepData> get() = stepData

    fun setStepData(sData: StepData) {
        stepData.value = sData
    }

    //  ================================================================


}