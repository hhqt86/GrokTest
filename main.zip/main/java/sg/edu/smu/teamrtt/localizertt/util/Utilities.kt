package sg.edu.smu.teamrtt.localizertt.util

import android.content.Context
import android.widget.Toast

//class Utilieies {
//}

fun toastMessages(thisContext: Context?, message: String) {
    val duration = Toast.LENGTH_SHORT

    val toast = Toast.makeText(thisContext, message, duration) // in Activity
    toast.show()
}

//  Dialog Box
//    fun createDialogBox() {
//
//        val builder = AlertDialog.Builder(this.thisContext)
//        builder.setMessage("Done! Move to next position!")
//            .setPositiveButton("Close") { dialog, id ->
//                // START THE GAME!
//                dialog.cancel()
//            }
//
//        builder.create().show()
//    }