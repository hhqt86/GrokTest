package sg.edu.smu.teamrtt.localizertt.model.stepDistanceCalc;

/**
 * Step Data Class
 * <p>
 * This originated from Hai's Algo.
 * This class does the following:
 * 1. Tracks each step's data.
 * 2. This includes the step's azimuth, timestamp and each step's counter.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 27: Created by William Tan Kiat Wee.
 */
public class StepData {

    public long stepID;
    public int azimuth;
    public long timestampMillis;
    String timestamp;

    public StepData(long stepID, int azimuth, String timestamp) {
        this.stepID = stepID;
        this.azimuth = azimuth;
        this.timestamp = timestamp;
        this.timestampMillis = Long.parseLong(timestamp); // Assuming timestamp is in milliseconds
    }

    public StepData(long stepID, int azimuth, long timestamp) {
        this.stepID = stepID;
        this.azimuth = azimuth;
        this.timestamp = Long.toString(timestamp);
        this.timestampMillis = timestamp; // Assuming timestamp is in milliseconds
    }

    public StepData(int azimuth, String timestamp) {
        this.stepID = -1;
        this.azimuth = azimuth;
        this.timestamp = timestamp;
        this.timestampMillis = Long.parseLong(timestamp); // Assuming timestamp is in milliseconds
    }

    public StepData(int azimuth, long timestamp) {
        this.stepID = -1;
        this.azimuth = azimuth;
        this.timestamp = Long.toString(timestamp);
        this.timestampMillis = timestamp; // Assuming timestamp is in milliseconds
    }

    @Override
    public String toString() {
        return "StepData{" +
                "azimuth=" + azimuth +
                ", stepID=" + stepID +
                ", timestampMillis=" + timestampMillis +
                ", timestamp='" + timestamp + '\'' +
                '}';
    }
}
