package sg.edu.smu.teamrtt.localizertt.ui.drawSB1

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import sg.edu.smu.teamrtt.localizertt.R
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentDrawSb1Binding
import sg.edu.smu.teamrtt.localizertt.model.cartesian.CoordinatePoint
import sg.edu.smu.teamrtt.localizertt.model.dataview.DrawSB1DetailsDataViewModel
import sg.edu.smu.teamrtt.localizertt.util.AppPrefStore
import java.util.Calendar

/**
 * SOSS B1 User AP Draw Plot Fragment (DrawSB1Frament)
 *
 * Hai's Constant Erro LeastSquare Algo Fragment Version (used in period of May 2025)
 *
 * This UI Fragments has the following functionality:
 * 1. Renders the SOSS B1 Map on screen.
 * 2. Marks and captures the user position on screen based on where the user is when the user taps on the map.
 * 3. Renders the AP Location based on Hai's Constant Erro LeastSquare Algo.
 * 4. This requires the WiFI RTT Scanning/Capturing be running in the background.
 *
 * William: DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 13: Created by William Tan Kiat Wee.
 */
class DrawSB1FragmentOld1 : Fragment() {

    //  Hardcoded AP MAC For Testing Only. (To be remove in Production)
    //  First 5Hex String out of 6 in MAC Address.
    private val apMACIndexMap = mapOf(
        "b8:3a:5a:df:f5" to 1,
        "1c:28:af:41:7e" to 2,
        "1c:28:af:41:df" to 3,
        "b8:3a:5a:e0:68" to 4,
        "1c:28:af:41:78" to 5,
        "1c:28:af:41:89" to 6,
        "1c:28:af:41:b8" to 7,
        "1c:28:af:41:90" to 8,
        "1c:28:af:41:46" to 9,
        "1c:28:af:41:4b" to 10,
        "1c:28:af:41:97" to 11
    )

    /*
    Grid 465px - 10m

    1px length
    10/465=0.0215

    1573*0.0215=33.82 meters

    immage
    1573x2030
    */
    private val GRID10MPX = 465
    //private val ACTUAL_LENGTH_OF_SOSS_B1 = 33.82

    private val NO_OF_MARKERS = 40

    //    private var _binding: FragmentDrawBinding? = null
    private var _binding: FragmentDrawSb1Binding? = null

    private var thisContext: Context? = null

    private val drawDetailsViewModel: DrawSB1DetailsDataViewModel by activityViewModels()

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private var gCanvasWidth = 0.0f
    private var gCanvasHeight = 0.0f
    private var gScaledWidth = 0.0f
    private var gScaledHeight = 0.0f
    private var oneMeterXAxisInPx = 0.0f
    private var oneMeterYAxisInPx = 0.0f
    private var apPOSCounter = 0

    //  Measurement Countdown
    private var flagMeasuringCountDown = false
    private var captureTimeWindow = 20 * 1000L

    private var listOfTrackPOSCoordinatePoint: MutableList<CoordinatePoint> = mutableListOf()
    private var listOfAPCoordinatePoint: MutableList<CoordinatePoint> = mutableListOf()
    private var userCoordinatePoint: CoordinatePoint = CoordinatePoint(0.0, 0.0)

    private lateinit var textViewMessage: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        thisContext = this.context

        captureTimeWindow = thisContext?.let { AppPrefStore(it).loadCaptureTime() }!!

        val drawViewModel = ViewModelProvider(this).get(DrawSB1ViewModel::class.java)

        _binding = FragmentDrawSb1Binding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textDraw
        drawViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        //textViewMessage = binding.textViewMessage

        // Log.i("William", "Draw onCreateView")

        val composeView = binding.composeView
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                DrawMap()
                CanvasDrawGrid(NO_OF_MARKERS)
            }
        }

        val buttonClear: Button = binding.buttonMark
        buttonClear.setOnClickListener {

        }

//        val buttonClear: Button = binding.buttonClear
//        buttonClear.setOnClickListener() {
//            composeView.apply {
//                // Dispose of the Composition when the view's LifecycleOwner
//                // is destroyed
//                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
//                setContent {
//                    EmptyCanvasWilliam()
//                }
//            }
//        }

        val buttonPlot: Button = binding.buttonUpdate
        buttonPlot.setOnClickListener {

            drawDetailsViewModel.setTriggerFlag(true)
//            composeView.apply {
//                // Dispose of the Composition when the view's LifecycleOwner
//                // is destroyed
//                setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
//                setContent {
//                    CanvasDrawGrid(50)
//                    PlotAPOrg()
//                }
//            }
        }

        //  Update from MainActivity WiFiProcessOps has computed the AP Locations
        drawDetailsViewModel.currentCoordAPPosList.observe(viewLifecycleOwner, Observer { value ->

            listOfAPCoordinatePoint = value

            // Draw on screen
            drawScreen(composeView)
        })

        //  Update from MainActivity WiFiProcessOps has computed the user location
        drawDetailsViewModel.currentUserCoordPosPointInMeters.observe(viewLifecycleOwner, Observer { value ->

            userCoordinatePoint = value

            // Log.i("William", "Drawing User Location...")

            // Draw on screen
            drawScreen(composeView)
        })


        //  Update from MainActivity WiFiProcessOps has computed the user location
        drawDetailsViewModel.currentCoordPosList.observe(viewLifecycleOwner, Observer { value ->

            // Draw on screen
            drawScreen(composeView)
        })


        return root
    }

    private fun addToCoordList(coordinatePoint: CoordinatePoint, composeView: ComposeView) {

        listOfTrackPOSCoordinatePoint.add(coordinatePoint)

        // Draw on screen
        drawScreen(composeView)

        // Update to view Model
        drawDetailsViewModel.setCoordPosList(listOfTrackPOSCoordinatePoint)
    }


    private fun addToCoordListV2(coordinatePoint: CoordinatePoint) {

        listOfTrackPOSCoordinatePoint.add(coordinatePoint)

        // Update to view Model
        drawDetailsViewModel.setCoordPosList(listOfTrackPOSCoordinatePoint)
    }

    /**
     * Draw or Re-Draw the Screen during any update.
     *
     * This is called from the view models during any data update.
     * In which, the whole screen is refreshed and data is redrawn.
     * These includes the map, tracked position, any AP plotted, etc.
     */
    private fun DrawSB1FragmentOld1.drawScreen(composeView: ComposeView) {
        composeView.apply {
            // Dispose of the Composition when the view's LifecycleOwner
            // is destroyed
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent {
                DrawMap()
                PlotTrackPOS(NO_OF_MARKERS)
                PlotAP(NO_OF_MARKERS)
                PlotUser(NO_OF_MARKERS)
                CanvasDrawGrid(NO_OF_MARKERS)
            }
        }
    }

    /**
     * Plot User on the map
     */
    @Composable
    fun PlotUser(numOfMakers: Int) {

        //val textMeasurer = rememberTextMeasurer()

        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            //  Get the midpoint of the canvas
            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            //  Calculate the intervals of the markers based on the canvas size
            //  Note! Different phone has different canvas size.
            val interval = canvasWidth / numOfMakers

            //  If user point is available
            if (userCoordinatePoint.x != 0.0 && userCoordinatePoint.y != 0.0) {

                //  Conversion from the calculated x,y position and convert it to the canvas's x,y position.
                //  Note! Again we are doing this because different phone has different canvas size.
                val posXcanvas = userCoordinatePoint.x * interval
                val posYcanvas = userCoordinatePoint.y * interval

                //  Since we are basing 0,0 coordinate in middle, we have to adjust the position of the user's x,y
                //  e.g. if we are moving from 0,0 in the middle towards the top of the screen in y-axis, we are actually, decreasing in y-axis in the canvas coordinate.
                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                //  The actual the draw user on canvas by represented by circle in green.
                if (actualPosX in 0.0..canvasHeight.toDouble() && actualPosY >= 0 && actualPosY <= canvasWidth) {

                    //Log.i("William", "Plotting User Location. X=${userCoordinatePoint.x}, Y=${userCoordinatePoint.y}")

                    drawCircle(
                        color = Color.Green,
                        radius = 7.dp.toPx(),
                        center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                    )

                    // drawText(
                    //    textMeasurer = textMeasurer,
                    //    text = eachCoordinatePoint.label,
                    //    topLeft = Offset(actualPosX.toFloat() + 50F, actualPosY.toFloat() + 50F),
                    //    style = TextStyle(
                    //        color = Color.Yellow,
                    //        fontSize = 17.sp,
                    //        fontWeight = FontWeight.Bold,
                    //        textDecoration = TextDecoration.Underline
                    //    )
                    // )
                }
                //else {
                //    Log.i("William", "Not Plotting User Location. X=${userCoordinatePoint.x}, Y=${userCoordinatePoint.y}")
                //}
            }
        }
    }

    /**
     * Plot AP on the map
     */
    @Composable
    fun PlotAP(numOfMakers: Int) {

        //  Use to plot text
        val textMeasurer = rememberTextMeasurer()

        //  Plot the list of AP in the store(listOfAPCoordinatePoint)
        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            // val interval = canvasWidth / numOfMakers

            //  Iterate thru each Point and plot it.
            for (eachCoordinatePoint in listOfAPCoordinatePoint) {

                //  Get the index of each Point
                val returnedIndex = getIndexFromMac(eachCoordinatePoint.label)

                //  Conversion
                val posXcanvas = eachCoordinatePoint.x * oneMeterXAxisInPx
                val posYcanvas = eachCoordinatePoint.y * oneMeterYAxisInPx
                // var posXcanvas = eachCoordinatePoint.x * interval
                // var posYcanvas = eachCoordinatePoint.y * interval

                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                //  Check if point is within the Canvas
                if (actualPosX in 0.0..canvasHeight.toDouble() && actualPosY >= 0 && actualPosY <= canvasWidth) {

                    //  Draw Circle
                    drawCircle(
                        color = Color.Yellow,
                        radius = 7.dp.toPx(),
                        center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                    )

                    //  Draw Text
                    drawText(
                        textMeasurer = textMeasurer,
                        text = "$returnedIndex",
                        topLeft = Offset(actualPosX.toFloat(), actualPosY.toFloat() + 5F),
                        style = TextStyle(
                            color = Color.Black,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )
                    )
                }
                //else {
                //    Log.i("William", "Not Plotting Point. X=${eachCoordinatePoint.x}, Y=${eachCoordinatePoint.y}")
                //}
            }
        }
    }

    /**
     * Plot the User tracked positions
     */
    @Composable
    fun PlotTrackPOS(numOfMakers: Int) {

        //  Use to plot text
        val textMeasurer = rememberTextMeasurer()

        Canvas(modifier = Modifier.fillMaxSize()) {

            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            // val interval = canvasWidth / numOfMakers

            for (eachCoordinatePoint in listOfTrackPOSCoordinatePoint) {
                //  Conversion
                val posXcanvas = eachCoordinatePoint.x * oneMeterXAxisInPx
                val posYcanvas = eachCoordinatePoint.y * oneMeterXAxisInPx

                val actualPosX = widthMid + posXcanvas
                val actualPosY = heightMid - posYcanvas

                drawCircle(
                    color = Color.Magenta,
                    radius = 7.dp.toPx(),
                    center = Offset(actualPosX.toFloat(), actualPosY.toFloat()),
                )

                drawText(
                    textMeasurer = textMeasurer,
                    text = eachCoordinatePoint.label,
                    topLeft = Offset(actualPosX.toFloat() - 30F, actualPosY.toFloat() + 25F),
                    style = TextStyle(
                        color = Color.Magenta,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        textDecoration = TextDecoration.Underline
                    )
                )
            }
        }
    }

    @Composable
    fun DrawMap() {

        // Log.i("William", "DrawMap")

        val mapSOSSB1 = ImageBitmap.imageResource(id = R.drawable.soss_b1)

        //  https://stackoverflow.com/questions/77299943/draw-image-with-fixed-height-and-width-jetpack-compose-canvas-using-drawimage
        val imageAspectRatio = mapSOSSB1.width.toFloat() / mapSOSSB1.height

        Canvas(
            modifier = Modifier
                .fillMaxSize(), onDraw = {
                val canvasWidth = size.width
                val canvasHeight = size.height

                gCanvasWidth = size.width
                gCanvasHeight = size.height

                setupMapParams(canvasWidth, canvasHeight, mapSOSSB1.width, mapSOSSB1.height)

                var scaledWidth = canvasWidth
                var scaledHeight = canvasWidth / imageAspectRatio

                if (scaledHeight > canvasHeight) {
                    scaledHeight = canvasHeight
                    scaledWidth = scaledHeight * imageAspectRatio
                }

                val offsetX = ((size.width - scaledWidth) / 2).toInt()
                val offsetY = ((size.height - scaledHeight) / 2).toInt()

                drawImage(
                    image = mapSOSSB1,
                    dstSize = IntSize(
                        width = scaledWidth.toInt(),
                        height = scaledHeight.toInt()
                    ),
                    dstOffset = IntOffset(x = offsetX, y = offsetY)
                )
            })
    }


    private fun setupMapParams(canvasWidth: Float, canvasHeight: Float, mapWidth: Int, mapHeight: Int) {

        val imageAspectRatio = mapWidth.toFloat() / mapHeight

        var scaledWidth = canvasWidth
        var scaledHeight = canvasWidth / imageAspectRatio

        if (scaledHeight > canvasHeight) {
            scaledHeight = canvasHeight
            scaledWidth = scaledHeight * imageAspectRatio
        }

        gScaledWidth = scaledWidth
        gScaledHeight = scaledHeight

        //  GRID10MPX

        //  MapWidth - scaledWidth
        //  1 - scaledWidth/MapWidth
        //  GRID10MPX - (scaledWidth/MapWidth) * GRID10MPX
        var adjustedGRID10MPX = (scaledWidth / mapWidth) * GRID10MPX
        oneMeterXAxisInPx = (adjustedGRID10MPX / 10)

        adjustedGRID10MPX = (scaledHeight / mapHeight) * GRID10MPX
        oneMeterYAxisInPx = (adjustedGRID10MPX / 10)

        //        Log.i("William", "=======")
        //        Log.i("William", "mapWidth $mapWidth")
        //        Log.i("William", "mapHeight $mapHeight")
        //        Log.i("William", "=======")
        //        Log.i("William", "canvasWidth $canvasWidth")
        //        Log.i("William", "canvasHeight $canvasHeight")
        //        Log.i("William", "=======")
        //        Log.i("William", "GRID10MPX $GRID10MPX")
        //        Log.i("William", "adjustedGRID10MPX $adjustedGRID10MPX")
        //        Log.i("William", "oneMeterXAxisInPx $oneMeterXAxisInPx")
        //        Log.i("William", "oneMeterYAxisInPx $oneMeterYAxisInPx")
        //        Log.i("William", "=======")
    }


    @Composable
    fun CanvasDrawGrid(numOfMakers: Int) {

        //  Tap: https://stackoverflow.com/questions/68363029/how-to-add-click-events-to-canvas-in-jetpack-compose
        //  https://medium.com/@fctdev/drawing-with-compose-836eadd1a308
        //  https://github.com/SebastienFCT/articles/blob/main/code-samples/DrawingCanvasExample/app/src/main/java/com/tectes/drawingcanvasexample/DrawingCanvas.kt
        // [START android_compose_graphics_canvas_diagonal_line]

        // Log.i("William", "CanvasDrawGrid")

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { tapOffset ->
                        capturePoint(tapOffset)
                    })
                }

        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            val widthMid = canvasWidth / 2
            val heightMid = canvasHeight / 2

            // val interval = canvasWidth / numOfMakers

            //  Horizontal Mid Line Right-Left
            drawLine(
                start = Offset(x = canvasWidth, y = heightMid),
                end = Offset(x = 0f, y = heightMid),
                color = Color.Red
            )

            //  Vertical Mid Line Top-Down
            drawLine(
                start = Offset(x = widthMid, y = 0f),
                end = Offset(x = widthMid, y = canvasHeight),
                color = Color.Red
            )

            drawGridHorizontalMarkers(heightMid, widthMid, oneMeterXAxisInPx, canvasWidth)
            drawGridVerticalMarkers(heightMid, widthMid, oneMeterYAxisInPx, canvasHeight)
        }
    }


    private fun DrawScope.drawGridHorizontalMarkers(heightMid: Float, widthMid: Float, interval: Float, canvasWidth: Float) {

        //  Draw Horizontal Markers
        var posFlag = true
        var startPoint = widthMid
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = heightMid - 10),
                end = Offset(x = startPoint, y = heightMid + 10),
                color = Color.Red
            )
            startPoint -= interval
            if (startPoint <= 0)
                posFlag = false
        }

        posFlag = true
        startPoint = widthMid
        while (posFlag) {
            drawLine(
                start = Offset(x = startPoint, y = heightMid - 10),
                end = Offset(x = startPoint, y = heightMid + 10),
                color = Color.Red
            )
            startPoint += interval
            if (startPoint >= canvasWidth)
                posFlag = false
        }
    }


    private fun DrawScope.drawGridVerticalMarkers(
        heightMid: Float,
        widthMid: Float,
        interval: Float,
        canvasHeight: Float
    ) {
        //  Draw Vertical Markers Reverse
        var posFlag = true
        var startPoint = heightMid
        while (posFlag) {
            drawLine(
                start = Offset(x = widthMid - 10, y = startPoint),
                end = Offset(x = widthMid + 10, y = startPoint),
                color = Color.Red
            )
            startPoint -= interval
            if (startPoint <= 0)
                posFlag = false
        }


        //  Draw Vertical Markers Forward
        posFlag = true
        startPoint = heightMid
        while (posFlag) {
            drawLine(
                start = Offset(x = widthMid - 10, y = startPoint),
                end = Offset(x = widthMid + 10, y = startPoint),
                color = Color.Red
            )
            startPoint += interval
            if (startPoint >= canvasHeight)
                posFlag = false
        }
    }

    private fun capturePoint(tapOffset: Offset) {

        // Log.i("William", "tapOffset: $tapOffset")

        if (!flagMeasuringCountDown) {
            flagMeasuringCountDown = true

            val widthMid = gCanvasWidth / 2
            val heightMid = gCanvasHeight / 2

            val canvasXPos: Double
            if (tapOffset.x >= widthMid)
                canvasXPos = (tapOffset.x - widthMid).toDouble()
            else
                canvasXPos = (widthMid - tapOffset.x) * -1.0

            val canvasYPos: Double
            if (tapOffset.y >= heightMid)
                canvasYPos = (tapOffset.y - heightMid) * -1.0
            else
                canvasYPos = (heightMid - tapOffset.y).toDouble()

            // Log.i("William", "canvas_xpos: $canvasXPos")
            // Log.i("William", "canvas_ypos: $canvasYPos")

            val actualXPosInMeters: Double = canvasXPos * (1 / oneMeterXAxisInPx)
            val actualYPosInMeters: Double = canvasYPos * (1 / oneMeterYAxisInPx)

            // Log.i("William", "actualXPosInMeters: $actualXPosInMeters meters")
            // Log.i("William", "actualYPosInMeters: $actualYPosInMeters meters")

            val posStr = "POS$apPOSCounter"

            //  Mark coordinate
            val coordinatePoint = CoordinatePoint(actualXPosInMeters, actualYPosInMeters, Calendar.getInstance().timeInMillis, posStr)

            //  Add to Holder list
            addToCoordListV2(coordinatePoint)

            apPOSCounter++

            object : CountDownTimer(captureTimeWindow, 1000) {
                override fun onTick(millisUntilFinished: Long) {
                    textViewMessage.text = "Remaining: " + (millisUntilFinished / 1000) + "s."
                }

                override fun onFinish() {
                    flagMeasuringCountDown = false

                    textViewMessage.text = "Ready"

                    createDialogBox()
                }
            }.start()
        }
    }

    fun createDialogBox() {

        val builder = AlertDialog.Builder(this.thisContext)
        builder.setMessage("Done! Move to next position!")
            .setPositiveButton("Close") { dialog, id ->
                // START THE GAME!
                dialog.cancel()
            }

        builder.create().show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    /**
     * Part of Hardcoded AP. To be removed once in production.
     */
    private fun getIndexFromMac(mac6: String): Int {

        val mac6Set = mac6.split(":")

        for (eachMac5 in apMACIndexMap) {

            val mac5Set = eachMac5.key.split(":")

            var flagFound = true
            for (index in 0..4) {
                if (mac5Set[index].compareTo(mac6Set[index]) != 0) {
                    flagFound = false
                    break
                }
            }

            if (flagFound) {
                return eachMac5.value
            }
        }

        return 0
    }
}