package sg.edu.smu.teamrtt.localizertt.ui.drawSB1

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DrawSB1ViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        //value = "SOSS B1 Static"
        value = "Static View"
    }
    val text: LiveData<String> = _text
}