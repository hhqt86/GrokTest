package sg.edu.smu.teamrtt.localizertt.ui.imu

import android.hardware.SensorEvent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import sg.edu.smu.teamrtt.localizertt.databinding.FragmentImuBinding
import kotlin.math.roundToInt

/**
 * IMU Fragment
 *
 * This UI Fragment has the following functionality:
 * 1. Toggles On/Off IMU Sensors
 * 2. Displays the IMU Sensor Data
 *      a. Accelerometer
 *      b. Gyro
 *      c. Steps
 *      d. Computed Data: Pitch, Roll and Azimuth.
 *
 * William Notes:
 * 1. DO NOT put long running data gathering in Fragments, as the process might stop when user is switching between fragments.
 *
 * Notes:
 * 1. This project is Drawer-Navigation paradigm, Each UI is in Fragment and you swap between the fragments via top-left navigation to push out the available views.
 * 2. Icons used reference:
 *      a. https://www.reddit.com/r/androiddev/comments/qygh2j/where_can_i_download_free_xml_vector_icons/
 *      b. https://pictogrammers.com/library/mdi/?welcome
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 May 19: Created by William Tan Kiat Wee.
 */
class IMUFragment : Fragment() {

    private var _binding: FragmentImuBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    //  UI Elements
    private var tvContentAccelX: TextView? = null
    private var tvContentAccelY: TextView? = null
    private var tvContentAccelZ: TextView? = null
    private var tvContentGyroX: TextView? = null
    private var tvContentGyroY: TextView? = null
    private var tvContentGyroZ: TextView? = null
    private var tvContentStepsDetect: TextView? = null
    private var tvContentOrientAzimuth: TextView? = null
    private var tvContentOrientPitch: TextView? = null
    private var tvContentOrientRoll: TextView? = null
    private var btnSwitchSensor: Switch? = null

    private var stepCounter: Long = 0

    private val imuViewModel: IMUViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        //val imuViewModel = ViewModelProvider(this).get(IMUViewModel::class.java)

        _binding = FragmentImuBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textImuHeader
        imuViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        tvContentAccelX = binding.tvContentAccelX
        tvContentAccelY = binding.tvContentAccelY
        tvContentAccelZ = binding.tvContentAccelZ

        tvContentGyroX = binding.tvContentGyroX
        tvContentGyroY = binding.tvContentGyroY
        tvContentGyroZ = binding.tvContentGyroZ

        tvContentStepsDetect = binding.tvContentStepDetect

        tvContentOrientAzimuth = binding.tvContentOrientationAzimuth
        tvContentOrientPitch = binding.tvContentOrientationPitch
        tvContentOrientRoll = binding.tvContentOrientationRoll

        btnSwitchSensor = binding.switchEnableSensor
        binding.switchEnableSensor.setOnCheckedChangeListener { buttonView, isChecked ->

            if (isChecked) {
                //  Trigger the MainActivity to start scanning.
                imuViewModel.setFlagStartScan(true)

            } else {
                //  Trigger the MainActivity to stop scanning.
                imuViewModel.setFlagStartScan(false)
            }
        }

        //  Observe the View Model for changes
        imuViewModel.currentSensorAccelEvent.observe(viewLifecycleOwner) { value ->
            setUIAccelData(value)
        }

        imuViewModel.currentSensorGyroEvent.observe(viewLifecycleOwner) { value ->
            setUIGyroData(value)
        }

        imuViewModel.currentSensorStepDetectedEvent.observe(viewLifecycleOwner) { value ->
            setUIStepDetectData()
        }

        imuViewModel.currentComputedDataOrientation.observe(viewLifecycleOwner) { value ->
            setUIOrientationData(value)
        }

        return root
    }

    /**
     * Display the Accel data to the Views
     */
    private fun setUIAccelData(sensorEvent: SensorEvent) {
        tvContentAccelX?.text = sensorEvent.values[0].toString()
        tvContentAccelY?.text = sensorEvent.values[1].toString()
        tvContentAccelZ?.text = sensorEvent.values[2].toString()
    }

    /**
     * Display the Gyro data to the Views
     */
    private fun setUIGyroData(sensorEvent: SensorEvent) {
        tvContentGyroX?.text = sensorEvent.values[0].toString()
        tvContentGyroY?.text = sensorEvent.values[1].toString()
        tvContentGyroZ?.text = sensorEvent.values[2].toString()
    }

    /**
     * Display the Step data to the Views
     */
    private fun setUIStepDetectData() {

        stepCounter++
        tvContentStepsDetect?.text = stepCounter.toString()
    }

    /**
     * Display the Orientation data to the Views
     *
     */
    private fun setUIOrientationData(orientationData: FloatArray) {

        //  Convert to Degrees
        val azimuthInDegrees = (Math.toDegrees(orientationData[0].toDouble()) + 360).toFloat() % 360
        val pitchInDegrees = (Math.toDegrees(orientationData[1].toDouble()) + 360).toFloat() % 360
        val rollInDegrees = (Math.toDegrees(orientationData[2].toDouble()) + 360).toFloat() % 360

        tvContentOrientAzimuth?.text = azimuthInDegrees.roundToInt().toString()
        tvContentOrientPitch?.text = pitchInDegrees.roundToInt().toString()
        tvContentOrientRoll?.text = rollInDegrees.roundToInt().toString()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}