package sg.edu.smu.teamrtt.localizertt.operations.wifi

import android.net.wifi.rtt.RangingResult
import java.util.concurrent.ConcurrentHashMap

/**
 * WiFi RTT Process Operation Class
 *
 * Sits in MainActivity
 * Obtains RTT Range scan from WIFIRTTScanOps
 * Uses Research Package to process
 *
 * @author William Tan Kiat Wee
 * Tracking:
 * - 2025 Feb 20: Created for integrating the Research Components. William.
 * - 2025 Feb 24: Added in Get RangeReadings and associated functions.
 */
class RTTProcessOps(private val trackingTimeWindow: Long) {

    /**
     * TAG for Logging
     */
    //private val classTAG = this.javaClass.name

    /**
     * Data older than this time window will be delete.
     * Time Window in millisec. E.g. 5min = 5 * 60 * 1000
     *
     * E.g. If timestamp is older than 5min, it will be deleted.
     */
    private val maxTimeWindowToHoldData = 5 * 60 * 1000L

//    /**
//     * (Deprecated)
//     * (Used in Leastsquare Algo, code now use Probabilistic AP's location approach. function is deprecated)
//     *
//     * Tracked Access Point: BSSID String - TrackedAP (Class)
//     */
//    private var trackedAccessPoints = HashMap<String, TrackedAP>()
//
//    /**
//     * (Deprecated)
//     * (Used in Leastsquare Algo, code now use Probabilistic AP's location approach. function is deprecated)
//     *
//     * List of AP used for compute
//     */
//    private var listOfAPForCompute: MutableList<String> = mutableListOf()
//
//    /**
//     * (Deprecated)
//     * (Used in Leastsquare Algo, code now use Probabilistic AP's location approach. function is deprecated)
//     *
//     * Range Error after computing all AP
//     */
//    private var rangeErrorEachAP = DoubleArray(1)

    //  Steps
    //private var stepsCounted: Long = 0

    //  Stored Steps Data
    //private var listOfUserStepData: MutableList<StepData> = mutableListOf()

    /**
     * Hashmap holding the history of RTT Range Result
     * Each result is paired to the timestamp that they are collected.
     *
     * Note:
     * 1. Although RangingResult is collected. This holder does not discriminate between success or fail RTT range.
     * 2. Hence, users are expected to parse the RangingResult to determine if the range result is usable or not.
     */
    private var rangeRTTResultsHashMap = ConcurrentHashMap<Long, MutableList<RangingResult>>()

    private var hashmapOfBSSIDToTimestampRTTRangeResult = ConcurrentHashMap<String, ConcurrentHashMap<Long, MutableList<RangingResult>>>()

    /**
     * Add the RTT Range Result to the Holder (Hashmap)
     *
     * Each result is paired to the timestamp that they are collected.
     *
     * Note:
     * 1. Although RangingResult is collected. This holder does not discriminate between success or fail RTT range.
     * 2. Hence, users are expected to parse the RangingResult to determine if the range result is usable or not.
     * 3. Older results greater than the maxTimeWindowToHoldData will be deleted from Hashmap holder to conserve space.
     */
    fun addCapturedRTTRangeResult(timestamp: Long, rangeResult: MutableList<RangingResult>) {

        //  Add to collection
        rangeRTTResultsHashMap[timestamp] = rangeResult.toMutableList()
        //scanResultsHashMap.put(timestamp, filteredList.toMutableList())

        //  Remove old result older than the allowed time window to conserve space.
        val filterTimestamp = timestamp - maxTimeWindowToHoldData
        for (eachTimestamp in rangeRTTResultsHashMap.keys)
            if (eachTimestamp <= filterTimestamp)
                rangeRTTResultsHashMap.remove(eachTimestamp)

        //  ==============================================
        //  New: Sort RangeResult into its BSSID holder
        //  ==============================================

        //  Iterate through the RangeResult list
        for (eachRangeResult in rangeResult) {

            //  Only process those that are success.
            if ((eachRangeResult.status == RangingResult.STATUS_SUCCESS)) {

                //  Capture the BSSID this range result belongs to.
                val strBSSID = eachRangeResult.macAddress.toString()

                //  Separate this range result into its own holder (which is going to be tagged to the BSSID)
                val filteredListOfRangingResult: MutableList<RangingResult> = mutableListOf()
                filteredListOfRangingResult.add(eachRangeResult)

                //  Check if overall holder already has the BSSID.
                if (hashmapOfBSSIDToTimestampRTTRangeResult.containsKey(strBSSID)) {

                    //  If yes: Store the latest Timestamp-RangeResult to its associated BSSID holder
                    val localRangeRTTResultsHashMap = hashmapOfBSSIDToTimestampRTTRangeResult[strBSSID]
                    if (localRangeRTTResultsHashMap != null && (!localRangeRTTResultsHashMap.containsKey(timestamp)))
                        localRangeRTTResultsHashMap[timestamp] = filteredListOfRangingResult.toMutableList()

                } else {

                    //  If no: Store the new BSSID into the holder with its latest Timestamp-RangeResult.
                    val localRangeRTTResultsHashMap = ConcurrentHashMap<Long, MutableList<RangingResult>>()
                    localRangeRTTResultsHashMap[timestamp] = filteredListOfRangingResult.toMutableList()

                    hashmapOfBSSIDToTimestampRTTRangeResult[strBSSID] = localRangeRTTResultsHashMap
                }
            }
        }

        //  Remove old result older than the allowed time window to conserve space.
        for (eachBSSIDTimestamp in hashmapOfBSSIDToTimestampRTTRangeResult) {
            val localRangeRTTResultsHashMap = eachBSSIDTimestamp.value
            for (eachTimestamp in localRangeRTTResultsHashMap.keys)
                if (eachTimestamp <= filterTimestamp)
                    localRangeRTTResultsHashMap.remove(eachTimestamp)
        }
    }

    /**
     * Retrieve the collected RTT Range Result
     *
     * Note:
     * 1. Although RangingResult is collected. This holder does not discriminate between success or fail RTT range.
     * 2. Hence, users are expected to parse the RangingResult to determine if the range result is usable or not.
     * 3. Older results greater than the maxTimeWindowToHoldData will be deleted from Hashmap holder to conserve space.
     * 4. Return empty hashmap, if no data is collected.
     */
    fun getCollectedRTTRangeResult(): HashMap<Long, MutableList<RangingResult>> {
        return if (rangeRTTResultsHashMap.isEmpty())
            hashMapOf()
        else
            rangeRTTResultsHashMap.toMap() as HashMap<Long, MutableList<RangingResult>>
    }

    fun getCollectedRTTRangeResult(strBSSID: String): HashMap<Long, MutableList<RangingResult>> {
        return if (rangeRTTResultsHashMap.isEmpty())
            hashMapOf()
        else {
            var filteredRangeRTTResultsHashMap = ConcurrentHashMap<Long, MutableList<RangingResult>>()

            if (hashmapOfBSSIDToTimestampRTTRangeResult.containsKey(strBSSID)) {
                val bssidRangeRTTResultsHashMap = hashmapOfBSSIDToTimestampRTTRangeResult.get(strBSSID)
                if (bssidRangeRTTResultsHashMap != null)
                    filteredRangeRTTResultsHashMap = bssidRangeRTTResultsHashMap
            }

            filteredRangeRTTResultsHashMap.toMap() as HashMap<Long, MutableList<RangingResult>>
        }
    }

//    /**
//     * (Deprecated)
//     * (Used in Leastsquare Algo, code now use Probabilistic AP's location approach. function is deprecated)
//     *
//     * Update Tracking of each AP and its RTT Results
//     *
//     * timestamp: Current Timestamp of captured RTT result.
//     * MutableList<RangingResult>: The current captured RTT Range Result
//     */
//    fun updateRTTRangeResult(timestamp: Long, rangeResult: MutableList<RangingResult>) {
//
//        //  DEBUG Logging
//        //Log.i(TAG, "updateTracking: ${rangeResult}")
//
//        //  Iterate thru the RTT scan result
//        for (eachScanResult in rangeResult) {
//
//            //  Only process those the are success.
//            if (eachScanResult.status == RangingResult.STATUS_SUCCESS) {
//
//                //Log.i(TAG, "RTT Success. eachScanResult: ${eachScanResult}")
//
//                //  Get the BSSID
//                val refMacAddress = eachScanResult.macAddress.toString()
//
//                //  Setup the Tracked-AP based on the BSSID.
//                //  Check if the Tracked-AP exist or not
//                //  Add in if not exist, if exist: Update the existing record (timestamp + distance)
//                var trackedAP: TrackedAP?
//                if (trackedAccessPoints.containsKey(refMacAddress)) {
//                    //  Existing AP
//                    trackedAP = trackedAccessPoints[refMacAddress]
//                } else {
//                    //  New AP
//                    trackedAP = TrackedAP(refMacAddress, trackingTimeWindow)
//                    trackedAccessPoints[refMacAddress] = trackedAP
//                }
//
//                //  Update the trackedAP (to meters)
//                trackedAP?.addDataPoint(timestamp, (eachScanResult.distanceMm / 1000.0))
//            }
//        }
//
//        //Log.i(TAG, "trackedAccessPoints.size: ${trackedAccessPoints.size}")
//    }

//    /**
//     * (Deprecated)
//     * (Code not use: Step data tracked in CoordOps)
//     *
//     * Update Tracking of Each Step and the Azimuth the user is facing.
//     *
//     * orientationAngles: The Float Array [3] containing [Azimuth, Pitch, Roll]
//     *
//     * StepData is stored and compact at each timestamp (i.e. Older values are removed to keep memory compact)
//     */
//    fun updateStepData(orientationAngles: FloatArray) {
//
//        //  Increment the Step Count. (Note this is reset if app is restarted)
//        stepsCounted++
//        //Log.i(TAG, "stepsCounted: $stepsCounted")
//
//        val timestampData = Calendar.getInstance().timeInMillis
//        val azimuthInDegrees = (Math.toDegrees(orientationAngles[0].toDouble()) + 360).toFloat() % 360
//        val cStepData = StepData(stepsCounted, azimuthInDegrees.roundToInt(), timestampData)
//        //Log.i(TAG, "StepData: $cStepData")
//
//        if (listOfUserStepData.isEmpty()) {
//            //  Add to list
//            listOfUserStepData.add(cStepData)
//        } else {
//            //  Add to list
//            addToList(cStepData)
//
//            //  Compact list (remove data outside the time bound)
//            compactStepData()
//        }
//    }
//
//    /**
//     * Add StepData to the Holding List
//     *
//     * Check before adding: No repeating Step
//     */
//    private fun addToList(stepData: StepData): Boolean {
//
//        //  TODO: Check if there is a better way to do this in Kotlin.
//        for (eachStepData in listOfUserStepData) {
//
//            if (stepData.stepID == eachStepData.stepID)
//                return false
//        }
//
//        listOfUserStepData.add(stepData)
//
//        return true
//    }
//
//    /**
//     * Compact The StepData Holding List
//     *
//     * Compact by removing older entries if they are older than the trackingTimeWindow's Midpoint
//     * Purpose: So that we don't make the app goes into out of memory.
//     */
//    private fun compactStepData() {
//
//        //Log.i(TAG, "Compact StepData!")
//
//        val newListOfUserStepData: MutableList<StepData> = mutableListOf()
//
//        val midpoint = trackingTimeWindow / 2
//
//        val filterTimestamp = Calendar.getInstance().timeInMillis - midpoint
//
//        for (eachStepData in listOfUserStepData) {
//
//            if (eachStepData.timestampMillis > filterTimestamp) {
//                newListOfUserStepData.add(eachStepData)
//                //Log.i(TAG, "StepData: $eachStepData")
//            }
//        }
//
//        listOfUserStepData = newListOfUserStepData
//    }


//    /**
//     * (Deprecated)
//     * (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Get Estimated User Location
//     *
//     * Given the list of estimated AP (Accesses Point) and the time window for capturing
//     * listOfAPCoordinate: MutableList<CoordinatePoint>
//     * timeWindowMillSec: Long
//     *
//     * Return CoordinatePoint
//     */
//    fun getUserLocation(listOfAPCoordinate: MutableList<CoordinatePoint>, timeWindowMillSec: Long): CoordinatePoint {
//
//        //  Init the user location (at unrealistc location of 99999.99, 99999.99. User distance should be less than 10meters.)
//        var resultCoordinatePoint = CoordinatePoint(99999.99, 99999.99)
//
//        //  Prerequisite Check that there is data to process before continuing.
//        if (trackedAccessPoints.isEmpty()) {
//            Log.e(classTAG, "getUserLocation(): No RTT Scan Data to processed on. Returning empty list of AP Coordinates!")
//            return resultCoordinatePoint
//        }
//        // TODO: Add Check listOfAPCoordinate, timeWindowMillSec, listOfAPForCompute
//
//        //  As we are getting the user location now, we get the current timestamp
//        val listOfTimestampAtCoordinatePoint: MutableList<Long> = mutableListOf()
//        listOfTimestampAtCoordinatePoint.add(Calendar.getInstance().timeInMillis)
//
//        //  Get the Range Readings given current timestamp
//        val rangeResult = getRangeReading(listOfTimestampAtCoordinatePoint, timeWindowMillSec)
//        if (rangeResult.isNotEmpty()) {
//
//            //  Get the list of the current detected RangResult
//            val listOfBSSID = APRangeReading.obtainListOfAP(rangeResult)
//
//            //  Check if the current detected list matches the compute AP list.
//            var allPresentFlag = true
//            for (eachBSSIDinList in listOfAPForCompute) {
//                if (!listOfBSSID.contains(eachBSSIDinList)) {
//                    allPresentFlag = false
//                    break
//                }
//            }
//
//            //  If list matches, proceed with user location detection.
//            if (allPresentFlag) {
//
//                //  Obtain the rangeResult
//                val rrRangeReading = APRangeReading.obtainRangeReading(rangeResult)
//
//                var extractedDistance = DoubleArray(1)
//
//                for (eachComputedAPBSSID in listOfAPForCompute) {
//
//                    for ((index, eachDetectedBSSID) in listOfBSSID.withIndex()) {
//
//                        if (eachComputedAPBSSID.compareTo(eachDetectedBSSID) == 0) {
//                            extractedDistance += rrRangeReading[index][0]
//                        }
//                    }
//                }
//
//                //  Interface with Hai's Algo to get user location.
//                resultCoordinatePoint = localizePosition(rangeErrorEachAP, listOfAPCoordinate.toTypedArray(), extractedDistance)
//            } else {
//                Log.i(this.javaClass.name, "not all present")
//            }
//        }
//
//        return resultCoordinatePoint
//    }

//    /**
//     *  (Deprecated)
//     *  (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Get AP (Access Point) Estimated Location
//     *
//     * Given the list of capturing positions and the capturing timestamp. Compute and return the list of estimated AP location.
//     * The positions and location in cartesian coordinates.
//     *
//     * arrayOfCoord: Array<CoordinatePoint> = Array of Coordinates of the capturing position.
//     * listOfTimestampAtCoordinatePoint: MutableList<Long> = List of the timestamp of the captured positions
//     * timeWindowMillSec: Long = The capturing time window.
//     *
//     * Returns MutableList<CoordinatePoint> = List of the estimated AP (can be empty)
//     */
//    fun getAPLocation(
//        arrayOfCoord: Array<CoordinatePoint>,
//        listOfTimestampAtCoordinatePoint: MutableList<Long>,
//        timeWindowMillSec: Long
//    ): MutableList<CoordinatePoint> {
//
//        //  Init the return list.
//        val listOfEstimatedAP: MutableList<CoordinatePoint> = mutableListOf()
//
//        //  Prerequisite Check that there is data to process before continuing.
//        if (trackedAccessPoints.isEmpty()) {
//            Log.e(this.javaClass.name, "getAPLocation(): No RTT Scan Data to processed on. Returning empty list of AP Coordinates!")
//            return listOfEstimatedAP
//        }
//
//        //  Get the Range Readings given the timestamp
//        val rangeResult = getRangeReading(listOfTimestampAtCoordinatePoint, timeWindowMillSec)
//        if (rangeResult.isNotEmpty()) {
//
//            val listOfBSSID = APRangeReading.obtainListOfAP(rangeResult)
//            val rrRangeReading = APRangeReading.obtainRangeReading(rangeResult)
//            val numOfAP = listOfBSSID.size
//
//            //  Debug logging
//            // Log.i(TAG, "getAPLocation numOfAP: $numOfAP")
//            // for (eachItem in rangeResult)
//            //     Log.i(TAG, "getAPLocation RangeResult: $eachItem")
//
//            //  Store the reference list of AP used for compute.
//            listOfAPForCompute = listOfBSSID.toMutableList()
//
//            //  ======================================
//            //  Hai's Contant Error Algo Portion Start
//            val diffDistances = APLocationConstantErrorLeastSquare.calculateDiffDistances(rrRangeReading)
//
//            for (i in 0..<numOfAP) {
//                val estimatedAPCoord = APLocationConstantErrorLeastSquare.solveX(arrayOfCoord, diffDistances[i])
//                estimatedAPCoord.label = listOfBSSID[i]
//                listOfEstimatedAP.add(estimatedAPCoord)
//                //Log.i(TAG, "getAPLocation BSSID: ${listOfBSSID[i]}")
//            }
//
//            rangeErrorEachAP = APLocationConstantErrorLeastSquare.calculateRangingErrors(numOfAP, arrayOfCoord, rrRangeReading, listOfEstimatedAP.toTypedArray())
//
//            //  Hai's Contant Error Algo Portion End
//            //  ====================================
//        }
//
//        return listOfEstimatedAP
//    }

//    /**
//     *  (Deprecated)
//     *  (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Get the Range Readings into format required by the Research Module
//     *
//     * Sample:
//     *     	double[][] rangeReadings = {
//     *                 {2002.0, 2006.5, 2019.01, 2014.32, 2011.70},
//     *                 {2208.06, 2207.02, 2210.31, 2207.07, 2204.47},
//     *                 {2415.0, 2410.5, 2411.10, 2407.21, 2417.03},
//     *                 {2617.49, 2613.83, 2602.5, 2605.0, 2613.15}
//     *             };
//     */
//    private fun getRangeReading(listOfTimestampAtCoordinatePoint: MutableList<Long>, timeWindowMillSec: Long): List<APRangeReading> {
//
//        /**
//         * Init the timestamp data: in KeyValue Pair: Timestamp-(BSSID-TrackedAP)
//         * Where the timestamped is the Unix Timestamp at each Coordinate.
//         *
//         * Hence, at each Timestamp, we have a Key-Value Pair List of BSSID-TrackedAP
//         * Where TrackedAP is the data collected over time.
//         */
//        val timestampedData = HashMap<Long, HashMap<String, TrackedAP>>()
//
//        /**
//         * Init the timestamp data: in KeyValue Pair: Timestamp-(BSSID-AverageDistance)
//         * Where the timestamped is the Unix Timestamp at each Coordinate.
//         *
//         * Hence, at each Timestamp, we have a Key-Value Pair List of BSSID-AverageDistance
//         * Where AverageDistance is the distance average over the TrackedAP at that Point of time and space.
//         *
//         * This is beacause, we might have a larger time window, and we collect more data that needs to be average out.
//         */
//        val timestampedDataCondensedToAvgDistance = HashMap<Long, HashMap<String, Double>>()
//
//        //  Collect the data at each Point (or rather at each Timestamp)
//        //  We do this all at once at the end of the tranversing all the points.
//        for (eachTimestamp in listOfTimestampAtCoordinatePoint) {
//
//            //  Hence, at each coordidate, we will have a timestamp,
//            //  Using that timestamp and the approproate time window, we get the
//            //  tracked APs at that point of time and store it into the key-value pair.
//            val timestampedTrackedAP = getTrackedAP(eachTimestamp, timeWindowMillSec)
//            timestampedData[eachTimestamp] = timestampedTrackedAP
//
//            //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedTrackedAP: $timestampedTrackedAP")
//        }
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedData: $timestampedData")
//
//        //  Find the BSSID that is common throughout the collection period
//        //  As it is possible not all BSSID are seen at every point.
//        val setOfCommonBSSID = getCommonBSSID(timestampedData)
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. getCommonBSSID: $setOfCommonBSSID")
//
//        //  Once, we get all the data, we processed it to get the average distance of each BSSID at that point of time.
//        //  This is stored in timestampedDataCondensedToAvgDistance
//        for (eachTimestamp in timestampedData.keys) {
//
//            val pairsOfBSSIDwithTrackedAPs = timestampedData.get(eachTimestamp)
//
//            if (pairsOfBSSIDwithTrackedAPs != null) {
//
//                val condensedBSSIDwithDistancePairs = HashMap<String, Double>()
//
//                for (eachBSSID in pairsOfBSSIDwithTrackedAPs.keys) {
//                    if (setOfCommonBSSID.contains(eachBSSID)) {
//                        val averageDistance: Double? = pairsOfBSSIDwithTrackedAPs.get(eachBSSID)?.getAverageDistance()
//
//                        if (averageDistance != null && averageDistance != 0.0) {
//                            condensedBSSIDwithDistancePairs[eachBSSID] = averageDistance
//                            //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedDataCondensedToAvgDistance. eachBSSID: $eachBSSID, averageDistance: $averageDistance")
//                        }
//                    }
//                }
//                timestampedDataCondensedToAvgDistance[eachTimestamp] = condensedBSSIDwithDistancePairs
//                //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedDataCondensedToAvgDistance. eachTimestamp: $eachTimestamp, condensedBSSIDwithDistancePairs: $condensedBSSIDwithDistancePairs")
//            }
//        }
//
//        //  Sort the map based on the time:
//        //  Ref: https://mrappbuilder.medium.com/sort-a-hashmap-in-kotlin-in-ascending-order-but-the-first-element-is-not-used-in-sorting-a7d6f1a1fefa
//        val filteredSortedMap = timestampedDataCondensedToAvgDistance.toList().sortedBy { it.first }.toMap()
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. filteredSortedMap: $filteredSortedMap")
//
//        //  Get the BSSID in ordered form
//        val arrangedSetOfBSSID: MutableMap<Int, String> = mutableMapOf()
//        for ((counter, eachBSSID) in setOfCommonBSSID.withIndex()) {
//            arrangedSetOfBSSID[counter] = eachBSSID
//        }
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. arrangedSetOfBSSID: $arrangedSetOfBSSID")
//
//        //  Init the rangeReadings Nested Array
//        //var rangeReadings: Array<DoubleArray> = emptyArray()
//        val rangeReadings: MutableList<APRangeReading> = mutableListOf()
//
//        //  Iterate through each BSSID-timestamp
//        //  Get the distance and put it into the corresponding order of the rangeReadings
//        for (eachIndex in 0..<arrangedSetOfBSSID.size) {
//
//            val eachBSSID = arrangedSetOfBSSID.get(eachIndex)
//
//            var eachReadingRow: Array<Double> = emptyArray()
//
//            for (eachTimestamp in filteredSortedMap.keys) {
//
//                val pairsOfBSSIDwithDistance = filteredSortedMap.get(eachTimestamp)
//
//                if (eachBSSID != null) {
//                    val averageDistance = pairsOfBSSIDwithDistance?.get(eachBSSID)
//                    if (averageDistance != null) {
//                        eachReadingRow += averageDistance
//                        //Log.i("WiFiRTTProcessOps", "getRangeReading. averageDistance: ${averageDistance}")
//                    }
//                }
//            }
//
//            val doubleArray = eachReadingRow.toDoubleArray()
//            //rangeReadings += doubleArray
//
//            if (eachBSSID != null) {
//                val apRangeReading = APRangeReading(eachBSSID, doubleArray)
//                rangeReadings += apRangeReading
//            }
//        }
//
//        return rangeReadings
//    }


//    /**
//     *  (Deprecated)
//     *  (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Get the Range Readings into format required by the Research Module
//     *
//     * Sample:
//     *     	double[][] rangeReadings = {
//     *                 {2002.0, 2006.5, 2019.01, 2014.32, 2011.70},
//     *                 {2208.06, 2207.02, 2210.31, 2207.07, 2204.47},
//     *                 {2415.0, 2410.5, 2411.10, 2407.21, 2417.03},
//     *                 {2617.49, 2613.83, 2602.5, 2605.0, 2613.15}
//     *             };
//     */
//    //    fun getRangeReading(listOfTimestampAtCoordinatePoint: MutableList<Long>, timeWindowMillSec: Long): Array<Array<Double>> {
//    private fun getRangeReadingOld(listOfTimestampAtCoordinatePoint: MutableList<Long>, timeWindowMillSec: Long): Array<DoubleArray> {
//
//        /**
//         * Init the timestamp data: in KeyValue Pair: Timestamp-(BSSID-TrackedAP)
//         * Where the timestamped is the Unix Timestamp at each Coordinate.
//         *
//         * Hence, at each Timestamp, we have a Key-Value Pair List of BSSID-TrackedAP
//         * Where TrackedAP is the data collected over time.
//         */
//        val timestampedData = HashMap<Long, HashMap<String, TrackedAP>>()
//
//        /**
//         * Init the timestamp data: in KeyValue Pair: Timestamp-(BSSID-AverageDistance)
//         * Where the timestamped is the Unix Timestamp at each Coordinate.
//         *
//         * Hence, at each Timestamp, we have a Key-Value Pair List of BSSID-AverageDistance
//         * Where AverageDistance is the distance average over the TrackedAP at that Point of time and space.
//         *
//         * This is beacause, we might have a larger time window, and we collect more data that needs to be average out.
//         */
//        val timestampedDataCondensedToAvgDistance = HashMap<Long, HashMap<String, Double>>()
//
//        //  Collect the data at each Point (or rather at each Timestamp)
//        //  We do this all at once at the end of the tranversing all the points.
//        for (eachTimestamp in listOfTimestampAtCoordinatePoint) {
//
//            //  Hence, at each coordidate, we will have a timestamp,
//            //  Using that timestamp and the approproate time window, we get the
//            //  tracked APs at that point of time and store it into the key-value pair.
//            val timestampedTrackedAP = getTrackedAP(eachTimestamp, timeWindowMillSec)
//            timestampedData[eachTimestamp] = timestampedTrackedAP
//
//            //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedTrackedAP: $timestampedTrackedAP")
//        }
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedData: $timestampedData")
//
//        //  Find the BSSID that is common throughout the collection period
//        //  As it is possible not all BSSID are seen at every point.
//        val setOfCommonBSSID = getCommonBSSID(timestampedData)
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. getCommonBSSID: $setOfCommonBSSID")
//
//        //  Once, we get all the data, we processed it to get the average distance of each BSSID at that point of time.
//        //  This is stored in timestampedDataCondensedToAvgDistance
//        for (eachTimestamp in timestampedData.keys) {
//
//            val pairsOfBSSIDwithTrackedAPs = timestampedData.get(eachTimestamp)
//
//            if (pairsOfBSSIDwithTrackedAPs != null) {
//
//                val condensedBSSIDwithDistancePairs = HashMap<String, Double>()
//
//                for (eachBSSID in pairsOfBSSIDwithTrackedAPs.keys) {
//                    if (setOfCommonBSSID.contains(eachBSSID)) {
//                        val averageDistance: Double? = pairsOfBSSIDwithTrackedAPs.get(eachBSSID)?.getAverageDistance()
//
//                        if (averageDistance != null && averageDistance != 0.0) {
//                            condensedBSSIDwithDistancePairs[eachBSSID] = averageDistance
//                            //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedDataCondensedToAvgDistance. eachBSSID: $eachBSSID, averageDistance: $averageDistance")
//                        }
//                    }
//                }
//                timestampedDataCondensedToAvgDistance[eachTimestamp] = condensedBSSIDwithDistancePairs
//                //Log.i("WiFiRTTProcessOps", "getRangeReading. Obtaining timestampedData. timestampedDataCondensedToAvgDistance. eachTimestamp: $eachTimestamp, condensedBSSIDwithDistancePairs: $condensedBSSIDwithDistancePairs")
//            }
//        }
//
//
//        //  Sort the map based on the time:
//        //  Ref: https://mrappbuilder.medium.com/sort-a-hashmap-in-kotlin-in-ascending-order-but-the-first-element-is-not-used-in-sorting-a7d6f1a1fefa
//        val filteredSortedMap = timestampedDataCondensedToAvgDistance.toList().sortedBy { it.first }.toMap()
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. filteredSortedMap: $filteredSortedMap")
//
//        //  Get the BSSID in ordered form
//        val arrangedSetOfBSSID: MutableMap<Int, String> = mutableMapOf()
//        for ((counter, eachBSSID) in setOfCommonBSSID.withIndex()) {
//            arrangedSetOfBSSID[counter] = eachBSSID
//        }
//        //Log.i("WiFiRTTProcessOps", "getRangeReading. arrangedSetOfBSSID: $arrangedSetOfBSSID")
//
//        //  Init the rangeReadings Nested Array
//        var rangeReadings: Array<DoubleArray> = emptyArray()
//
//        //  Iterate through each BSSID-timestamp
//        //  Get the distance and put it into the corresponding order of the rangeReadings
//        for (eachIndex in 0..<arrangedSetOfBSSID.size) {
//
//            val eachBSSID = arrangedSetOfBSSID.get(eachIndex)
//
//            var eachReadingRow: Array<Double> = emptyArray()
//
//            for (eachTimestamp in filteredSortedMap.keys) {
//
//                val pairsOfBSSIDwithDistance = filteredSortedMap.get(eachTimestamp)
//
//                if (eachBSSID != null) {
//                    val averageDistance = pairsOfBSSIDwithDistance?.get(eachBSSID)
//                    if (averageDistance != null) {
//                        eachReadingRow += averageDistance
//                        //Log.i("WiFiRTTProcessOps", "getRangeReading. averageDistance: ${averageDistance}")
//                    }
//                }
//            }
//
//            val doubleArray = eachReadingRow.toDoubleArray()
//            rangeReadings += doubleArray
//        }
//
//        return rangeReadings
//    }


//    /**
//     *  (Deprecated)
//     *  (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Get the Common set of BSSID.
//     *
//     * It is possible that not all APs are visible at each Coordinate Point.
//     * Hence, this function gets the common set of BSSID in all readings.
//     */
//    private fun getCommonBSSID(timestampedData: HashMap<Long, HashMap<String, TrackedAP>>): MutableSet<String> {
//
//        val setOfBSSID = mutableSetOf<String>()
//
//        for (eachTimestamp in timestampedData.keys) {
//
//            val filteredTrackedAccessPoints = timestampedData.get(eachTimestamp)
//            val timestampedSetOfBSSID = filteredTrackedAccessPoints?.keys
//
//            if (timestampedSetOfBSSID != null) {
//                for (eachSSID in timestampedSetOfBSSID) {
//
//                    if (checkBSSID(timestampedData, eachTimestamp, eachSSID)) {
//                        setOfBSSID.add(eachSSID)
//                    }
//                }
//            }
//        }
//
//        return setOfBSSID
//    }

//    /**
//     *  (Deprecated)
//     *  (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Check if BSSID exists in the keyValue Pair.
//     */
//    private fun checkBSSID(timestampedData: HashMap<Long, HashMap<String, TrackedAP>>, timestamped: Long, checkBSSID: String): Boolean {
//
//        for (eachTimestamp in timestampedData.keys) {
//
//            if (eachTimestamp != timestamped) {
//                val filteredTrackedAccessPoints = timestampedData.get(eachTimestamp)
//                if (!filteredTrackedAccessPoints?.containsKey(checkBSSID)!!)
//                    return false
//            }
//        }
//
//        return true
//    }


//    /**
//     *  (Deprecated)
//     *  (Previously use for APLocationConstantErrorLeastSquare)
//     *
//     * Get the list of Tracked AP.
//     *
//     * Given:
//     * timestampMillSec: The Timestamp to be retrieve
//     * timeWindowMillSec: The Time Window Bound +/- in Milliseconds.
//     *  - E.g. If set to 5 seconds or 5000
//     *  - timestampMillSec: 140000
//     * It will retrieve from time window: 135000 to 145000
//     */
//    private fun getTrackedAP(timestampMillSec: Long, timeWindowMillSec: Long): HashMap<String, TrackedAP> {
//
//        val filteredTrackedAccessPoints = HashMap<String, TrackedAP>()
//
//        //  Get window bound
//        val lowerLimit = timestampMillSec - timeWindowMillSec
//        val upperLimit = timestampMillSec + timeWindowMillSec
//
//        if (trackedAccessPoints.isNotEmpty()) {
//
//            val keySet = trackedAccessPoints.keys
//            for (eachKey in keySet) {
//
//                val trackedAP: TrackedAP? = trackedAccessPoints.get(eachKey)
//                val filteredTrackedAP = trackedAP?.getFilteredWindow(lowerLimit, upperLimit)
//                if (filteredTrackedAP != null && !filteredTrackedAP.isEmpty()) {
//                    filteredTrackedAccessPoints[eachKey] = filteredTrackedAP
//                }
//            }
//        }
//
//        return filteredTrackedAccessPoints
//    }
}